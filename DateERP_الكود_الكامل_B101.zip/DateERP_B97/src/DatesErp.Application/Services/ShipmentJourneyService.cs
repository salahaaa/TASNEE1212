using DatesErp.Core.Domain.Entities;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

/// <summary>§B101 — مرحلة واحدة في رحلة شحنة العميل (صف في التقرير).</summary>
public class JourneyStageRow
{
    public string StageAr { get; set; } = "";
    public string DocNumber { get; set; } = "-";
    public string DateText { get; set; } = "-";
    public string ShiftLine { get; set; } = "-";
    public double QtyKg { get; set; }
    public int Cartons { get; set; }
    public string StatusAr { get; set; } = "-";
    public string Detail { get; set; } = "-";
}

/// <summary>
/// §B101 — شحنة عميل كاملة: من أول دخولها (سطر خطة) حتى تسليمها تاماً للعميل.
/// الشحنة = سطر خطة إنتاج مرتبط بعميل: خطة ← أوامر (بعدد/تواريخ) ← تشغيل ← فحص ← مخزن التام ← تسليمات العميل.
/// </summary>
public class ShipmentJourneyLine
{
    public int PlanItemId { get; set; }
    public int PlanId { get; set; }
    public string PlanNumber { get; set; } = "";
    public int CustomerId { get; set; }
    public string CustomerName { get; set; } = "";
    public int ProductId { get; set; }
    public string ProductName { get; set; } = "";
    public double PlannedKg { get; set; }
    public int PlannedCartons { get; set; }
    public DateTime? PlannedDate { get; set; }

    // ── لحظات الرحلة (الإجابات المباشرة على أسئلة المدير) ──
    /// <summary>متى دخلت: تاريخ إنشاء الخطة (أول وجود للشحنة في النظام).</summary>
    public DateTime? EntryDate { get; set; }
    /// <summary>اعتماد الخطة (بها تصبح الشحنة رسمية).</summary>
    public DateTime? PlanApprovedDate { get; set; }
    public string EntryUser { get; set; } = "—";
    public string ApproverUser { get; set; } = "—";
    /// <summary>بكم أمر شُغّلت.</summary>
    public int OrderCount { get; set; }
    /// <summary>متى دخلت الإنتاج: أول تاريخ إنتاج لأوامرها.</summary>
    public DateTime? FirstProductionDate { get; set; }
    public DateTime? LastProductionDate { get; set; }

    // ── الإجماليات (من القيم المُزامَنة نفسها التي تعرضها «متاح العملاء») ──
    public double ProducedKg { get; set; }
    public double AcceptedKg { get; set; }
    public double RejectedKg { get; set; }
    public double ReceivedKg { get; set; }
    public double DeliveredKg { get; set; }
    public int DeliveredCartons { get; set; }
    public double InvoicedKg { get; set; }
    public DateTime? LastDeliveryDate { get; set; }

    /// <summary>✅ سلّمت تاماً / ⏳ جزئي / 🟡 بانتظار التسليم / 🔍 بانتظار الجودة / ⚪ لم تبدأ.</summary>
    public string StatusIcon { get; set; } = "";
    public string FinalStatusAr { get; set; } = "";
    /// <summary>أيام الدورة: من اعتماد الخطة حتى آخر تسليم.</summary>
    public int? CycleDays { get; set; }

    public List<JourneyStageRow> Stages { get; set; } = new();
}

/// <summary>§B101 — تتبع شحنة العميل من أول دخولها حتى تسليمها تام (تقرير «التتبع»).</summary>
public class ShipmentJourneyService
{
    private readonly DatesErpDbContext _db;

    public ShipmentJourneyService(DatesErpDbContext db) => _db = db;

    public List<ShipmentJourneyLine> GetJourneys(int? custId, int? prodId, int? planId)
    {
        var db = _db;
        var planItems = db.ProductionPlanItems.AsNoTracking()
            .Where(i => i.CustomerId != null
                     && (custId == null || i.CustomerId == custId)
                     && (prodId == null || i.ProductId == prodId)
                     && (planId == null || i.PlanId == planId))
            .OrderBy(i => i.PlanId).ThenBy(i => i.Id)
            .ToList();
        if (planItems.Count == 0) return new List<ShipmentJourneyLine>();

        // الاستعلامات — كلها للبيانات المرتبطة فقط (بلا استعلام لكل سطر)
        var plans = db.ProductionPlans.AsNoTracking()
            .Where(p => planItems.Select(i => i.PlanId).Contains(p.Id)).ToDictionary(p => p.Id);
        var custs = db.Customers.AsNoTracking()
            .Where(c => planItems.Select(i => i.CustomerId!.Value).Contains(c.Id)).ToDictionary(c => c.Id);
        var prods = db.Products.AsNoTracking()
            .Where(p => planItems.Select(i => i.ProductId).Contains(p.Id)).ToDictionary(p => p.Id);
        var users = db.Users.AsNoTracking().ToDictionary(u => u.Id, u => u.FullName ?? u.UserName);
        var shifts = db.Shifts.AsNoTracking().ToDictionary(s => s.Id, s => s.ShiftNameAr);
        var lines = db.ProductionLines.AsNoTracking().ToDictionary(l => l.Id, l => l.LineNameAr);
        var warehouses = db.Warehouses.AsNoTracking().ToDictionary(w => w.Id, w => w.WarehouseNameAr);

        var orderItems = db.ProductionOrderItems.AsNoTracking()
            .Where(i => i.PlanItemId != null && planItems.Select(p => p.Id).Contains(i.PlanItemId!.Value))
            .ToList();
        var orderIds = orderItems.Select(o => o.OrderId).Distinct().ToList();
        var orders = db.ProductionOrders.AsNoTracking()
            .Where(o => orderIds.Contains(o.Id)).ToDictionary(o => o.Id);
        var execs = db.ProductionExecutions.AsNoTracking()
            .Where(e => orderIds.Contains(e.OrderId))
            .OrderBy(e => e.StartDateTime).ThenBy(e => e.Id).ToList();
        var qcs = db.QualityChecks.AsNoTracking()
            .Where(q => q.OrderId != null && orderIds.Contains(q.OrderId!.Value))
            .OrderBy(q => q.Id).ToList();
        var qcItems = db.QualityCheckItems.AsNoTracking()
            .Where(i => qcs.Select(q => q.Id).Contains(i.CheckId)).ToList();
        var pds = db.ProductionDeliveries.AsNoTracking()
            .Where(d => d.SourceType == DeliverySources.FromCheck && qcs.Select(q => q.Id).Contains(d.SourceId))
            .ToList();
        var pdItems = db.ProductionDeliveryItems.AsNoTracking()
            .Where(i => pds.Select(d => d.Id).Contains(i.DeliveryId)).ToList();
        var fgs = db.FinishedGoodsReceipts.AsNoTracking()
            .Where(f => orderIds.Contains(f.OrderId)).OrderBy(f => f.Id).ToList();
        var fgItems = db.FinishedGoodsReceiptItems.AsNoTracking()
            .Where(i => fgs.Select(f => f.Id).Contains(i.ReceiptId)).ToList();
        var cds = db.CustomerDeliveries.AsNoTracking()
            .Where(c => custId == null || c.CustomerId == custId).OrderBy(c => c.Id).ToList();
        var cdItems = db.CustomerDeliveryItems.AsNoTracking()
            .Where(i => cds.Select(c => c.Id).Contains(i.DeliveryId)).ToList();

        var result = new List<ShipmentJourneyLine>();
        foreach (var pi in planItems)
        {
            if (!plans.TryGetValue(pi.PlanId, out var plan)) continue;
            var cust = custs.TryGetValue(pi.CustomerId!.Value, out var c) ? c : null;
            var prod = prods.TryGetValue(pi.ProductId, out var pr) ? pr : null;

            var line = new ShipmentJourneyLine
            {
                PlanItemId = pi.Id,
                PlanId = pi.PlanId,
                PlanNumber = plan.DocumentNumber,
                CustomerId = pi.CustomerId.Value,
                CustomerName = cust?.CustomerName ?? $"عميل #{pi.CustomerId}",
                ProductId = pi.ProductId,
                ProductName = prod?.ProductNameAr ?? $"صنف #{pi.ProductId}",
                PlannedKg = pi.PlannedQtyKg,
                PlannedCartons = pi.PlannedCartons,
                PlannedDate = pi.ScheduledDate,
                EntryDate = plan.CreatedDate,
                PlanApprovedDate = plan.ApprovedDate,
                EntryUser = UserName(users, plan.CreatedBy),
                ApproverUser = UserName(users, plan.ApprovedBy),
                ProducedKg = pi.ProducedQtyKg,
                AcceptedKg = pi.AcceptedQtyKg,
                DeliveredKg = pi.DeliveredQtyKg,
            };

            // أوامر الشحنة: بنود الأمر المرتبطة بسطر الخطة
            var myOrderItems = orderItems.Where(o => o.PlanItemId == pi.Id).ToList();
            var myOrderIds = myOrderItems.Select(o => o.OrderId).Distinct().ToList();
            var myOrders = myOrderIds.Where(orders.ContainsKey).Select(id => orders[id]).ToList();
            var myLots = myOrderItems.Where(o => o.LotId != null).Select(o => o.LotId!.Value).ToHashSet();
            line.OrderCount = myOrders.Count;
            var prodDates = myOrders.Where(o => o.ProductionDate != null).Select(o => o.ProductionDate!.Value).ToList();
            line.FirstProductionDate = prodDates.Count > 0 ? prodDates.Min() : null;
            line.LastProductionDate = prodDates.Count > 0 ? prodDates.Max() : null;
            // المرفوض: من آخر فحص لكل أمر (نتيجة الوضع الحالي للدفعة)
            foreach (var oid in myOrderIds)
            {
                var last = qcs.Where(q => q.OrderId == oid).OrderBy(q => q.Id).LastOrDefault();
                if (last == null) continue;
                line.RejectedKg += qcItems.Where(i => i.CheckId == last.Id && i.LotId != null && myLots.Contains(i.LotId!.Value))
                    .Sum(i => i.RejectedQtyKg);
            }

            // ── المرحلة 0: أول دخول (الخطة) ──
            line.Stages.Add(new JourneyStageRow
            {
                StageAr = "أول دخول — خطة الإنتاج",
                DocNumber = plan.DocumentNumber,
                DateText = plan.CreatedDate.ToString("dd/MM/yyyy HH:mm"),
                QtyKg = pi.PlannedQtyKg,
                Cartons = pi.PlannedCartons,
                StatusAr = DocStatusAr(plan.Status),
                Detail = $"أنشأها: {line.EntryUser} — اعتمدتها: {line.ApproverUser} " +
                         $"{(plan.ApprovedDate != null ? $"يوم {plan.ApprovedDate:dd/MM/yyyy HH:mm}" : "— بعد")} — " +
                         $"تاريخ التشغيل المجدول: {(pi.ScheduledDate != null ? pi.ScheduledDate.Value.ToString("dd/MM/yyyy") : "—")}"
            });

            // ── المراحل 1..N: كل أمر ونتائجه ──
            for (int n = 0; n < myOrders.Count; n++)
            {
                var o = myOrders[n];
                var tag = $"أمر {n + 1} — إنتاج";
                var lineItems = myOrderItems.Where(i => i.OrderId == o.OrderId).ToList();
                line.Stages.Add(new JourneyStageRow
                {
                    StageAr = tag,
                    DocNumber = o.DocumentNumber,
                    DateText = o.ProductionDate != null ? o.ProductionDate.Value.ToString("dd/MM/yyyy") : "—",
                    ShiftLine = ShiftLineText(shifts, lines, o.ShiftId, o.LineId),
                    QtyKg = lineItems.Sum(i => i.PlannedQtyKg),
                    Cartons = lineItems.Sum(i => i.PlannedCartons),
                    StatusAr = DocStatusAr(o.Status),
                    Detail = $"أُنشئ: {o.CreatedDate:dd/MM/yyyy HH:mm} ({UserName(users, o.CreatedBy)}) — " +
                             $"عُتمد/صُرف: {(o.ApprovedDate != null ? $"{o.ApprovedDate:dd/MM/yyyy HH:mm} ({UserName(users, o.ApprovedBy)})" : "—")}" +
                             (o.IsClosed ? $" — أُقفل: {o.ClosedDate?.ToString("dd/MM/yyyy HH:mm")} {Trunc(o.CloseReason, 60)}" : "")
                });

                // التشغيل (جلسات يوم الإنتاج) — خرج الجلسة للمستوى الكامل للأمر + حصة هذه الشحنة
                foreach (var ex in execs.Where(e => e.OrderId == o.OrderId).ToList())
                {
                    line.Stages.Add(new JourneyStageRow
                    {
                        StageAr = $"{tag} · تشغيل (جلسة)",
                        DocNumber = ex.DocumentNumber,
                        DateText = ex.StartDateTime != null ? ex.StartDateTime.Value.ToString("dd/MM/yyyy HH:mm")
                            : (ex.EndDateTime != null ? ex.EndDateTime.Value.ToString("dd/MM/yyyy HH:mm") : "—"),
                        ShiftLine = ShiftLineText(shifts, lines, ex.ShiftId, ex.LineId),
                        QtyKg = ex.ActualQtyKg,
                        Cartons = ex.ActualCartons,
                        StatusAr = ex.IsDayClosed ? "أُغلقت الجلسة" : "جلسة مفتوحة",
                        Detail = $"حصة هذه الشحنة: {myOrderItems.Where(i => i.OrderId == o.OrderId).Sum(i => i.ProducedQtyKg):N0} كجم — " +
                                 $"خسارة: {ex.WastageQtyKg:N0} كجم — حشف: {ex.HashfKg:N0} — نوى: {ex.NawaKg:N0} — خام مستهلك: {ex.ConsumedRawKg:N0} كجم"
                    });
                }

                // فحص الجودة (آخر فحص للأمر)
                var qcsOfOrder = qcs.Where(q => q.OrderId == o.OrderId).ToList();
                foreach (var qc in qcsOfOrder)
                {
                    var lineAccepted = qcItems.Where(i => i.CheckId == qc.Id && i.LotId != null && myLots.Contains(i.LotId!.Value))
                        .Sum(i => i.AcceptedQtyKg);
                    var lineRejected = qcItems.Where(i => i.CheckId == qc.Id && i.LotId != null && myLots.Contains(i.LotId!.Value))
                        .Sum(i => i.RejectedQtyKg);
                    line.Stages.Add(new JourneyStageRow
                    {
                        StageAr = $"{tag} · فحص الجودة",
                        DocNumber = qc.DocumentNumber,
                        DateText = qc.CheckDate != null ? qc.CheckDate.Value.ToString("dd/MM/yyyy") : "—",
                        QtyKg = qc.AcceptedKg,
                        Cartons = (int)qc.AcceptedCartons,
                        StatusAr = qc.IsApproved ? $"معتمد — {DecisionAr(qc.Decision)}" : DecisionAr(qc.Decision),
                        Detail = $"حصة هذه الشحنة: مقبول {lineAccepted:N0} / مرفوض {lineRejected:N0} كجم — " +
                                 $"الفاحص: {qc.InspectorName ?? "—"} — " +
                                 $"رطوبة: {qc.MoisturePct:0.##}% / Brix: {qc.BrixDeg:0.##}° — " +
                                 $"اعتماد: {(qc.ApprovedDate != null ? $"{qc.ApprovedDate:dd/MM/yyyy HH:mm} ({UserName(users, qc.ApprovedBy)})" : "—")}"
                    });
                }

                // تسليم الإنتاج → مخزن التام
                foreach (var pd in pds.Where(d => qcsOfOrder.Any(q => q.Id == d.SourceId)).ToList())
                {
                    var linePdT = pdItems.Where(i => i.DeliveryId == pd.Id && i.CustomerId == line.CustomerId && i.ProductId == line.ProductId);
                    line.Stages.Add(new JourneyStageRow
                    {
                        StageAr = $"{tag} · تسليم الإنتاج للمخزن",
                        DocNumber = pd.DocumentNumber,
                        DateText = pd.DeliveryDate != null ? pd.DeliveryDate.Value.ToString("dd/MM/yyyy") : "—",
                        QtyKg = linePdT.Sum(i => i.QtyKg),
                        Cartons = linePdT.Sum(i => i.PackageCount),
                        StatusAr = DocStatusAr(pd.Status) + " — استلام: " + ReceiptAr(pd.ReceiptStatus),
                        Detail = pd.BypassReason != null ? $"تجاوز موثق: {Trunc(pd.BypassReason, 80)}" : "صدر من فحص الجودة (المسار الرسمي)"
                    });
                }

                // استلام مخزن التام (سندات — قد تتكرر للجزئي)
                foreach (var fg in fgs.Where(f => f.OrderId == o.OrderId).ToList())
                {
                    var lineFg = fgItems.Where(i => i.ReceiptId == fg.Id && i.LotId != null && myLots.Contains(i.LotId!.Value));
                    line.Stages.Add(new JourneyStageRow
                    {
                        StageAr = $"{tag} · استلام مخزن التام",
                        DocNumber = fg.DocumentNumber,
                        DateText = fg.DeliveryDate != null ? fg.DeliveryDate.Value.ToString("dd/MM/yyyy") : "—",
                        QtyKg = lineFg.Sum(i => i.ReceivedQtyKg > 0 ? i.ReceivedQtyKg : i.NetWeightKg),
                        Cartons = lineFg.Sum(i => i.PackageCount),
                        StatusAr = ReceiptAr(fg.ReceiptStatus),
                        Detail = $"المخزن: {warehouses.TryGetValue(fg.WarehouseId, out var wh) ? wh : "-"} — " +
                                 $"أمين المخزن: {UserName(users, fg.WarehouseKeeperId)} — " +
                                 $"بنود استلام منفذة: {fg.ReceiveCount}"
                    });
                }
            }

            // ── تسليمات العميل الخاصة بهذه الشحنة ──
            var myCds = cds.Where(c => c.CustomerId == line.CustomerId
                && cdItems.Any(i => i.DeliveryId == c.Id && i.ProductId == line.ProductId
                    && ((i.LotId != null && myLots.Contains(i.LotId.Value)) || (c.OrderId != null && myOrderIds.Contains(c.OrderId.Value))))
                ).ToList();
            for (int m = 0; m < myCds.Count; m++)
            {
                var cd = myCds[m];
                var items = cdItems.Where(i => i.DeliveryId == cd.Id && i.ProductId == line.ProductId
                    && ((i.LotId != null && myLots.Contains(i.LotId.Value)) || (cd.OrderId != null && myOrderIds.Contains(cd.OrderId.Value)))).ToList();
                var qty = items.Sum(i => i.QtyKg);
                var ctns = items.Sum(i => i.PackageCount);
                var invoicedShare = cd.TotalQtyKg > 0 ? cd.InvoicedQtyKg * qty / cd.TotalQtyKg : 0;
                line.InvoicedKg += invoicedShare;
                line.DeliveredCartons += cd.IsApproved ? ctns : 0;
                if (cd.IsApproved && cd.DeliveryDate != null)
                    line.LastDeliveryDate = line.LastDeliveryDate == null || cd.DeliveryDate.Value > line.LastDeliveryDate.Value
                        ? cd.DeliveryDate : line.LastDeliveryDate;
                line.Stages.Add(new JourneyStageRow
                {
                    StageAr = $"تسليم {m + 1} — إلى العميل",
                    DocNumber = cd.DocumentNumber,
                    DateText = cd.DeliveryDate != null ? cd.DeliveryDate.Value.ToString("dd/MM/yyyy") : "—",
                    QtyKg = qty,
                    Cartons = ctns,
                    StatusAr = cd.IsApproved ? $"مُعتمد — {DocStatusAr(cd.Status)}" : DocStatusAr(cd.Status),
                    Detail = $"اعتماد: {(cd.ApprovedDate != null ? $"{cd.ApprovedDate:dd/MM/yyyy HH:mm} ({UserName(users, cd.ApprovedBy)})" : "—")} — " +
                             $"فُوتر (نظام المبيعات): {invoicedShare:N0} كجم — متبقي للفوترة: {Math.Max(0, qty - invoicedShare):N0} كجم"
                });
            }

            // ── الحالة النهائية + أيام الدورة ──
            line.ReceivedKg = fgItems.Where(i => i.LotId != null && myLots.Contains(i.LotId!.Value)
                && i.CustomerId == line.CustomerId && i.ProductId == line.ProductId)
                .Sum(i => i.ReceivedQtyKg > 0 ? i.ReceivedQtyKg : i.NetWeightKg);
            ComputeFinalStatus(line);
            if (line.LastDeliveryDate != null && line.PlanApprovedDate != null)
                line.CycleDays = (int)Math.Ceiling((line.LastDeliveryDate.Value - line.PlanApprovedDate.Value).TotalDays);

            result.Add(line);
        }
        return result;
    }

    private static void ComputeFinalStatus(ShipmentJourneyLine l)
    {
        double planned = l.PlannedKg;
        if (l.DeliveredKg >= planned - 0.001 && planned > 0)
        { l.StatusIcon = "✅"; l.FinalStatusAr = $"سلّمت تاماً ({l.DeliveredKg:N0} كجم)"; return; }
        if (l.DeliveredKg > 0)
        { l.StatusIcon = "⏳"; l.FinalStatusAr = $"جزئي: {l.DeliveredKg:N0} من {planned:N0} كجم"; return; }
        if (l.AcceptedKg > 0)
        { l.StatusIcon = "🟡"; l.FinalStatusAr = $"بانتظار التسليم ({l.AcceptedKg:N0} كجم مقبول)"; return; }
        if (l.ProducedKg > 0)
        { l.StatusIcon = "🔍"; l.FinalStatusAr = $"بانتظار الجودة ({l.ProducedKg:N0} كجم منتج)"; return; }
        l.StatusIcon = "⚪"; l.FinalStatusAr = "لم تبدأ بعد";
    }

    private static string UserName(Dictionary<int, string> users, int? id)
        => id != null && users.TryGetValue(id.Value, out var n) ? n : "—";

    private static string ShiftLineText(Dictionary<int, string> shifts, Dictionary<int, string> lines, int? shift, int? line)
    {
        var s = shift != null && shifts.TryGetValue(shift.Value, out var sn) ? sn : null;
        var l = line != null && lines.TryGetValue(line.Value, out var ln) ? ln : null;
        if (s == null && l == null) return "—";
        return s == null ? $"خط: {l}" : l == null ? $"وردية: {s}" : $"وردية: {s} · خط: {l}";
    }

    private static string DecisionAr(string d) => d switch
    {
        "Passed" => "ناجح ✓",
        "Failed" => "مرفوض ✗",
        "ConditionalPassed" => "ناجح بشروط",
        _ => d ?? "—"
    };

    private static string ReceiptAr(string s) => s switch
    {
        "None" => "لم يُستلم بعد",
        "Partial" => "استلام جزئي ◐",
        "Full" => "استلام كامل ✓",
        _ => s ?? "—"
    };

    private static string DocStatusAr(string s) => s switch
    {
        "Draft" => "مسودة",
        "Submitted" => "مقدم",
        "Approved" => "معتمد",
        "Issued" => "مُحرَّر",
        "Scheduled" => "مجدول",
        "InProgress" => "قيد التنفيذ",
        "Stopped" => "موقوف",
        "Completed" => "مكتمل",
        "Closed" => "مقفل",
        "Cancelled" => "ملغي",
        "PendingDelivery" => "بانتظار تسليم العميل",
        _ => s ?? "—"
    };

    private static string Trunc(string s, int max)
        => string.IsNullOrWhiteSpace(s) ? "" : s.Length > max ? s[..max] + "…" : s;
}
