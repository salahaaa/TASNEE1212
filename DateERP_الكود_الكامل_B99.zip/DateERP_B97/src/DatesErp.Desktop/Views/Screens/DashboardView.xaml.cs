using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DatesErp.Core.Common;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Screens;
using DatesErp.Desktop.Services;
using DatesErp.Desktop.Views;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Desktop.Views.Screens;

/// <summary>
/// §B97 — الشاشة الرئيسية: «مهامي».
/// الموظف لا يبحث عن عمله — النظام يعرضه له: ثلاثة أعمدة (بانتظار إجرائي/قيد المسار/أُنجز اليوم)
/// + تنبيهات حرجة. بطاقة ← نقرتان ← نافذة تفاصيل كاملة ← إجراء المرحلة. بلا «إضافة/بحث».
/// </summary>
public partial class DashboardView : UserControl
{
    private readonly string _deptFilter;

    public DashboardView(string deptFilter = null)
    {
        InitializeComponent();
        _deptFilter = deptFilter;
        Loaded += (_, _) => Load();
    }

    private void Load()
    {
        try
        {
            DashDate.Text = "التاريخ: " + DateTime.Now.ToString("dd/MM/yyyy");
            var session0 = AppContainer.Get<Infrastructure.Session.SessionContext>();
            DashUser.Text = session0.UserName ?? "—";
            FootUser.Text = session0.UserName ?? "—";
            // §B84/D1: تسمية الاتصال حية
            try
            {
                using var scope0 = AppContainer.NewScope();
                var db0 = (DatesErpDbContext)scope0.ServiceProvider.GetService(typeof(DatesErpDbContext));
                FootDb.Text = db0 != null && db0.Database.IsSqlServer()
                    ? "قاعدة البيانات: SQL Server المركزية" : "قاعدة البيانات: محلية (SQLite)";
            }
            catch { FootDb.Text = "قاعدة البيانات: محلية"; }

            // أزرار الإدارات في شريط الأدوات
            if (DeptToolbar.Children.Count == 0)
            {
                foreach (var dept in ScreenCatalog.Departments)
                {
                    var b = new Button { Content = $"{dept.Icon} {dept.Title}", Style = (Style)System.Windows.Application.Current.FindResource("ErpButton"), Margin = new Thickness(2, 0, 2, 0) };
                    var did = dept.Id;
                    b.Click += (_, _) => ((MainWindow)Window.GetWindow(this))?.OpenDeptDashboardPublic(did);
                    DeptToolbar.Children.Add(b);
                }
                var home = new Button { Content = "🏠 الرئيسية", Style = (Style)System.Windows.Application.Current.FindResource("ErpPrimaryButton"), Margin = new Thickness(2, 0, 2, 0) };
                home.Click += (_, _) => ((MainWindow)Window.GetWindow(this))?.OpenScreen("dashboard");
                DeptToolbar.Children.Add(home);
            }

            RenderBoard();

            // ── محتوى الإدارات: شبكة شاشات الإدارة المحددة أو بطاقات الإدارات ──
            DeptArea.Children.Clear();
            if (_deptFilter != null)
            {
                DeptArea.Children.Add(BuildDeptScreenGrid(_deptFilter));
            }
            else
            {
                DeptArea.Children.Add(new TextBlock
                {
                    Text = "📂 إدارات وأقسام النظام — اختر الإدارة لفتح شاشاتها ونوافذها الفرعية",
                    FontSize = 12, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(Color.FromRgb(0x0A, 0x24, 0x6A)),
                    Margin = new Thickness(0, 0, 0, 10)
                });
                var tiles = new WrapPanel();
                foreach (var dept in ScreenCatalog.Departments)
                {
                    var count = ScreenCatalog.All.Count(s => s.Group == dept.Title);
                    var tile = new Border
                    {
                        Background = Brushes.White,
                        BorderBrush = new SolidColorBrush(Color.FromRgb(0x7F, 0x9D, 0xB9)),
                        BorderThickness = new Thickness(1.5),
                        Padding = new Thickness(16, 14, 16, 14),
                        Width = 300,
                        Margin = new Thickness(0, 0, 12, 12),
                        Cursor = Cursors.Hand
                    };
                    var tileIcon = new Border
                    {
                        Width = 44, Height = 44, Background = new SolidColorBrush(Color.FromRgb(0xDC, 0xE6, 0xF1)),
                        BorderBrush = new SolidColorBrush(Color.FromRgb(0x7F, 0x9D, 0xB9)), BorderThickness = new Thickness(1),
                        Child = new TextBlock { Text = dept.Icon, FontSize = 24, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center }
                    };
                    DockPanel.SetDock(tileIcon, Dock.Right);
                    var tileArrow = new TextBlock { Text = "⬅", FontSize = 14, FontWeight = FontWeights.Bold,
                        Foreground = new SolidColorBrush(Color.FromRgb(0x0A, 0x24, 0x6A)),
                        VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 0, 0) };
                    DockPanel.SetDock(tileArrow, Dock.Left);
                    var tileInfo = new StackPanel { Margin = new Thickness(12, 0, 0, 0) };
                    tileInfo.Children.Add(new TextBlock { Text = dept.Title, FontSize = 13.5, FontWeight = FontWeights.Bold,
                        Foreground = new SolidColorBrush(Color.FromRgb(0x0A, 0x24, 0x6A)) });
                    tileInfo.Children.Add(new TextBlock { Text = $"عدد الشاشات: {count} شاشات فرعية", FontSize = 11,
                        Foreground = new SolidColorBrush(Color.FromRgb(0x55, 0x55, 0x55)), Margin = new Thickness(0, 2, 0, 0) });
                    var tilePanel = new DockPanel();
                    tilePanel.Children.Add(tileIcon);
                    tilePanel.Children.Add(tileArrow);
                    tilePanel.Children.Add(tileInfo);
                    tile.Child = tilePanel;
                    var deptId = dept.Id;
                    tile.MouseLeftButtonUp += (_, _) => ((MainWindow)Window.GetWindow(this))?.OpenDeptDashboardPublic(deptId);
                    tile.MouseEnter += (_, _) => tile.Background = new SolidColorBrush(Color.FromRgb(0xE8, 0xEE, 0xF7));
                    tile.MouseLeave += (_, _) => tile.Background = Brushes.White;
                    tiles.Children.Add(tile);
                }
                DeptArea.Children.Add(tiles);
            }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Dashboard"); }
    }

    // ═══════════════════════════════════════════════════════════
    // §B97 — مركز المهام
    // ═══════════════════════════════════════════════════════════

    private void RenderBoard()
    {
        using var scope = AppContainer.NewScope();
        var session = AppContainer.Get<Infrastructure.Session.SessionContext>();
        var tc = scope.ServiceProvider.GetRequiredService<ITaskCenterService>();
        var board = tc.GetBoard();

        TaskUserChip.Text = $"المستخدم: {session.UserName ?? "—"} | {board.RoleAr}";

        // التنبيهات الحرجة
        AlertsPanel.Children.Clear();
        if (board.Alerts.Count > 0)
        {
            AlertsPanel.Children.Add(new TextBlock
            {
                Text = "⚠ تنبيهات تشغيلية",
                FontWeight = FontWeights.ExtraBold,
                FontSize = 12.5,
                Foreground = new SolidColorBrush(Color.FromRgb(0x99, 0x1B, 0x1B)),
                Margin = new Thickness(0, 0, 0, 4)
            });
            foreach (var a in board.Alerts)
            {
                var (bg, br, fg) = AlertColors(a);
                AlertsPanel.Children.Add(AlertCard(a, bg, br, fg));
            }
        }

        // الأعمدة الثلاثة
        RenderColumn(ActionPanel, ActionHead, board.Action, "🔴 بانتظار إجرائي", "لا شيء بانتظارك — كل المهام في وقتها 🟢");
        RenderColumn(InFlightPanel, InFlightHead, board.InFlight, "🟠 قيد المسار / متوقف", "لا مهام في المسار حالياً");
        RenderColumn(DonePanel, DoneHead, board.DoneToday, "🟢 أُنجز اليوم", "لم يُنجز شيء مسجلاً بعد اليوم");
    }

    private void RenderColumn(StackPanel panel, TextBlock head, List<TaskCardDto> cards, string title, string empty)
    {
        head.Text = $"{title} ({cards.Count})";
        panel.Children.Clear();
        if (cards.Count == 0)
        {
            panel.Children.Add(new TextBlock
            {
                Text = empty,
                FontSize = 11.5,
                Foreground = new SolidColorBrush(Color.FromRgb(0x64, 0x74, 0x8B)),
                Margin = new Thickness(4, 8, 4, 4),
                TextWrapping = TextWrapping.Wrap
            });
            return;
        }
        foreach (var c in cards)
        {
            var card = TaskCard(c);
            var captured = c;
            // §B97 — النمط الموحد: نقرتان ← التفاصيل الكاملة ← إجراء المرحلة
            card.MouseDoubleClick += (_, _) => OpenCard(captured);
            panel.Children.Add(card);
        }
    }

    private UIElement TaskCard(TaskCardDto c)
    {
        var b = new Border
        {
            Background = c.Overdue ? new SolidColorBrush(Color.FromRgb(0xFE, 0xF2, 0xF2)) : Brushes.White,
            BorderBrush = c.Overdue ? new SolidColorBrush(Color.FromRgb(0xF8, 0x71, 0x71)) : new SolidColorBrush(Color.FromRgb(0xE2, 0xE8, 0xF0)),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(6),
            Padding = new Thickness(10, 8, 10, 8),
            Margin = new Thickness(0, 0, 0, 6),
            Cursor = Cursors.Hand
        };
        var sp = new StackPanel();

        var headLine = new StackPanel { Orientation = Orientation.Horizontal };
        headLine.Children.Add(new TextBlock
        {
            Text = c.Title + (c.Overdue ? "  ⏰" : ""),
            FontSize = 12,
            FontWeight = FontWeights.Bold,
            Foreground = c.Overdue ? new SolidColorBrush(Color.FromRgb(0xB9, 0x1C, 0x1C)) : new SolidColorBrush(Color.FromRgb(0x1E, 0x29, 0x3B)),
            TextWrapping = TextWrapping.Wrap
        });
        sp.Children.Add(headLine);

        if (!string.IsNullOrWhiteSpace(c.Subtitle))
            sp.Children.Add(new TextBlock
            {
                Text = c.Subtitle,
                FontSize = 11,
                Foreground = new SolidColorBrush(Color.FromRgb(0x47, 0x55, 0x69)),
                Margin = new Thickness(0, 3, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });

        var meta = new List<string>();
        if (!string.IsNullOrWhiteSpace(c.Sender)) meta.Add(c.Sender);
        if (!string.IsNullOrWhiteSpace(c.DocNumber)) meta.Add($"المستند: {c.DocNumber}");
        if (!string.IsNullOrWhiteSpace(c.Due)) meta.Add($"المستحق: {c.Due}");
        if (meta.Count > 0)
            sp.Children.Add(new TextBlock
            {
                Text = string.Join("  |  ", meta),
                FontSize = 10.5,
                Foreground = new SolidColorBrush(Color.FromRgb(0x64, 0x74, 0x8B)),
                Margin = new Thickness(0, 3, 0, 0)
            });

        if (!string.IsNullOrWhiteSpace(c.Reason))
            sp.Children.Add(new TextBlock
            {
                Text = "⚠️ " + c.Reason,
                FontSize = 11,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(Color.FromRgb(0x99, 0x1B, 0x1B)),
                Margin = new Thickness(0, 4, 0, 0),
                TextWrapping = TextWrapping.Wrap
            });

        b.Child = sp;
        return b;
    }

    /// <summary>
    /// §B97/B98 — نمط النقر المزدوج:
    /// «تشغيل اليوم/متعثر» ← نافذة تشغيل اليوم (إدخال يدوي موجّه)؛ خطة ← نافذتها الغنية (اعتماد/إرجاع)؛
    /// أمر تشغيل ← نافذة الأمر (بدء/إيقاف/إقفال اليوم)؛ وغير ذلك ← نافذة التفاصيل العامة.
    /// </summary>
    private void OpenCard(TaskCardDto c)
    {
        try
        {
            var owner = Window.GetWindow(this);
            if (c.DocType == "Plan" && c.Action == "RunDay")
            {
                var w = new DayRunWindow(c.DocId, c.Due) { Owner = owner };
                w.ShowDialog();
            }
            else if (c.DocType == "Plan")
            {
                var w = new PlanDetailWindow(c.DocId) { Owner = owner };
                w.ShowDialog();
            }
            else if (c.DocType == "Order")
            {
                var w = new OrderDetailWindow(c.DocId) { Owner = owner };
                w.ShowDialog();
            }
            else if (c.DocType == "QC")
            {
                var w = new QCWindow(c.DocId) { Owner = owner };
                w.ShowDialog();
            }
            else if (c.DocType == "Delivery")
            {
                var w = ReceiptWindow.FromDelivery(c.DocId) { Owner = owner };
                w.ShowDialog();
            }
            else if (c.DocType == "Receipt")
            {
                var w = ReceiptWindow.FromReceipt(c.DocId) { Owner = owner };
                w.ShowDialog();
            }
            else
            {
                // تسليم/فاتورة العميل — نظام البيع نظام خاص به (قرار المستخدم)؛ العرض هنا للقراءة فقط
                var w = new DocDetailWindow(c.DocType, c.DocId, c.DocNumber) { Owner = owner };
                w.ShowDialog();
            }
            Load(); // انعكس الإجراء — أعد رسم اللوحة
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Dashboard.OpenCard"); }
    }

    private static (string bg, string border, string fg) AlertColors(string text)
    {
        if (text.StartsWith("⏰") || text.StartsWith("⛔") || text.StartsWith("🚫") || text.StartsWith("🛡️"))
            return ("#FEF2F2", "#FCA5A5", "#991B1B");
        if (text.StartsWith("🧾")) return ("#FFFBEB", "#FDE68A", "#92400E");
        return ("#FFF7ED", "#FDBA74", "#9A3412");
    }

    // ═══════════════════════════════════════════════════════════

    private UIElement BuildDeptScreenGrid(string deptId)
    {
        var dept = ScreenCatalog.Departments.FirstOrDefault(d => d.Id == deptId);
        var color = (Color)ColorConverter.ConvertFromString(dept?.Color ?? "#14532D");
        var head = new StackPanel { Margin = new Thickness(0, 0, 0, 10) };
        var deptHead = new StackPanel { Orientation = Orientation.Horizontal };
        deptHead.Children.Add(new TextBlock { Text = dept.Icon, FontSize = 16, VerticalAlignment = VerticalAlignment.Center });
        deptHead.Children.Add(new TextBlock { Text = "  " + dept.Title, FontSize = 14.5, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(color), VerticalAlignment = VerticalAlignment.Center });
        head.Children.Add(new Border
        {
            BorderThickness = new Thickness(5, 0, 0, 0),
            BorderBrush = new SolidColorBrush(color),
            Background = Brushes.White,
            Padding = new Thickness(12, 10, 12, 10),
            Child = deptHead
        });

        var grid = new WrapPanel { Margin = new Thickness(0, 10, 0, 0) };
        foreach (var s in ScreenCatalog.All.Where(x => x.Group == dept.Title && x.Code != "dashboard"))
        {
            var card = new Border
            {
                Background = Brushes.White,
                BorderBrush = new SolidColorBrush(Color.FromRgb(0xE2, 0xE8, 0xF0)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(12, 9, 12, 9),
                Width = 230,
                Margin = new Thickness(0, 0, 10, 10),
                Cursor = Cursors.Hand
            };
            var cardIcon = new TextBlock { Text = s.Icon + "  ", FontSize = 12.5, VerticalAlignment = VerticalAlignment.Center };
            DockPanel.SetDock(cardIcon, Dock.Right);
            var cardOpen = new TextBlock { Text = "فتح ⬅", FontSize = 10, Foreground = new SolidColorBrush(Color.FromRgb(0x0A, 0x24, 0x6A)), VerticalAlignment = VerticalAlignment.Center };
            DockPanel.SetDock(cardOpen, Dock.Left);
            var cardTitle = new TextBlock { Text = s.Title, FontSize = 12.5, FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(0x1E, 0x29, 0x3B)), VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis };
            var cardPanel = new DockPanel();
            cardPanel.Children.Add(cardIcon);
            cardPanel.Children.Add(cardOpen);
            cardPanel.Children.Add(cardTitle);
            card.Child = cardPanel;
            var code = s.Code;
            card.MouseLeftButtonUp += (_, _) => ((MainWindow)Window.GetWindow(this))?.OpenScreen(code);
            card.MouseEnter += (_, _) => { card.BorderBrush = new SolidColorBrush(Color.FromRgb(0x14, 0x53, 0x2D)); card.Background = new SolidColorBrush(Color.FromRgb(0xF8, 0xFA, 0xFC)); };
            card.MouseLeave += (_, _) => { card.BorderBrush = new SolidColorBrush(Color.FromRgb(0xE2, 0xE8, 0xF0)); card.Background = Brushes.White; };
            grid.Children.Add(card);
        }
        head.Children.Add(grid);
        return head;
    }

    /// <summary>§بطاقة تنبيه — شريط ملوّن بنص التحذير.</summary>
    private UIElement AlertCard(string text, string bg, string border, string fg)
    {
        var b = new Border
        {
            Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString(bg)),
            BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(border)),
            BorderThickness = new Thickness(1.2),
            CornerRadius = new CornerRadius(6),
            Padding = new Thickness(10, 7, 10, 7),
            Margin = new Thickness(0, 0, 0, 5)
        };
        b.Child = new TextBlock
        {
            Text = text,
            TextWrapping = TextWrapping.Wrap,
            FontSize = 11.5,
            FontWeight = FontWeights.Bold,
            Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(fg))
        };
        return b;
    }
}
