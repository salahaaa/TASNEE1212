using DatesErp.Application.Services;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace DatesErp.Tests;

/// <summary>
/// §B57 — شاشة الإقفال: كمية الفحص اختيار المستخدم وتُحفظ، والمخرج الثانوي يضيفه المستخدم بلا ثوابت.
/// </summary>
public class ExecutionB57Tests
{
    private static DatesErpDbContext Db(TestHost host)
        => new DatesErpDbContext(new DbContextOptionsBuilder<DatesErpDbContext>().UseSqlite(host.Connection).Options);

    private static (int planId, int planItemId) BuildApprovedPlan(TestHost host)
    {
        var scope = host.Services.CreateScope();
        var master = scope.ServiceProvider.GetRequiredService<MasterDataService>();
        var plan = scope.ServiceProvider.GetRequiredService<IPlanningService>();
        var rcv = scope.ServiceProvider.GetRequiredService<IReceivingService>();
        var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();

        var cust = master.SaveCustomer(null, "B57-C", "عميل الإقفال", "جملة", "777", "-", true);
        var raw = master.SaveProductFull(null, "001-B57", "خام الإقفال", "001", "Raw", "كجم", 20, 0, 0, null);
        var fin = master.SaveProductFull(null, "002-B57", "تام الإقفال", "002", "Finished", "كرتون", 10, 5, 2,
            new System.Collections.Generic.List<(int, int?, int)> { (1, null, 4000) }, raw.Id);
        var sh = rcv.SaveShipment(cust.Id, null, null, new System.Collections.Generic.List<ShipmentItemDto>
        { new() { ProductId = raw.Id, QtyKg = 50000, PackageCount = 2500, UnitWeightKg = 20 } });
        rcv.ApproveShipment(sh.Id);
        int lot = db.Lots.AsNoTracking().Where(l => l.ShipmentId == sh.Id).Select(l => l.Id).First();
        var r = plan.SavePlan("خطة B57", "Daily", "2026-09-01", "2026-09-01", 1, 1,
            new System.Collections.Generic.List<PlanItemDto>
            {
                new() { SourceType = "FromReceiving", LotId = lot, CustomerId = cust.Id,
                        ProductId = fin.Id, PlannedCartons = 1000, PlannedQtyKg = 10000, PriorityNo = 1 }
            });
        Assert.True(r.Ok, r.Message);
        Assert.True(plan.ApprovePlan(r.Id).Ok);
        int item = db.ProductionPlanItems.AsNoTracking().Where(i => i.PlanId == r.Id).Select(i => i.Id).First();
        return (r.Id, item);
    }

    [Fact]
    public void Closing_Stores_User_Chosen_Quality_Quantity()
    {
        using var host = new TestHost();
        host.LoginAsAdmin();
        var (planId, itemId) = BuildApprovedPlan(host);
        var svc = host.Services.CreateScope().ServiceProvider.GetRequiredService<IExecutionService>();

        var res = svc.ClosePlanItems(planId,
            new System.Collections.Generic.List<PlanClosingItemDto>
            {
                new() { PlanItemId = itemId, ProducedKg = 5000, ProducedCartons = 500, WastageKg = 10 }
            },
            true, new System.Collections.Generic.List<DowntimeDto>(), null, null, null, null, 4321.5);
        Assert.True(res.Ok, res.Message);

        using var db = Db(host);
        var closing = db.PlanClosings.AsNoTracking().OrderByDescending(c => c.Id).First();
        Assert.Equal(4321.5, closing.SentToQualityKg);   // اختيار المستخدم لا تقدير النظام
    }

    [Fact]
    public void Closing_Without_User_Quantity_Falls_Back_To_Produced_Total()
    {
        using var host = new TestHost();
        host.LoginAsAdmin();
        var (planId, itemId) = BuildApprovedPlan(host);
        var svc = host.Services.CreateScope().ServiceProvider.GetRequiredService<IExecutionService>();

        var res = svc.ClosePlanItems(planId,
            new System.Collections.Generic.List<PlanClosingItemDto>
            {
                new() { PlanItemId = itemId, ProducedKg = 3000, ProducedCartons = 300 }
            },
            true, new System.Collections.Generic.List<DowntimeDto>());
        Assert.True(res.Ok, res.Message);

        using var db = Db(host);
        var closing = db.PlanClosings.AsNoTracking().OrderByDescending(c => c.Id).First();
        Assert.Equal(3000, closing.SentToQualityKg);    // فارغ = إجمالي المنتَج
    }

    [Fact]
    public void User_Can_Add_A_ByProduct_With_No_Duplicates()
    {
        using var host = new TestHost();
        host.LoginAsAdmin();
        var master = host.Services.CreateScope().ServiceProvider.GetRequiredService<MasterDataService>();

        var r = master.SaveByProduct(null, "مخلفات فرز", "كجم");
        Assert.True(r.Ok, r.Message);
        var dup = master.SaveByProduct(null, "مخلفات فرز", "كجم");
        Assert.False(dup.Ok);                       // التكرار مرفوض
        Assert.Contains("بنفس الاسم", dup.Message);

        using var db = Db(host);
        Assert.Contains(db.ByProducts.AsNoTracking().ToList(), b => b.ByProductNameAr == "مخلفات فرز" && b.IsActive);
    }

    // §B78: شاشة الإقفال حُذفت لإعادة التصميم من الصفر — يُعاد حارس حقول التوقف مع الشاشة الجديدة
}
