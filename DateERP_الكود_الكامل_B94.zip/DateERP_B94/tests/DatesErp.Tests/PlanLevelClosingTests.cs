using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Domain.Enums;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace DatesErp.Tests;

/// <summary>
/// اختبارات الإقفال على مستوى الخطة: تسليم الخطة كاملة بأصنافها أو صنف واحد أو جزء من صنف،
/// والتحقق أن المتبقي يُعاد لمخزن الخام بنفس العميل والدفعة (حركة مرتجع) وأن حجزه يتحرر —
/// فلا يوجد «حجز فوق حجز» — وأن الفحص يُرسل (تبريد يومان) للخطة اليومية والفترية.
/// </summary>
public class PlanLevelClosingTests
{
    /// <summary>خطة بعميلين وبندين + أمر تشغيل معتمد لكل بند (خصم الخام مسبقاً).</summary>
    private static (TestHost host, int planId, int itemA, int itemB, int lotA, int lotB) SeedTwoItemPlan()
    {
        var host = new TestHost();
        host.LoginAsAdmin();
        using var scope = host.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
        var receiving = scope.ServiceProvider.GetRequiredService<IReceivingService>();
        var planning = scope.ServiceProvider.GetRequiredService<IPlanningService>();
        var orders = scope.ServiceProvider.GetRequiredService<IProductionOrderService>();

        // مواد مساعدة كافية
        var whAux = db.Warehouses.Single(w => w.WarehouseCode == "WAUX").Id;
        db.StockBalances.AddRange(
            new StockBalance { WarehouseId = whAux, MaterialId = 1, QtyKg = 100000 },
            new StockBalance { WarehouseId = whAux, MaterialId = 2, QtyKg = 100000 });

        // عميل ثانٍ وشحنتان (دفعتان لعميلين مختلفين)
        db.Customers.Add(new Customer { CustomerCode = "CX2", CustomerName = "عميل ثانٍ", IsActive = true });
        db.SaveChanges();
        int cust2 = db.Customers.Single(c => c.CustomerCode == "CX2").Id;

        var s1 = receiving.SaveShipment(1, null, null, new List<ShipmentItemDto>
        { new() { ProductId = 1, PackagingTypeId = 1, PackageCount = 1, UnitWeightKg = 10000, QtyKg = 10000 } });
        Assert.True(receiving.ApproveShipment(s1.Id).Ok);
        // §تتبع الصنف: دفعة العميل الثاني من خام سكري (2) لتطابق المنتج المخطط لها (4 = سكري)
        var s2 = receiving.SaveShipment(cust2, null, null, new List<ShipmentItemDto>
        { new() { ProductId = 2, PackagingTypeId = 1, PackageCount = 1, UnitWeightKg = 6000, QtyKg = 6000 } });
        Assert.True(receiving.ApproveShipment(s2.Id).Ok);
        var lotsList = db.Lots.OrderBy(l => l.Id).ToList();
        int lotA = lotsList[^2].Id;
        int lotB = lotsList[^1].Id;

        string day = DateTime.Today.AddDays(1).ToString("dd/MM/yyyy");
        var plan = planning.SavePlan("خطة الإقفال على مستويين", "Period", day, day, 1, 1, new List<PlanItemDto>
        {
            new() { SourceType = "FromReceiving", LotId = lotA, CustomerId = 1, ProductId = 3, PackagingTypeId = 1,
                    PlannedQtyKg = 10000, PlannedCartons = 2000, ScheduledDate = day, SuggestedShiftId = 1, SuggestedLineId = 1, PriorityNo = 1 },
            new() { SourceType = "FromReceiving", LotId = lotB, CustomerId = cust2, ProductId = 4, PackagingTypeId = 1,
                    PlannedQtyKg = 6000, PlannedCartons = 1200, ScheduledDate = day, SuggestedShiftId = 1, SuggestedLineId = 1, PriorityNo = 2 }
        });
        Assert.True(plan.Ok, plan.Message);
        Assert.True(planning.ApprovePlan(plan.Id).Ok);
        var itemIds = db.ProductionPlanItems.Where(i => i.PlanId == plan.Id).OrderBy(i => i.PriorityNo).Select(i => i.Id).ToList();

        // أمر لكل عميل (الاستخدام الصحيح: الأمر لعميل واحد ودفعة عميله)
        var order1 = orders.SaveOrder("FromPlan", plan.Id, 1, day, 1, 1, new List<OrderItemDto>
        {
            new() { PlanItemId = itemIds[0], LotId = lotA, CustomerId = 1, ProductId = 3, PackagingTypeId = 1, PlannedQtyKg = 10000, PlannedCartons = 2000 }
        });
        Assert.True(order1.Ok, order1.Message);
        var ao1 = orders.ApproveOrder(order1.Id); Assert.True(ao1.Ok, ao1.Message); // §B85/M7: الاعتماد لا يخصم الخام — يُصرف عند الإقفال

        var order2 = orders.SaveOrder("FromPlan", plan.Id, cust2, day, 1, 1, new List<OrderItemDto>
        {
            new() { PlanItemId = itemIds[1], LotId = lotB, CustomerId = cust2, ProductId = 4, PackagingTypeId = 1, PlannedQtyKg = 6000, PlannedCartons = 1200 }
        });
        Assert.True(order2.Ok, order2.Message);
        var ao2 = orders.ApproveOrder(order2.Id); Assert.True(ao2.Ok, ao2.Message);
        return (host, plan.Id, itemIds[0], itemIds[1], lotA, lotB);
    }

    [Fact]
    public void CloseWholePlan_ReturnsRemaindersToRaw_SendsQuality_AndAutoCloses()
    {
        var seed = SeedTwoItemPlan();
        using var host = seed.host;
        using var scope = host.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
        var exec = scope.ServiceProvider.GetRequiredService<IExecutionService>();

        double inStockA_before = db.Lots.AsNoTracking().Single(l => l.Id == seed.lotA).InStockQtyKg; // كامل (10,000) — الاعتماد لا يخصم الخام

        // إقفال البند الأول: 8000 إنتاج + 200 حشف + 100 نوى ← متبقي 1700 يُعاد للخام
        // إقفال البند الثاني كاملاً بكمياته الصريحة (§B85/H1: صفر الكيلو مع كراتين مرفوض — أدخل الكميات أو صفّر الكل للتحرير)
        var r = exec.ClosePlanItems(seed.planId, new List<PlanClosingItemDto>
        {
            new() { PlanItemId = seed.itemA, ProducedKg = 8000, ProducedCartons = 1600, HashfKg = 200, NawaKg = 100, WastageKg = 0 },
            new() { PlanItemId = seed.itemB, ProducedKg = 6000, ProducedCartons = 1200 }
        }, sendToQuality: true, downtimes: new List<DowntimeDto>
        { new() { Hours = 1, ReasonAr = "صيانة" } }, notes: "إقفال كامل");

        Assert.True(r.Ok, r.Message);

        // §B85/H1: الإقفال يصرف الخامه (10,000) ثم يعيد المتبقي (1,700) — الصافي −8,300 + حركة مرتجع موثقة
        double inStockA_after = db.Lots.AsNoTracking().Single(l => l.Id == seed.lotA).InStockQtyKg;
        Assert.Equal(inStockA_before - 8300, inStockA_after, 1);
        Assert.Contains(db.InventoryTransactions, t => t.ReferenceDocType == ReferenceDocType.Return
            && t.LotId == seed.lotA && t.QtyKg == 1700);


        // الفحص أُرسل لكل أمر متأثر (فترة تبريد يومان)
        var checks = db.QualityChecks.Where(c => c.ExpectedCheckDate != null).ToList();
        Assert.NotEmpty(checks);
        Assert.All(checks, c => Assert.Equal(DateTime.Today.AddDays(2), c.ExpectedCheckDate));

        // §B79: مكتملة ≠ مقفلة — الإقفال قرار صريح من شاشة إقفال خطة الإنتاج
        Assert.False(db.ProductionPlans.AsNoTracking().Single(p => p.Id == seed.planId).IsClosed);
        foreach (var oid in db.ProductionOrders.AsNoTracking().Where(o => o.SourcePlanId == seed.planId).Select(o => o.Id).ToList())
            Assert.True(host.Services.CreateScope().ServiceProvider.GetRequiredService<IProductionOrderService>().CloseOrder(oid).Ok);
        var cl = host.Services.CreateScope().ServiceProvider.GetRequiredService<IPlanClosureService>().ClosePlanFinal(seed.planId);
        Assert.True(cl.Ok, cl.Message);
        Assert.True(db.ProductionPlans.AsNoTracking().Single(p => p.Id == seed.planId).IsClosed);
        // الحجوزات تحررت عند الإقفال الصريح
        Assert.Equal(0, db.Lots.AsNoTracking().Single(l => l.Id == seed.lotA).ReservedQtyKg, 1);
        Assert.Equal(0, db.Lots.AsNoTracking().Single(l => l.Id == seed.lotB).ReservedQtyKg, 1);

        // مستند الإقفال يحفظ حساب كل بند
        var closing = db.PlanClosings.Include(c => c.Items).Include(c => c.Downtimes).Single();
        Assert.Equal(2, closing.Items.Count);
        var ci = closing.Items.Single(i => i.PlanItemId == seed.itemA);
        Assert.Equal(10000, ci.ConsumedRawKg, 1);   // كم خاماً استُلم
        Assert.Equal(8000, ci.ProducedKg, 1);        // كم أُنتج تاماً
        Assert.Equal(1600, ci.ProducedCartons);      // كم كرتوناً
        Assert.Equal(200, ci.HashfKg, 1);            // مخرجات ثانوية
        Assert.Equal(1700, ci.ReturnedToRawKg, 1);   // المتبقي المُعاد
        Assert.Single(closing.Downtimes);
    }

    [Fact]
    public void CloseSingleItem_KeepsPlanOpen_OtherItemUnaffected()
    {
        var seed = SeedTwoItemPlan();
        using var host = seed.host;
        using var scope = host.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
        var exec = scope.ServiceProvider.GetRequiredService<IExecutionService>();

        // إقفال بند واحد فقط (الخطة فترية — تبقى مفتوحة للبند الآخر)
        var r = exec.ClosePlanItems(seed.planId, new List<PlanClosingItemDto>
        {
            new() { PlanItemId = seed.itemA, ProducedKg = 10000, ProducedCartons = 2000 }
        }, sendToQuality: false, downtimes: null);
        Assert.True(r.Ok, r.Message);

        var plan = db.ProductionPlans.AsNoTracking().Single(p => p.Id == seed.planId);
        Assert.False(plan.IsClosed); // لم تكتمل كل البنود
        var itemB = db.ProductionPlanItems.AsNoTracking().Single(i => i.Id == seed.itemB);
        Assert.Equal(6000, itemB.PlannedQtyKg, 1); // البند الآخر لم يُمس
        Assert.Equal(0, itemB.ProducedQtyKg, 1);
    }

    [Fact]
    public void ClosePartOfItem_ClosesItAtProduced_ReleasesRestOfReservation()
    {
        var seed = SeedTwoItemPlan();
        using var host = seed.host;
        using var scope = host.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
        var exec = scope.ServiceProvider.GetRequiredService<IExecutionService>();

        Assert.Equal(10000, db.Lots.AsNoTracking().Single(l => l.Id == seed.lotA).ReservedQtyKg, 1);

        // إقفال جزء من الصنف: 4000 من 10000 — والباقي يعود للخام ويُحرر حجزه
        var r = exec.ClosePlanItems(seed.planId, new List<PlanClosingItemDto>
        {
            new() { PlanItemId = seed.itemA, ProducedKg = 4000, ProducedCartons = 800 }
        }, sendToQuality: true, downtimes: null);
        Assert.True(r.Ok, r.Message);

        var itemA = db.ProductionPlanItems.AsNoTracking().Single(i => i.Id == seed.itemA);
        Assert.Equal(4000, itemA.ProducedQtyKg, 1);
        // §إصلاح: كان هذا الاختبار يؤكّد السلوك الخاطئ (المخطط يُخفَض للمنتَج فيضيع أساس الخطة
        // وتظهر 100% إنجاز دائماً). الآن المخطط محفوظ والإقفال بعلم IsClosed،
        // وما حُرر من الحجز موثق في ReleasedQtyKg — وتحرير الحجز نفسه ما زال مؤكَّداً أدناه.
        Assert.Equal(10000, itemA.PlannedQtyKg, 1);
        Assert.True(itemA.IsClosed);
        Assert.Equal(6000, itemA.ReleasedQtyKg, 1);

        // §قاعدة توازن الإنتاج: لا يُخصم الخام عند الاعتماد — يُصرف عند الإقفال فعلياً.
        // §B85/H1: صُرف (10,000) وعاد المتبقي (6,000) = 6,000 بلا حجز.
        Assert.Equal(6000, db.Lots.AsNoTracking().Single(l => l.Id == seed.lotA).InStockQtyKg, 1);
        Assert.Equal(0, db.Lots.AsNoTracking().Single(l => l.Id == seed.lotA).ReservedQtyKg, 1);
    }

    [Fact]
    public void ClosePlan_Guards_OverPlan_And_Negative()
    {
        var seed = SeedTwoItemPlan();
        using var host = seed.host;
        using var scope = host.Services.CreateScope();
        var exec = scope.ServiceProvider.GetRequiredService<IExecutionService>();

        var over = exec.ClosePlanItems(seed.planId, new List<PlanClosingItemDto>
        { new() { PlanItemId = seed.itemA, ProducedKg = 999999 } }, false, null);
        Assert.False(over.Ok);
        Assert.Contains("أكبر من المتبقي", over.Message);

        var neg = exec.ClosePlanItems(seed.planId, new List<PlanClosingItemDto>
        { new() { PlanItemId = seed.itemA, ProducedKg = -10 } }, false, null);
        Assert.False(neg.Ok);

        var empty = exec.ClosePlanItems(seed.planId, new List<PlanClosingItemDto>(), false, null);
        Assert.False(empty.Ok);
    }
}
