using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Exceptions;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

// ═══════════════════════════════════════════════════════════════
// §الفحص الديناميكي — أنواع نتائج قابلة للتعريف، وحدات من القاموس، وربط كامل بالأمر
// ═══════════════════════════════════════════════════════════════

/// <summary>
/// §خدمة الفحص الديناميكي — المصدر الوحيد لأنواع النتائج والوحدات والإجماليات.
/// لا يوجد هنا اسم نتيجة مثبّت ولا وحدة مثبّتة: كل شيء من الجداول.
/// </summary>
public class InspectionService : ServiceBase, IInspectionService
{
    public InspectionService(DatesErpDbContext db, ICurrentSession session, INumberingService numbering)
        : base(db, session, numbering) { }

    // ─────────────────────── أنواع النتائج (الإعدادات) ───────────────────────

    /// <summary>§3 — تعريف/تعديل نوع نتيجة فحص من الإعدادات (لا تعديل كود لإضافة نتيجة جديدة).</summary>
    public OpResult SaveResultType(int? id, string code, string nameAr, string resultKind,
        int? unitId, bool isFinishedGood, bool isByProduct, bool entersInventory,
        bool countsAsLoss, int sortNo, bool isActive, string notes = null)
    {
        Require("products", "Edit");
        if (string.IsNullOrWhiteSpace(nameAr)) return OpResult.Fail("اسم نوع النتيجة مطلوب.");

        return RunOp(() =>
        {
            // §التصنيف يُطبع داخل RunOp حتى يعود خطأً عربياً في OpResult لا استثناءً
            resultKind = NormalizeKind(resultKind);
            var t = id == null ? new InspectionResultType() : Db.InspectionResultTypes.FirstOrDefault(x => x.Id == id);
            if (id != null && t == null) throw new DomainException("نوع النتيجة غير موجود.");
            if (Db.InspectionResultTypes.Any(x => x.NameAr == nameAr && x.Id != t.Id))
                throw new DomainException($"يوجد نوع نتيجة بالاسم «{nameAr}» — اختر اسماً آخر.");

            // §4 — الوحدة من القاموس: لا نقبل وحدة غير معرفة، ولا نثبّت وحدة في الكود
            string unitLabel = null;
            if (unitId != null)
            {
                var u = Db.UnitsOfMeasure.AsNoTracking().FirstOrDefault(x => x.Id == unitId && x.IsActive);
                if (u == null) throw new DomainException("الوحدة المختارة غير موجودة في قاموس الوحدات أو موقوفة — عرّفها أولاً من نافذة الوحدات.");
                unitLabel = u.UnitNameAr;
            }

            t.Code = string.IsNullOrWhiteSpace(code) ? $"RT-{DateTime.Now:HHmmssfff}" : code.Trim();
            t.NameAr = nameAr.Trim();
            t.ResultKind = resultKind;
            t.UnitId = unitId;
            t.UnitLabel = unitLabel;
            t.IsFinishedGood = isFinishedGood;
            t.IsByProduct = isByProduct;
            t.EntersInventory = entersInventory;
            t.CountsAsLoss = countsAsLoss;
            t.SortNo = sortNo;
            t.IsActive = isActive;
            t.Notes = notes;
            if (id == null) Db.InspectionResultTypes.Add(t);
            Db.SaveChanges();
            return OpResult.Success($"تم حفظ نوع النتيجة «{t.NameAr}» ({InspectionResultType.KindNameAr(t.ResultKind)}) — سيظهر في استمارة الفحص.", t.Id, t.Code);
        });
    }

    /// <summary>كل أنواع النتائج النشطة مرتبة.</summary>
    public List<AllowedResultType> GetResultTypes(bool includeInactive = false)
    {
        var q = Db.InspectionResultTypes.AsNoTracking();
        if (!includeInactive) q = q.Where(t => t.IsActive);
        return q.OrderBy(t => t.SortNo).ThenBy(t => t.Id).ToList().Select(ToAllowed).ToList();
    }

    /// <summary>
    /// §7 — نتائج الفحص المسموحة لصنف معيّن بوحدتها المعتمدة.
    /// الأولوية: ملف الصنف ← ملف المجموعة ← الأنواع العامة النشطة.
    /// </summary>
    public List<AllowedResultType> GetAllowedResultTypesForItem(int? productId, string groupCode = null)
    {
        if (groupCode == null && productId != null)
            groupCode = Db.Products.AsNoTracking().Where(p => p.Id == productId).Select(p => p.GroupCode).FirstOrDefault();

        var profiles = Db.ItemInspectionProfiles.AsNoTracking().Where(p => p.IsActive).ToList();
        var types = Db.InspectionResultTypes.AsNoTracking().Where(t => t.IsActive)
            .OrderBy(t => t.SortNo).ThenBy(t => t.Id).ToList();

        // ملف خاص بالصنف
        var itemProfiles = productId != null ? profiles.Where(p => p.ProductId == productId).ToList() : new List<ItemInspectionProfile>();
        // ملف المجموعة (بلا صنف محدد)
        var groupProfiles = groupCode != null
            ? profiles.Where(p => p.ProductId == null && p.GroupCode == groupCode).ToList()
            : new List<ItemInspectionProfile>();

        var result = new List<AllowedResultType>();
        var used = new HashSet<int>();

        foreach (var set in new[] { itemProfiles, groupProfiles })
        {
            foreach (var pr in set.OrderBy(p => p.SortNo).ThenBy(p => p.Id))
            {
                var t = types.FirstOrDefault(x => x.Id == pr.ResultTypeId);
                if (t == null || used.Contains(t.Id)) continue;
                used.Add(t.Id);
                var a = ToAllowed(t);
                if (pr.UnitId != null)
                {
                    var u = Db.UnitsOfMeasure.AsNoTracking().FirstOrDefault(x => x.Id == pr.UnitId);
                    if (u != null) { a.UnitId = u.Id; a.UnitLabel = u.UnitNameAr; }
                }
                a.DefaultQty = (double)pr.DefaultQty;
                a.IsMandatory = pr.IsMandatory;
                a.SortNo = pr.SortNo;
                result.Add(a);
            }
        }

        // ما لم يُخصّص: كل الأنواع النشطة المتاحة للجميع
        foreach (var t in types.Where(t => !used.Contains(t.Id))) result.Add(ToAllowed(t));
        return result.OrderBy(a => a.SortNo).ThenBy(a => a.ResultTypeId).ToList();
    }

    /// <summary>§7 — تحديد نتائج الفحص المسموحة لصنف (إنشاء/تحديث).</summary>
    public OpResult SetProfile(int? id, int? productId, string groupCode, int resultTypeId,
        int? unitId, decimal defaultQty, bool isMandatory, int sortNo, bool isActive)
    {
        Require("products", "Edit");
        return RunOp(() =>
        {
            if (!Db.InspectionResultTypes.Any(t => t.Id == resultTypeId))
                throw new DomainException("نوع النتيجة غير موجود — عرّفه أولاً من «أنواع نتائج الفحص».");
            if (productId == null && string.IsNullOrWhiteSpace(groupCode))
                throw new DomainException("حدّد الصنف أو مجموعة الأصناف.");

            var p = id == null ? new ItemInspectionProfile() : Db.ItemInspectionProfiles.FirstOrDefault(x => x.Id == id);
            if (id != null && p == null) throw new DomainException("التعريف غير موجود.");
            if (Db.ItemInspectionProfiles.Any(x => x.Id != p.Id && x.ResultTypeId == resultTypeId
                    && x.ProductId == productId && x.GroupCode == groupCode))
                throw new DomainException("هذا النوع معرَّف مسبقاً لهذا الصنف/المجموعة.");

            p.ProductId = productId;
            p.GroupCode = groupCode;
            p.ResultTypeId = resultTypeId;
            p.UnitId = unitId;
            p.DefaultQty = defaultQty;
            p.IsMandatory = isMandatory;
            p.SortNo = sortNo;
            p.IsActive = isActive;
            if (id == null) Db.ItemInspectionProfiles.Add(p);
            Db.SaveChanges();
            return OpResult.Success("تم حفظ تعريف نتائج الفحص للصنف.", p.Id);
        });
    }

    /// <summary>تحويل وحدات معرَّف — بدونه لا يُجمع مقداران بوحدتين مختلفتين.</summary>
    public OpResult SaveConversion(int? id, int fromUnitId, int toUnitId, decimal factor, bool isActive)
    {
        Require("products", "Edit");
        if (fromUnitId == toUnitId) return OpResult.Fail("وحدة التحويل المصدر والهدف متطابقتان.");
        if (factor <= 0) return OpResult.Fail("معامل التحويل يجب أن يكون أكبر من صفر.");
        return RunOp(() =>
        {
            var c = id == null ? new UnitConversion() : Db.UnitConversions.FirstOrDefault(x => x.Id == id);
            if (id != null && c == null) throw new DomainException("التحويل غير موجود.");
            c.FromUnitId = fromUnitId;
            c.ToUnitId = toUnitId;
            c.Factor = factor;
            c.IsActive = isActive;
            if (id == null) Db.UnitConversions.Add(c);
            Db.SaveChanges();
            return OpResult.Success($"تم حفظ التحويل: 1 {UnitName(fromUnitId)} = {factor:0.####} {UnitName(toUnitId)}.", c.Id);
        });
    }

    // ─────────────────────── سياق الأمر (رأس الشاشة) ───────────────────────

    /// <summary>
    /// §1 — بيانات الفحص تُجلب آلياً من أمر الإنتاج: رقم الأمر، الخطة، العميل، الصنف الخام،
    /// المنتج التام، الكمية المنتجة، الوحدة، التاريخ، الوردية، خط الإنتاج — بلا إعادة إدخال.
    /// </summary>
    public InspectionOrderContext GetOrderContext(int orderId)
    {
        var o = Db.ProductionOrders.AsNoTracking().Include(x => x.Items).FirstOrDefault(x => x.Id == orderId);
        if (o == null) throw new DomainException("أمر الإنتاج غير موجود.");

        var ctx = new InspectionOrderContext
        {
            OrderId = o.Id,
            OrderNo = o.DocumentNumber,
            CustomerId = o.CustomerId,
            CustomerName = Db.Customers.AsNoTracking().Where(c => c.Id == o.CustomerId).Select(c => c.CustomerName).FirstOrDefault(),
            Date = (o.ProductionDate ?? DateTime.Today).ToString(Core.Common.UiFormat.DatePattern),
            ShiftName = Db.Shifts.AsNoTracking().Where(s => s.Id == o.ShiftId).Select(s => s.ShiftNameAr).FirstOrDefault(),
            LineName = Db.ProductionLines.AsNoTracking().Where(l => l.Id == o.LineId).Select(l => l.LineNameAr).FirstOrDefault(),
        };

        // §1 — الخطة من الأمر مباشرة (SourcePlanId) أو عبر بند الخطة المرتبط
        int? planId = o.SourcePlanId;
        if (planId == null)
        {
            var planItemId = o.Items.Select(i => i.PlanItemId).FirstOrDefault(x => x != null);
            if (planItemId != null)
                planId = Db.ProductionPlanItems.AsNoTracking().Where(i => i.Id == planItemId).Select(i => i.PlanId).FirstOrDefault();
        }
        if (planId != null)
            ctx.PlanNo = Db.ProductionPlans.AsNoTracking().Where(p => p.Id == planId).Select(p => p.DocumentNumber).FirstOrDefault();

        foreach (var it in o.Items)
        {
            var prod = Db.Products.AsNoTracking().FirstOrDefault(p => p.Id == it.ProductId);
            var lot = it.LotId != null ? Db.Lots.AsNoTracking().FirstOrDefault(l => l.Id == it.LotId) : null;
            double qty = it.ProducedQtyKg > 0 ? it.ProducedQtyKg : it.PlannedQtyKg;
            ctx.Items.Add((it.ProductId, prod?.ProductNameAr ?? "-", it.LotId, lot?.LotCode, it.CustomerId, qty));

            if (prod != null && prod.ItemType == "Finished" && ctx.FinishedProductId == null)
            {
                ctx.FinishedProductId = prod.Id;
                ctx.FinishedProductName = prod.ProductNameAr;
                ctx.FinishedProductCode = prod.ProductCode;
                ctx.ProducedQtyKg = qty;
                ctx.ProducedQty = qty;
                ctx.ProducedUnitLabel = prod.TradingUnit ?? prod.UnitOfMeasure;
                // §5 — الصنف الخام من التعريف الرسمي في بطاقة المنتج (لا تخمين)
                if (prod.SourceProductId != null)
                {
                    var raw = Db.Products.AsNoTracking().FirstOrDefault(p => p.Id == prod.SourceProductId);
                    ctx.RawItemName = raw?.ProductNameAr;
                    ctx.RawItemCode = raw?.ProductCode;
                }
            }
            if (lot != null && ctx.LotCode == null) { ctx.LotCode = lot.LotCode; ctx.LotId = lot.Id; }
            if (ctx.RawItemName == null && lot != null)
            {
                var lotProd = Db.Products.AsNoTracking().FirstOrDefault(p => p.Id == lot.ProductId);
                if (lotProd != null && lotProd.ItemType == "Raw") { ctx.RawItemName = lotProd.ProductNameAr; ctx.RawItemCode = lotProd.ProductCode; }
            }
        }
        if (ctx.CustomerName == null && ctx.Items.Count > 0 && ctx.Items[0].CustomerId != null)
            ctx.CustomerName = Db.Customers.AsNoTracking().Where(c => c.Id == ctx.Items[0].CustomerId).Select(c => c.CustomerName).FirstOrDefault();
        return ctx;
    }

    // ─────────────────────── التحقق والحساب ───────────────────────

    /// <summary>
    /// §8 — التحقق من النتائج قبل الحفظ: النوع معرَّف ونشط، الوحدة معرفة ومسموحة لهذا النوع،
    /// الكمية غير سالبة، والأنواع الإجبارية للصنف مُدخلة.
    /// </summary>
    public void ValidateResults(List<InspectionResultDto> results, int? orderId = null, int? productId = null)
    {
        if (results == null || results.Count == 0) throw new DomainException("أدخل نتيجة فحص واحدة على الأقل.");

        var types = Db.InspectionResultTypes.AsNoTracking().ToDictionary(t => t.Id);
        var units = Db.UnitsOfMeasure.AsNoTracking().ToDictionary(u => u.Id);
        var orderProducts = orderId != null
            ? Db.ProductionOrderItems.AsNoTracking().Where(i => i.OrderId == orderId).Select(i => i.ProductId).Distinct().ToHashSet()
            : null;

        foreach (var r in results)
        {
            if (!types.TryGetValue(r.ResultTypeId, out var t))
                throw new DomainException($"نوع النتيجة #{r.ResultTypeId} غير معرَّف في الإعدادات.");
            if (!t.IsActive)
                throw new DomainException($"نوع النتيجة «{t.NameAr}» موقوف — فعّله من الإعدادات أو اختر غيره.");
            if (r.Qty < 0)
                throw new DomainException($"كمية «{t.NameAr}» لا يمكن أن تكون سالبة.");

            // §4 — الوحدة من القاموس وقواعد النوع
            int? unitId = r.UnitId ?? t.UnitId;
            if (unitId != null)
            {
                if (!units.TryGetValue(unitId.Value, out var u))
                    throw new DomainException($"الوحدة المحددة لـ«{t.NameAr}» غير موجودة في قاموس الوحدات.");
                if (!u.IsActive)
                    throw new DomainException($"الوحدة «{u.UnitNameAr}» موقوفة في قاموس الوحدات — لا يمكن استخدامها لـ«{t.NameAr}».");
            }
            else if (r.Qty > 0)
            {
                throw new DomainException(
                    $"«{t.NameAr}» بلا وحدة معتمدة — حدّد الوحدة في تعريف نوع النتيجة من الإعدادات، أو اختر وحدة في الشاشة.");
            }

            // §5 — الربط: لا نتيجة لصنف خارج أمر الإنتاج
            if (orderProducts != null && r.ProductId != null && !orderProducts.Contains(r.ProductId.Value))
            {
                string name = Db.Products.AsNoTracking().Where(p => p.Id == r.ProductId).Select(p => p.ProductNameAr).FirstOrDefault() ?? $"#{r.ProductId}";
                throw new DomainException($"الصنف «{name}» ليس من بنود أمر الإنتاج — الفحص يحافظ على ربط النتائج بالأمر.");
            }
        }

        // الأنواع الإجبارية لهذا الصنف
        if (productId != null)
        {
            var mandatory = Db.ItemInspectionProfiles.AsNoTracking()
                .Where(p => p.IsActive && p.IsMandatory && p.ProductId == productId).Select(p => p.ResultTypeId).ToList();
            foreach (var m in mandatory.Where(m => !results.Any(r => r.ResultTypeId == m && r.Qty > 0)))
            {
                string name = types.TryGetValue(m, out var mt) ? mt.NameAr : $"#{m}";
                throw new DomainException($"النتيجة «{name}» إجبارية لهذا الصنف حسب تعريفه — أدخل كميتها (ولو صفراً).");
            }
        }
    }

    /// <summary>
    /// §6 — الحسابات: إجمالي المفحوص/التام/غير المطابق/المخرجات الثانوية/الفاقد والنسب.
    /// لا يجمع وحدات مختلفة في إجمالي واحد: كل وحدة إجمالي مستقل، والنسب تُحسب داخل الوحدة.
    /// </summary>
    public InspectionTotals Compute(List<InspectionResultDto> results)
    {
        var totals = new InspectionTotals();
        if (results == null || results.Count == 0) return totals;

        var types = Db.InspectionResultTypes.AsNoTracking().ToDictionary(t => t.Id);
        var units = Db.UnitsOfMeasure.AsNoTracking().ToDictionary(u => u.Id);

        var byUnit = new Dictionary<int?, UnitTotal>();
        var byType = new Dictionary<int, (string name, double qty, string unit)>();

        foreach (var r in results)
        {
            if (!types.TryGetValue(r.ResultTypeId, out var t)) continue;
            double qty = (double)r.Qty;
            int? unitId = r.UnitId ?? t.UnitId;
            string unitLabel = unitId != null && units.TryGetValue(unitId.Value, out var u) ? u.UnitNameAr : t.UnitLabel ?? "—";

            if (!byUnit.TryGetValue(unitId, out var ut))
                byUnit[unitId] = ut = new UnitTotal { UnitId = unitId, UnitLabel = unitLabel };

            ut.Checked += qty;
            switch (t.ResultKind)
            {
                case InspectionResultType.KindAccepted: ut.Accepted += qty; break;
                case InspectionResultType.KindRejected: ut.Rejected += qty; break;
                case InspectionResultType.KindByProduct: ut.ByProduct += qty; break;
                case InspectionResultType.KindLoss: ut.Loss += qty; break;
            }
            if (t.CountsAsLoss && t.ResultKind != InspectionResultType.KindLoss) ut.Loss += qty;

            if (!byType.TryGetValue(t.Id, out var agg)) byType[t.Id] = (t.NameAr, 0, unitLabel);
            byType[t.Id] = (agg.name, agg.qty + qty, unitLabel);
        }

        totals.ByUnit = byUnit.Values.OrderBy(x => x.UnitLabel).ToList();
        totals.ByResultType = byType.Select(kv => (kv.Key, kv.Value.name, kv.Value.qty, kv.Value.unit)).ToList();

        totals.TotalChecked = totals.ByUnit.Sum(x => x.Checked);
        totals.TotalAccepted = totals.ByUnit.Sum(x => x.Accepted);
        totals.TotalRejected = totals.ByUnit.Sum(x => x.Rejected);
        totals.TotalByProduct = totals.ByUnit.Sum(x => x.ByProduct);
        totals.TotalLoss = totals.ByUnit.Sum(x => x.Loss);

        totals.SingleUnit = totals.ByUnit.Count <= 1;
        if (totals.SingleUnit && totals.ByUnit.Count == 1)
        {
            var u0 = totals.ByUnit[0];
            totals.PrimaryUnitLabel = u0.UnitLabel;
            totals.AcceptancePct = Pct(u0.Accepted, u0.Checked);
            totals.ByProductPct = Pct(u0.ByProduct, u0.Checked);
            totals.LossPct = Pct(u0.Loss, u0.Checked);
        }
        else if (totals.ByUnit.Count > 1)
        {
            totals.Warnings.Add(
                $"الكميات مسجّلة بـ{totals.ByUnit.Count} وحدات مختلفة ({string.Join("، ", totals.ByUnit.Select(x => x.UnitLabel))}) — " +
                "الإجماليات والنسب معروضة لكل وحدة على حدة ولا تُجمع. عرّف تحويل وحدات إن أردت إجماليّاً موحّداً.");
        }
        return totals;
    }

    /// <summary>
    /// §6 — إجمالي موحّد بوحدة هدف باستخدام التحويلات المعرَّفة فقط.
    /// إن وُجدت كمية بوحدات لا تحويل لها ← تُرفض العملية برسالة صريحة (لا تخمين).
    /// </summary>
    public double? ComputeConvertedTotal(List<InspectionResultDto> results, int toUnitId, out string failureReason)
    {
        failureReason = null;
        decimal total = 0;
        var types = Db.InspectionResultTypes.AsNoTracking().ToDictionary(t => t.Id);
        var convs = Db.UnitConversions.AsNoTracking().Where(c => c.IsActive && c.ToUnitId == toUnitId).ToList();

        foreach (var r in results)
        {
            int? unitId = r.UnitId ?? (types.TryGetValue(r.ResultTypeId, out var t) ? t.UnitId : null);
            if (unitId == null) { failureReason = $"«{(types.TryGetValue(r.ResultTypeId, out var t2) ? t2.NameAr : "-")}» بلا وحدة معتمدة."; return null; }
            if (unitId == toUnitId) { total += (decimal)r.Qty; continue; }
            var c = convs.FirstOrDefault(x => x.FromUnitId == unitId);
            if (c == null)
            {
                failureReason = $"لا يوجد تحويل معرَّف من «{UnitName(unitId.Value)}» إلى «{UnitName(toUnitId)}» — عرّفه من نافذة الوحدات.";
                return null;
            }
            total += (decimal)r.Qty * c.Factor;
        }
        return (double)Math.Round(total, 3);
    }

    /// <summary>اسم وحدة من القاموس — للرسائل.</summary>
    public string UnitName(int unitId)
        => Db.UnitsOfMeasure.AsNoTracking().Where(u => u.Id == unitId).Select(u => u.UnitNameAr).FirstOrDefault() ?? $"#{unitId}";

    // ─────────────────────── أدوات ───────────────────────

    private static double? Pct(double part, double whole)
        => whole > 0 ? Math.Round(part / whole * 100.0, 2) : null;

    private static string NormalizeKind(string kind)
    {
        if (string.IsNullOrWhiteSpace(kind)) return InspectionResultType.KindAccepted;
        var k = kind.Trim();
        if (new[] { InspectionResultType.KindAccepted, InspectionResultType.KindRejected,
                    InspectionResultType.KindByProduct, InspectionResultType.KindLoss }
                .Contains(k, StringComparer.OrdinalIgnoreCase)) return k;
        // قبول التسمية العربية أيضاً — الشاشة قد ترسل أياً منهما
        return k switch
        {
            "مقبول" or "مقبول للإفراج" or "تام" => InspectionResultType.KindAccepted,
            "مرفوض" or "غير مطابق" => InspectionResultType.KindRejected,
            "مخرج ثانوي" or "ثانوي" => InspectionResultType.KindByProduct,
            "فاقد" or "هالك" => InspectionResultType.KindLoss,
            _ => throw new DomainException(
                $"تصنيف النتيجة «{k}» غير معتمد — المسموح: مقبول للإفراج | مرفوض | مخرج ثانوي | فاقد.")
        };
    }

    private AllowedResultType ToAllowed(InspectionResultType t) => new()
    {
        ResultTypeId = t.Id,
        Code = t.Code,
        NameAr = t.NameAr,
        ResultKind = t.ResultKind,
        ResultKindAr = InspectionResultType.KindNameAr(t.ResultKind),
        UnitId = t.UnitId,
        UnitLabel = t.UnitLabel,
        IsFinishedGood = t.IsFinishedGood,
        IsByProduct = t.IsByProduct,
        EntersInventory = t.EntersInventory,
        CountsAsLoss = t.CountsAsLoss,
        SortNo = t.SortNo
    };
}
