using DatesErp.Core.Common;

namespace DatesErp.Core.Domain.Entities;

/// <summary>§7 — أمر تسليم الإنتاج التام من الإنتاج إلى مخزن التام (استلام الإنتاج التام).</summary>
public class FinishedGoodsReceipt : WorkflowDocument
{
    public int OrderId { get; set; }
    public int? QualityCheckId { get; set; }
    public DateTime? DeliveryDate { get; set; }
    public int? PackagingOfficerId { get; set; }
    public int? WarehouseKeeperId { get; set; }
    public int WarehouseId { get; set; } // مخزن التام
    public string ReceiptStatus { get; set; } // None | Partial | Full
    public string ReceiptNumber { get; set; }
    public int ReceiveCount { get; set; } // عدد سندات الاستلام المنفذة على هذا الأمر (سندات المتابعة)

    public List<FinishedGoodsReceiptItem> Items { get; set; } = new();
}

public class FinishedGoodsReceiptItem : BaseEntity
{
    public int ReceiptId { get; set; }
    public int ProductId { get; set; }
    public int? LotId { get; set; }
    public int? PackagingTypeId { get; set; }
    public int PackageCount { get; set; }
    public double NetWeightKg { get; set; }
    public double ReceivedQtyKg { get; set; } // ما استلمه أمين المخزن فعلياً
    /// <summary>§نظام الوحدات: وزن الكرتون وقت الاستلام — لا يتغير بتعريف العبوة لاحقاً.</summary>
    public double CartonWeightKg { get; set; }
}

/// <summary>§7 — تسليم الإنتاج للعميل.</summary>
public class CustomerDelivery : WorkflowDocument
{
    public int CustomerId { get; set; }
    public DateTime? DeliveryDate { get; set; }
    public int? OrderId { get; set; }
    public string DeliveryType { get; set; } = "FinishedGoods";
    public double TotalQtyKg { get; set; }
    public int TotalCartons { get; set; }
    // §9 — الفوترة على المسلَّم فعلياً فقط، مع منع تكرار الفوترة
    public double InvoicedQtyKg { get; set; }
    public double BillableQtyKg => Math.Max(0, TotalQtyKg - InvoicedQtyKg);

    public List<CustomerDeliveryItem> Items { get; set; } = new();
}

public class CustomerDeliveryItem : BaseEntity
{
    public int DeliveryId { get; set; }
    public int ProductId { get; set; }
    public int? LotId { get; set; }
    public int? PackagingTypeId { get; set; }
    public int PackageCount { get; set; }
    public double QtyKg { get; set; }
    /// <summary>§القاعدة 7: وزن الكرتون وقت التسليم — يجمّد التعريف اللاحق للعبوة بأثر رجعي.</summary>
    public double CartonWeightKg { get; set; }
}
