using DatesErp.Core.Common;

namespace DatesErp.Core.Domain.Entities;

/// <summary>§7 — فحص الجودة (نهائي/أثناء العملية) — على تصميم استمارة الفحص المعتمدة.</summary>
public class QualityCheck : WorkflowDocument
{
    /// <summary>الفحص اليدوي قد لا يرتبط بأمر — والاعتيادي يرتبط بأمر إنتاجه.</summary>
    public int? OrderId { get; set; }
    public int? ExecutionId { get; set; }
    public DateTime? CheckDate { get; set; }
    public string CheckType { get; set; } = "نهائي";
    public double TotalCheckedKg { get; set; }
    public double AcceptedKg { get; set; }
    public double RejectedKg { get; set; }
    /// <summary>§جودة التمور: الفحص النهائي متوقع بعد فترة التبريد (يومان) — لا يظهر العيب إلا بعد أن يبرد المنتج.</summary>
    public DateTime? ExpectedCheckDate { get; set; }
    /// <summary>§قرار الجودة: Passed مطابق ومقبول للإفراج | Quarantine حجز وتحريز مؤقت | Rejected مرفوض/عوادم.</summary>
    public string Decision { get; set; } = "Passed";
    /// <summary>§معايير الفحص المخبري والحسي — المواصفة القياسية المعتمدة للتمور.</summary>
    public double MoisturePct { get; set; }        // نسبة الرطوبة % (14–18)
    public double BrixDeg { get; set; }            // تركيز السكريات Brix° (≥ 65)
    public double SkinSeparationPct { get; set; }  // نسبة انفصال القشرة % (≤ 5)
    public double ImpuritiesPct { get; set; }      // نسبة الشوائب والأتربة % (≤ 1)
    public int SampleCartons { get; set; }         // عينة الفحص المخبري (كرتون)
    public string InspectorNotes { get; set; }     // ملاحظات وتوصيات مسؤول الجودة

    public List<QualityCheckItem> Items { get; set; } = new();

    /// <summary>
    /// §النتائج الديناميكية: نوع نتيجة + كمية + وحدتها — بدل أعمدة ثابتة باسم «حشف/نوى».
    /// الأصناف والوحدات وأنواع النتائج كلها من التعريفات، فلا نتيجة مثبّتة في الكود.
    /// </summary>
    public List<InspectionResult> Results { get; set; } = new();
}

public class QualityCheckItem : BaseEntity
{
    public int CheckId { get; set; }
    public int ProductId { get; set; }
    public int? LotId { get; set; }
    public double CheckedQtyKg { get; set; }
    public double AcceptedQtyKg { get; set; }
    public double RejectedQtyKg { get; set; }
    public string Notes { get; set; }
}

/// <summary>§7/§8 — الأصناف الثانوية (حشف، نوى، مخلفات) — تُقاس بالكيلو دائماً.</summary>
public class ByProduct : BaseEntity
{
    public string ByProductCode { get; set; }
    public string ByProductNameAr { get; set; } // حشف | نوى | مخلفات فرز
    public string UnitOfMeasure { get; set; } = "كجم"; // §8: وحدات الأصناف الثانوية كيلوجرام
    public bool IsActive { get; set; } = true;
}

public class QualityByProductRecord : BaseEntity
{
    public int CheckId { get; set; }
    public int ByProductId { get; set; }
    public double QtyKg { get; set; }
    public string Notes { get; set; }
}

/// <summary>§لا ثوابت في الكود: معايير الفحص المخبري تُهيأ كلها من شاشة إعدادات الأصناف.</summary>
public class QualityStandard : BaseEntity
{
    public string Code { get; set; }
    public string NameAr { get; set; }
    public string UnitLabel { get; set; } = "%";
    public double? MinValue { get; set; }
    public double? MaxValue { get; set; }
    public double DefaultValue { get; set; }
    public int SortNo { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>قيمة معيار مسجلة في استمارة فحص (بدلاً من أعمدة ثابتة).</summary>
public class QualityStandardRecord : BaseEntity
{
    public int CheckId { get; set; }
    public int StandardId { get; set; }
    public double Value { get; set; }
    public string Notes { get; set; }
}

/// <summary>§مخرجات ثانوية فعلية لإقفال خطة — الأصناف من جدول ByProducts لا من الكود.</summary>
public class PlanClosingByProduct : BaseEntity
{
    public int ClosingId { get; set; }
    public int ByProductId { get; set; }
    public double QtyKg { get; set; }
}
