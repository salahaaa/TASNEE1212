using Xunit;

namespace DatesErp.Tests;

/// <summary>§B93 — ربط الترحيل بين الشاشات (فحص مصدر فقط).</summary>
public class UiB93Tests
{
    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir != null && !File.Exists(Path.Combine(dir.FullName, "DateERP.sln")))
            dir = dir.Parent;
        Assert.NotNull(dir);
        return dir!.FullName;
    }

    private static string Read(string rel)
        => File.ReadAllText(Path.Combine(RepoRoot(), rel));

    [Fact]
    public void Issue_Handoff_Wired_Planning_To_Orders()
    {
        string main = Read("src/DatesErp.Desktop/Views/MainWindow.xaml.cs");
        string orders = Read("src/DatesErp.Desktop/Views/Screens/OrdersView.xaml.cs");
        string planning = Read("src/DatesErp.Desktop/Views/Screens/PlanningView.xaml.cs");
        Assert.Contains("PendingIssuePlanIdToOpen", main);
        Assert.Contains("OpenIssuePlanOrders", main);
        Assert.Contains("PendingIssuePlanIdToOpen", orders);
        Assert.Contains("IssuePlan_Click", orders);
        Assert.Contains("OpenIssuePlanOrders", planning);
        Assert.Contains("class IssuePlanWindow", Read("src/DatesErp.Desktop/Views/Screens/OrdersWindows.cs"));
    }
}
