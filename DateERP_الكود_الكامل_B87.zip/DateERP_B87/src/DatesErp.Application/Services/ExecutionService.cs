using DatesErp.Core.Common;
using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Domain.Enums;
using DatesErp.Core.Exceptions;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

/// <summary>§7 — تنفيذ وإقفال الإنتاج مع حراس §8 (لا تنفيذ على أمر مكتمل/غير معتمد، لا تجاوز للكميات).</summary>
public class ExecutionService : ServiceBase, IExecutionService
{
    private readonly IPlanningService _planning;

    public ExecutionService(DatesErpDbContext db, ICurrentSession session, INumberingService numbering, IPlanningService planning)
        : base(db, session, numbering)
    {
        _planning = planning;
    }

    // §حُذف StartExecution وCompleteExecution في B40: كانا مساراً موازياً لا تستدعيه أي شاشة.
    // المسار الفعلي: IProductionOrderService.StartOrder ثم IExecutionService.CloseProductionDay.
    // كانت 25 استدعاء اختبار تسلكهما — حُوّلت إلى المسار الحقيقي في B36.

    /// <summary>
    /// §نموذج إقفال الخطة اليومي — بديل جلسة التنفيذ:
    /// إنزال من أمر التشغيل: المفترض إنتاجه × كم خاماً استلمنا (صُرف) × كم أنتجنا × ماذا خرج
    /// (كراتين بوزنها + حشف + نوى + هالك بالكيلو) والمتبقي في صالة الإنتاج يُرحَّل اختيارياً
    /// لخطة اليوم التالي + التوقفات (كم ساعة ولماذا) + الإرسال للجودة (فحص بعد يومَي تبريد)
    /// ثم إقفال اليوم — وإن اكتملت الخطة تُقفل تلقائياً استعداداً لأمر جديد.
    /// </summary>
    public OpResult CloseProductionDay(int orderId, double producedKg, int producedCartons,
        double hashfKg, double nawaKg, double wastageKg, bool carryToNextDay,
        List<DowntimeDto> downtimes, bool sendToQuality, string notes = null,
        List<ByProductQtyDto> byProducts = null, double consumedRawKg = 0)
    {
        Require("execution", "Edit");
        var order = Db.ProductionOrders.Include(o => o.Items).FirstOrDefault(o => o.Id == orderId);
        if (order == null) return OpResult.Fail("أمر التشغيل غير موجود.");
        if (!order.IsApproved) return OpResult.Fail("لا يمكن إقفال يوم أمر غير معتمد.");
        if (order.IsClosed) return OpResult.Fail("هذا الأمر مقفل مسبقاً.");
        if (Db.ProductionExecutions.Any(e => e.OrderId == orderId && e.IsDayClosed))
            return OpResult.Fail("يوم الإنتاج لهذا الأمر مقفل مسبقاً — لا يسمح بتكرار الإقفال.");
        // §B85/H1: منع الازدواج — بنود أُقفلت عبر «إقفال بنود الخطة» لا يُقفل يوم أمرها أيضاً
        if (order.Items.Any(i => i.IsClosed))
            return OpResult.Fail("بنود هذا الأمر أُقفلت عبر «إقفال بنود الخطة» — لا يجوز إقفال يومه أيضاً (منعاً لازدواج الإنتاج والخام). للإقفال النهائي استخدم «إقفال خطة الإنتاج».");

        return RunOp(() =>
        {
            // §8 — حراس الكميات
            if (producedKg < 0 || hashfKg < 0 || nawaKg < 0 || wastageKg < 0 || producedCartons < 0)
                throw new DomainException("الكميات لا يمكن أن تكون سالبة.");
            double producedSoFar = order.Items.Sum(i => i.ProducedQtyKg);
            double plannedTotal = order.Items.Sum(i => i.PlannedQtyKg);
            if (producedSoFar + producedKg > plannedTotal + 0.001)
                throw new DomainException(
                    $"كمية الإنتاج أكبر من المسموح بها للأمر.\nالمخطط: {plannedTotal:N1} كجم | المنتَج حتى الآن: {producedSoFar:N1} | المطلوب تسجيله: {producedKg:N1}",
                    "OVER_PRODUCTION");

            // الخام المستهلك = ما صُرف عند اعتماد الأمر (بنود الدفعات)
            // §لا تناقض بين الكراتين والوزن: الإنتاج الفعلي كان يُدخل بلا هذا التحقق
            // (كان مطبقاً في الخطة والأمر والتام فقط) فقُبل «100 كرتون مقابل 9,500 كجم».
            foreach (var oiChk in order.Items)
            {
                UnitsPolicy.RequireCartonWeight(Db, oiChk.ProductId, oiChk.PackagingTypeId, producedCartons,
                    "إقفال يوم الإنتاج");
                UnitsPolicy.EnsureCartonKgConsistency(Db, oiChk.ProductId, oiChk.PackagingTypeId,
                    producedKg, producedCartons, "إقفال يوم الإنتاج");
                break;   // التحقق على صنف الأمر الأول يكفي — الأمر الواحد صنف واحد في النموذج الحالي
            }

            // §قاعدة توازن الإنتاج: الخام المستهلك هو ما يُدخله المستخدم فعلياً،
            // لا ما يُشتق من وزن المنتج المخطط. فإن لم يُدخل، يُعتمد المخطط تقريباً.
            double plannedRaw = order.Items.Where(i => i.LotId != null).Sum(i => i.PlannedQtyKg);
            double consumed = consumedRawKg > 0 ? consumedRawKg : plannedRaw;

            // صرف الخام فعلياً من الدفعات — هنا لا عند الاعتماد
            var whRawForClose = WarehouseId("WRM");
            var takeByLot = new Dictionary<int, double>(); // §B86/M12: المصروف الفعلي لكل دفعة — أساس توزيع المرتجع
            foreach (var oi in order.Items.Where(i => i.LotId != null))
            {
                double share = plannedRaw > 0 ? oi.PlannedQtyKg / plannedRaw : 0;
                double take = Math.Round(consumed * share, 1);
                if (take <= 0) continue;
                ConsumeLot(oi.LotId.Value, take, "إقفال يوم الإنتاج");
                takeByLot[oi.LotId.Value] = (takeByLot.TryGetValue(oi.LotId.Value, out var tv) ? tv : 0) + take;
                PostStockMovement(whRawForClose, MovementType.Outbound, take, 0,
                    ReferenceDocType.ProductionExecution, order.DocumentNumber,
                    productId: Db.Lots.Where(l => l.Id == oi.LotId).Select(l => l.ProductId).FirstOrDefault(),
                    lotId: oi.LotId, customerId: oi.CustomerId ?? order.CustomerId, orderId: order.Id,
                    notes: "صرف خام فعلي عند إقفال يوم الإنتاج");
            }
            // §المخرجات الثانوية: القائمة الديناميكية هي المرجع إن وُجدت. وإن غابت يُعتمد على
            // العمودين القديمين — ولا يُجمعان معاً أبداً، وإلا عُدّ المخرج مرتين
            // (CloseDayDialog يملأ الاثنين معاً مطابقةً بالاسم للبيانات السابقة).
            double byTotal = byProducts?.Where(b => b != null && b.QtyKg > 0).Sum(b => b.QtyKg) ?? 0;
            double secondary = byTotal > 0 ? byTotal : hashfKg + nawaKg;
            double outputs = producedKg + secondary + wastageKg;
            // §قاعدة توازن الإنتاج: لا معادلة ثابتة ولا رفض.
            // في تصنيع التمور يزيد وزن الخارج عن الداخل لإضافة الماء أثناء التشغيل،
            // والماء لا يُسجَّل صنفاً ولا مدخلاً مستقلاً. فالنظام يقبل الكميات الفعلية
            // ويحسب الفرق ويعرضه في «تقرير توازن الإنتاج» إجراءً رقابياً — لا يمنع العملية.
            double remainingInHall = Math.Round(Math.Max(0, consumed - outputs), 1);

            // §B85/H3: انحراف معامل الإنتاجية — المتوقع من المعامل مقابل الفعلي (تنبيه فقط، لا رفض)
            string yieldMsg = "";
            int? firstProdId = order.Items.FirstOrDefault()?.ProductId;
            double? yf = firstProdId != null
                ? Db.Products.AsNoTracking().Where(p => p.Id == firstProdId.Value).Select(p => p.YieldFactor).FirstOrDefault()
                : null;
            if (yf != null && yf > 0 && outputs > 0)
            {
                double expectedConsumed = outputs / yf.Value;
                double variance = consumed - expectedConsumed;
                double varPct = expectedConsumed > 0 ? variance / expectedConsumed * 100 : 0;
                string vSign = variance >= 0 ? "+" : "";
                string pSign = varPct >= 0 ? "+" : "";
                yieldMsg = $"\n📊 معامل الإنتاجية ({yf.Value:0.###}): المتوقع {expectedConsumed:N1} كجم مقابل فعلي {consumed:N1} — الانحراف {vSign}{variance:N1} كجم ({pSign}{varPct:0.0}%).";
                if (Math.Abs(varPct) > 5)
                    yieldMsg += " ⚠ يتجاوز ±5% — راجع القياس أو حدّث المعامل من بطاقة الصنف.";
            }
            else if (outputs > consumed + 0.001)
            {
                // §B85/H2: زيادة الخارج عن الداخل = ماء التشغيل غالباً — تُعرض ولا تُرفض
                yieldMsg = $"\n💧 الخارج يزيد عن الداخل بـ {outputs - consumed:N1} كجم (ماء التشغيل غالباً) — حدّد معامل الإنتاجية في بطاقة الصنف لضبط الانحراف تلقائياً.";
            }

            // جلسة الإقفال: تكمل جلسة جارية أو تُنشأ جديدة
            var exe = Db.ProductionExecutions
                .Include(x => x.Downtimes).Include(x => x.ByProducts)
                .FirstOrDefault(e => e.OrderId == orderId && e.Status == DocStatuses.InProgress);
            bool isNew = exe == null;
            if (isNew)
            {
                exe = new ProductionExecution
                {
                    DocumentNumber = Numbering.Next("EXE"),
                    OrderId = orderId,
                    LineId = order.LineId,
                    ShiftId = order.ShiftId,
                    StartDateTime = DateTime.Now
                };
            }
            exe.EndDateTime = DateTime.Now;
            exe.Status = DocStatuses.Completed;
            exe.ActualQtyKg = producedKg;
            exe.ActualCartons = producedCartons;
            exe.WastageQtyKg = wastageKg;
            exe.HashfKg = hashfKg;
            exe.NawaKg = nawaKg;
            exe.ConsumedRawKg = consumed;
            exe.RemainingInHallKg = remainingInHall;
            exe.CarryToNextDay = carryToNextDay && remainingInHall > 0;
            exe.QualitySent = sendToQuality;
            exe.ExpectedQualityDate = sendToQuality ? DateTime.Today.AddDays(2) : null;
            exe.IsDayClosed = true;
            exe.ClosingNotes = notes;

            // §المخرجات الثانوية بأصنافها المعرَّفة (لا «حشف/نوى» مفروضة)
            if (byProducts != null)
                foreach (var bp in byProducts)
                {
                    if (bp == null || bp.QtyKg <= 0) continue;
                    if (!Db.ByProducts.Any(b => b.Id == bp.ByProductId && b.IsActive))
                        throw new DomainException("المخرج الثانوي غير موجود في بطاقته أو موقوف — عرّفه من إعدادات الأصناف.");
                    exe.ByProducts.Add(new ExecutionByProduct { ByProductId = bp.ByProductId, Qty = (decimal)bp.QtyKg });
                }

            // §التوقفات: كم ساعة ولماذا
            if (downtimes != null)
                foreach (var dt in downtimes)
                    if (dt != null && dt.Hours > 0 && !string.IsNullOrWhiteSpace(dt.ReasonAr))
                        exe.Downtimes.Add(new ExecutionDowntime { Hours = dt.Hours, ReasonAr = dt.ReasonAr.Trim(), StartTime = dt.StartTime, EndTime = dt.EndTime });

            // توزيع المنتَج على بنود الأمر بالترتيب
            double remaining = producedKg;
            foreach (var item in order.Items.Where(i => i.ProducedQtyKg < i.PlannedQtyKg))
            {
                double take = Math.Min(remaining, item.PlannedQtyKg - item.ProducedQtyKg);
                if (take <= 0) continue;
                item.ProducedQtyKg += take;
                remaining -= take;
                if (remaining <= 0.001) break;
            }
            // §B86/H7: توزيع الكراتين على البنود بالترتيب وبحدود مخطط كل بند — كانت لا تُكتب أبداً فانكسر تتبع الكراتين
            int remainingBoxes = producedCartons;
            foreach (var item in order.Items.Where(i => i.ProducedCartons < i.PlannedCartons))
            {
                int boxTake = Math.Min(remainingBoxes, item.PlannedCartons - item.ProducedCartons);
                if (boxTake <= 0) continue;
                item.ProducedCartons += boxTake;
                remainingBoxes -= boxTake;
                if (remainingBoxes <= 0) break;
            }
            // §حالة الأمر: اكتملت كل البنود ← «مكتمل»
            if (order.Items.All(i => i.IsClosed || i.ProducedQtyKg + 0.001 >= i.PlannedQtyKg))
                order.Status = DocStatuses.Completed;

            if (isNew) Db.ProductionExecutions.Add(exe);
            Db.SaveChanges();

            // §تكافؤ مسارَي الإقفال: ClosePlanItems تُرجع المتبقي من الخام إلى مخزن الخام بحركة
            // مرتجع موثقة وتزيد رصيد الدفعة، ومسار الأوامر لم يكن يفعل — فكان الخام المتبقي
            // يختفي من الحساب. يُوزَّع على بنود الأمر بحسب دفعاتها.
            if (remainingInHall > 0.001)
            {
                // §B86/M12: المرتجع بنسبة المصروف الفعلي لكل دفعة (نفس الوحدة فيجمع لـ1 — كان المخطط/المستهلك مخلوطاً)
                // مع سد كسور التقريب في آخر دفعة، وحركة واحدة للدفعة (بندان من دفعة واحدة لا يكرران الحركة)
                double totalTake = takeByLot.Values.Sum();
                double backAssigned = 0;
                var backLots = takeByLot.Keys.ToList();
                for (int li = 0; li < backLots.Count; li++)
                {
                    var lotBack = Db.Lots.FirstOrDefault(l => l.Id == backLots[li]);
                    if (lotBack == null) continue;
                    bool lastBack = li == backLots.Count - 1;
                    double back = lastBack
                        ? Math.Round(remainingInHall - backAssigned, 1)
                        : Math.Round(remainingInHall * (totalTake > 0 ? takeByLot[backLots[li]] / totalTake : 0), 1);
                    if (back <= 0) continue;
                    backAssigned += back;
                    lotBack.InStockQtyKg += back;
                    PostStockMovement(WarehouseId("WRM"), MovementType.Inbound, back, 0,
                        ReferenceDocType.Return, exe.DocumentNumber,
                        productId: lotBack.ProductId, lotId: lotBack.Id, customerId: lotBack.CustomerId,
                        orderId: order.Id,
                        notes: $"مرتجع متبقي إقفال يوم الإنتاج إلى مخزن الخام — نفس العميل والدفعة ({lotBack.LotCode})");
                }
            }

            PlanSync.SyncProduced(Db, order.Id);

            // §B85/H1: تحديث الحجز المخزن بعد الإنتاج — كان يبقى مرتفعاً حتى الإقفال النهائي فيُخفي المتاح عن الخطط
            if (order.SourcePlanId is int srcPlanId)
            {
                var srcPlan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == srcPlanId);
                if (srcPlan != null) ApplyReservationsViaPlanning(srcPlan);
            }
            else
            {
                RefreshLotReservations(order.Items.Where(i => i.LotId != null).Select(i => i.LotId.Value));
            }

            // §جودة التمور: الإرسال للفحص — النتيجة متوقعة بعد يومَي تبريد (العيب لا يظهر إلا بعد أن يبرد المنتج)
            if (sendToQuality)
            {
                Db.QualityChecks.Add(new QualityCheck
                {
                    DocumentNumber = Numbering.Next("QC"),
                    OrderId = order.Id,
                    ExecutionId = exe.Id,
                    CheckDate = DateTime.Now,
                    CheckType = "نهائي — بعد التبريد (يومان)",
                    TotalCheckedKg = producedKg,
                    ExpectedCheckDate = DateTime.Today.AddDays(2),
                    Status = DocStatuses.Submitted
                });
            }
            Db.SaveChanges();

            // §إن اكتملت الخطة المصدر تُقفل تلقائياً ويُسمح بإصدار خطة اليوم التالي
            string planMsg = "";
            if (order.SourcePlanId is int planId)
            {
                var auto = _planning.TryAutoCloseIfComplete(planId);
                if (auto.Ok) planMsg = "\n" + auto.Message;
            }

            // §B86/L4: صياغة صادقة — المتبقي يعود لخام دفعته ولا يرتبط تلقائياً بخطة الغد
            string carryMsg = exe.CarryToNextDay
                ? $"\n⏪ المتبقي في الصالة {remainingInHall:N1} كجم أُعيد لخام دفعته — أعد تخطيطه يدوياً في خطة اليوم التالي."
                : (remainingInHall > 0 ? $"\nالمتبقي في الصالة: {remainingInHall:N1} كجم (أُعيد لخام الدفعة)." : "");
            string qMsg = sendToQuality
                ? $"\n🔬 أُرسل للجودة — الفحص متوقع {DateTime.Today.AddDays(2):dd/MM/yyyy} (فترة تبريد يومان)." +
                  "\nيُسمح بالتسليم لمخزن التام الآن؛ تسليم العميل بانتظار اعتماد الفحص."
                : "";
            return OpResult.Success(
                $"🔒 أُقفل يوم الإنتاج للأمر {order.DocumentNumber}: المنتَج {producedKg:N1} كجم ({producedCartons:N0} كرتون)" +
                $" | حشف {hashfKg:N1} | نوى {nawaKg:N1} | هالك {wastageKg:N1} | خام مستهلك {consumed:N1}." +
                carryMsg + qMsg + planMsg + yieldMsg, exe.Id, exe.DocumentNumber);
        });
    }

    /// <summary>
    /// §إقفال على مستوى الخطة (يومية أو فترية) — تسليم الخطة كاملة أو صنف واحد أو جزء من صنف:
    /// لكل بند: الخام المستلم ← المنتَج التام والكراتين ← المخرجات الثانوية (حشف/نوى/هالك)
    /// ← المتبقي يُعاد لمخزن الخام بنفس العميل والدفعة (حركة مرتجع موثقة) ويُحرر حجزه،
    /// فلا يوجد «حجز فوق حجز»: الكمية العائدة رصيد جديد تحجزه الخطط القادمة عبر الآلية المعتادة.
    /// يُرسل للفحص (تبريد يومان) سواء كانت الخطة يومية أو فترية، وإن اكتملت البنود تُقفل الخطة.
    /// </summary>
    public OpResult ClosePlanItems(int planId, List<PlanClosingItemDto> items, bool sendToQuality,
        List<DowntimeDto> downtimes, string notes = null, double? emptyCartonsActual = null, int? cartonWarehouseId = null,
        List<AuxActualDto> actualAux = null, double? sentToQualityKg = null)
    {
        Require("execution", "Edit");
        if (items == null || items.Count == 0) return OpResult.Fail("اختر بنداً واحداً على الأقل للإقفال.");
        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");
        if (!plan.IsApproved) return OpResult.Fail("لا يمكن إقفال خطة غير معتمدة.");
        if (plan.IsClosed) return OpResult.Fail("الخطة مقفلة مسبقاً.");

        return RunOp(() =>
        {
            var closing = new PlanClosing
            {
                DocumentNumber = Numbering.Next("PCL"),
                PlanId = planId,
                ClosingDate = DateTime.Now,
                QualitySent = sendToQuality,
                SentToQualityKg = sentToQualityKg ?? 0,
                ExpectedQualityDate = sendToQuality ? DateTime.Today.AddDays(2) : null,
                ClosingNotes = notes,
                Status = DocStatuses.Completed
            };

            double totalProduced = 0, totalReturned = 0;
            // §B10 فارغ مفصول بنوع الوعاء. المفتاح int لا int? لأن Dictionary في .NET يرمي
            // ArgumentNullException عند المفتاح الفارغ — والدفعات بلا نوع عبوة حالة شائعة،
            // فكان الإقفال يسقط. NoPack بديل داخلي يُعاد إلى null عند الاستهلاك.
            const int NoPack = int.MinValue;
            var estByPack = new Dictionary<int, double>();
            var orderActual = new System.Collections.Generic.Dictionary<int, System.Collections.Generic.Dictionary<int, double>>(); // §أمر → صنف → كراتين فعلية
            var producedByOrder = new Dictionary<int, double>();
            var consumeByLot = new Dictionary<int, double>(); // §B85/H1: صرف الخام مجمّعاً لكل دفعة
            var returnByLot = new Dictionary<int, double>(); // §B86: مرتجع الخام مجمّعاً لكل دفعة

            foreach (var dto in items)
            {
                var pi = plan.Items.FirstOrDefault(i => i.Id == dto.PlanItemId)
                    ?? throw new DomainException($"البند رقم {dto.PlanItemId} غير موجود في الخطة.", "BAD_ITEM");
                // §B85/H1: الأصفار الكاملة = تحرير المتبقي (إسقاطه) لا إنتاجه — والسالب مرفوض
                if (dto.ProducedKg < 0 || dto.HashfKg < 0 || dto.NawaKg < 0 || dto.WastageKg < 0 || dto.ProducedCartons < 0)
                    throw new DomainException("الكميات لا يمكن أن تكون سالبة.");

                // §لا وزن كرتون ثابت ولا تناقض بين الكراتين والوزن عند الإقفال
                UnitsPolicy.RequireCartonWeight(Db, pi.ProductId, pi.PackagingTypeId, dto.ProducedCartons, "إقفال بند الخطة");
                UnitsPolicy.EnsureCartonKgConsistency(Db, pi.ProductId, pi.PackagingTypeId,
                    dto.ProducedKg, dto.ProducedCartons, "إقفال بند الخطة");

                double remainingToPlan = pi.PlannedQtyKg - pi.ProducedQtyKg;
                if (remainingToPlan <= 0.001 && dto.ProducedKg <= 0 && dto.HashfKg + dto.NawaKg + dto.WastageKg <= 0)
                    throw new DomainException("هذا البند مكتمل الإنتاج مسبقاً — لا يحتاج إقفالاً.", "ALREADY_DONE");
                // §B85/H1: الأصفار الكاملة مع متبقٍّ = تحرير البند (إسقاط المتبقي) لا إنتاجه — كان يُسجَّل إنتاجاً وهمياً
                bool releaseOnly = remainingToPlan > 0.001 && dto.ProducedKg <= 0 && dto.HashfKg + dto.NawaKg + dto.WastageKg <= 0
                    && (dto.ByProducts == null || !dto.ByProducts.Any(b => b != null && b.QtyKg > 0));
                // §B85/H1: كراتين بلا كيلو مدخل = إدخال متناقض — كان يُفترض «صفر = المتبقي كله» مع أي كراتين
                if (releaseOnly && dto.ProducedCartons > 0)
                    throw new DomainException("أدخل الكمية المنتجة بالكيلو مع عدد الكراتين، أو صفّر الكل لتحرير متبقي البند.", "CARTONS_WITHOUT_KG");
                double produced = dto.ProducedKg; // §B85/H1: المنتَج = المُدخل فقط — لا افتراض «صفر = المتبقي» (كان إنتاجاً وهمياً)
                if (produced > remainingToPlan + 0.001)
                    throw new DomainException(
                        $"الكمية المنتجة ({produced:N1} كجم) أكبر من المتبقي المخطط للبند ({remainingToPlan:N1} كجم).",
                        "OVER_PLAN");

                // الأمر وبند الأمر المرتبطان (إن وُجدا) والدفعة المالكة
                // §إصلاح: كان FirstOrDefault بلا ترتيب ولا استثناء للملغى — إن كان للبند أوامران
                // (توزيع على ورديتين) يُربط الأول عشوائياً وقد يكون الملغي.
                var oi = Db.ProductionOrderItems.Where(i => i.PlanItemId == pi.Id)
                    .Join(Db.ProductionOrders, i => i.OrderId, o => o.Id, (i, o) => new { i, o })
                    .Where(x => x.o.Status != DocStatuses.Cancelled)
                    .OrderBy(x => x.i.Id)
                    .Select(x => x.i)
                    .FirstOrDefault();
                var order = oi != null ? Db.ProductionOrders.FirstOrDefault(o => o.Id == oi.OrderId) : null;
                var lot = pi.LotId != null ? Db.Lots.FirstOrDefault(l => l.Id == pi.LotId) : null;
                // §B85/H1: منع الازدواج — بند سُجّل إنتاجه عبر مسار الأوامر لا يُقفل هنا أيضاً
                if (oi != null && oi.ProducedQtyKg > 0.001)
                    throw new DomainException($"البند مرتبط بالأمر {order?.DocumentNumber} وقد سُجّل فيه إنتاج ({oi.ProducedQtyKg:N1} كجم) — أقفل يوم الأمر بدل ازدواج الإقفال.", "DUAL_CLOSE");
                // §B85/H1: حصة الأمر — لا يُسجَّل عبر هذا البند فوق حصة أمره
                if (oi != null && !releaseOnly && produced > oi.PlannedQtyKg - oi.ProducedQtyKg + 0.001)
                    throw new DomainException($"الكمية المنتجة ({produced:N1} كجم) أكبر من حصة هذا البند في الأمر ({oi.PlannedQtyKg - oi.ProducedQtyKg:N1} كجم).", "OVER_ORDER");

                // كم خاماً استُلم/استُهلك لهذا البند: ما صُرف بأمر التشغيل، وإلا فالمخطط نظرياً
                // §B85/H1: التحرير وحده بلا استهلاك — لا خام تحرك أصلاً
                double consumed = releaseOnly ? 0 : (oi != null ? oi.PlannedQtyKg : pi.PlannedQtyKg);
                int packKey = Db.Lots.AsNoTracking().Where(l => l.Id == pi.LotId).Select(l => l.PackagingTypeId).FirstOrDefault() ?? NoPack;
                var w = CartonService.RawCartonWeight(Db, pi.LotId, pi.ProductId);
                // §w قد يكون صفراً (وزن غير معرَّف) — لا قسمة على صفر ولا تقدير بلا أساس
                estByPack[packKey] = (estByPack.TryGetValue(packKey, out var pv) ? pv : 0) + (w > 0 ? consumed / w : 0);
                if (order != null)
                {
                    if (!orderActual.TryGetValue(order.Id, out var pm)) orderActual[order.Id] = pm = new System.Collections.Generic.Dictionary<int, double>();
                    pm[pi.ProductId] = (pm.TryGetValue(pi.ProductId, out var pc) ? pc : 0) + dto.ProducedCartons;
                }
                // §B39 أُصلح هذا في CloseProductionDay ونُسِي هنا: المخرجات الثانوية المعرَّفة
                // (dto.ByProducts) لم تكن تُحسب، فتحقق «المخرجات تتجاوز الخام» كان أعمى عنها.
                // القائمة الديناميكية هي المرجع إن وُجدت، والعمودان القديمان بديل احتياطي — لا يُجمعان.
                // §المعيار «توجد كميات فعلية» لا «القائمة غير فارغة» — فـ dto.ByProducts
                // قائمة مُهيأة فارغة في الغالب، ولو اعتمدنا null لتُجاهلت HashfKg/NawaKg دائماً.
                double byDyn = dto.ByProducts?.Where(b => b != null && b.QtyKg > 0).Sum(b => b.QtyKg) ?? 0;
                double secondary = byDyn > 0 ? byDyn : dto.HashfKg + dto.NawaKg;
                double outputs = produced + secondary + dto.WastageKg;
                // §لا رفض عند زيادة الوزن — الفرق يظهر في تقرير توازن الإنتاج (انظر CloseProductionDay)

                // §B85/H1: تجميع الصرف لكل دفعة — يُصرف بعد الحلقة بحركة واحدة للدفعة (منع تكرار الحركة)
                if (!releaseOnly && consumed > 0 && lot != null)
                    consumeByLot[lot.Id] = (consumeByLot.TryGetValue(lot.Id, out var cv) ? cv : 0) + consumed;

                // المتبقي ← يُعاد لمخزن الخام بنفس العميل والدفعة (حركة مرتجع) ويُحرر حجزه
                // §B85/H1: المرتجع للمسارين (كان المستقل بلا مرتجع فيضيع الفرق)
                // §B86: تجميع المرتجع لكل دفعة — يُطبَّق بعد الحلقة بحركة واحدة (منع تكرار الحركة)
                double returnedRaw = releaseOnly ? 0 : Math.Round(Math.Max(0, consumed - outputs), 1);
                if (returnedRaw > 0 && lot != null)
                    returnByLot[lot.Id] = (returnByLot.TryGetValue(lot.Id, out var rv) ? rv : 0) + returnedRaw;

                // §إصلاح حرج: تسوية بند الأمر على المنتَج الفعلي — بعلم الإقفال لا بمحو المخطط.
                if (oi != null)
                {
                    oi.ProducedQtyKg += produced;
                    // §B86/H7: كراتين البند تُسجَّل وبحدود مخططه — كانت لا تُكتب أبداً
                    oi.ProducedCartons = Math.Min(oi.PlannedCartons, oi.ProducedCartons + dto.ProducedCartons);
                    oi.IsClosed = true;
                    if (order != null && !producedByOrder.ContainsKey(order.Id)) producedByOrder[order.Id] = 0;
                    if (order != null) producedByOrder[order.Id] += produced;
                }

                // §إصلاح حرج: إقفال البند على ما أُنتج — مع حفظ المخطط كما هو.
                // كان يُكتب PlannedQtyKg = ProducedQtyKg فيمحو أساس الخطة، فتظهر كل خطة
                // بنسبة إنجاز 100% في التقارير ويضيع ما كان مخططاً أصلاً.
                // الآن يُحرَّر الحجز بعلم IsClosed ويُسجَّل ما حُرر في ReleasedQtyKg.
                pi.ProducedQtyKg += produced;
                pi.ReleasedQtyKg = Math.Round(Math.Max(0, pi.PlannedQtyKg - pi.ProducedQtyKg), 3);
                pi.IsClosed = true;
                pi.ExecutionStatus = "Completed";

                closing.Items.Add(new PlanClosingItem
                {
                    PlanItemId = pi.Id,
                    OrderId = order?.Id,
                    LotId = pi.LotId,
                    CustomerId = pi.CustomerId,
                    ProductId = pi.ProductId,
                    ConsumedRawKg = consumed,
                    ProducedKg = produced,
                    ProducedCartons = dto.ProducedCartons,
                    // §القاعدة 7: وزن الكرتون وقت الإقفال — لا يتغير بتعريف العبوة لاحقاً
                    CartonWeightKg = UnitsPolicy.CartonWeight(Db, pi.ProductId, pi.PackagingTypeId),
                    // §حفظ تعريف التعبئة كاملاً وقت الإقفال
                    MoldsCount = UnitsPolicy.PackagingDefinition(Db, pi.ProductId, pi.PackagingTypeId).MoldsCount,
                    MoldWeightKg = (decimal)UnitsPolicy.PackagingDefinition(Db, pi.ProductId, pi.PackagingTypeId).MoldWeightKg,
                    HashfKg = dto.HashfKg,
                    NawaKg = dto.NawaKg,
                    WastageKg = dto.WastageKg,
                    ReturnedToRawKg = returnedRaw
                });
                var closingItem = closing.Items[^1];
                // §المخرجات الثانوية الديناميكية (أصنافها من إعدادات الأصناف لا من الكود)
                if (dto.ByProducts is { Count: > 0 })
                    foreach (var bp in dto.ByProducts.Where(b => b.QtyKg > 0))
                        closingItem.ByProducts.Add(new PlanClosingByProduct { ByProductId = bp.ByProductId, QtyKg = bp.QtyKg });
                totalProduced += produced;

            // §B57: الكمية المرسلة للفحص = اختيار المستخدم أو إجمالي المنتَج إن تُركت فارغة
            if ((sentToQualityKg ?? 0) <= 0) closing.SentToQualityKg = totalProduced;                totalReturned += returnedRaw;
            }

            // التوقفات على مستند الإقفال (يُربط ClosingId آلياً عبر مجموعة التنقل عند الحفظ)
            if (downtimes != null)
                foreach (var dt in downtimes)
                    if (dt != null && dt.Hours > 0 && !string.IsNullOrWhiteSpace(dt.ReasonAr))
                        closing.Downtimes.Add(new ExecutionDowntime { Hours = dt.Hours, ReasonAr = dt.ReasonAr.Trim(), StartTime = dt.StartTime, EndTime = dt.EndTime });

            closing.EmptyCartonsEstimated = Math.Round(estByPack.Values.Sum());
            closing.EmptyCartonsActual = emptyCartonsActual;
            Db.PlanClosings.Add(closing);
            Db.SaveChanges();
            // §B10 — التوريد الآلي للكرتون الفارغ إلى مخزن الكرتون (الفعلي إن أُكد وإلا فتقدير النظام)
            var cartonSvc = new CartonService(Db, Session, Numbering);
            // §تسوية المواد المساعدة مقابل الفعلي: المستهلك = فعلي × معادلة؛ والفرق مرتجع آلي غير معرقِل
            var ordSvc = new ProductionOrderService(Db, Session, Numbering);
            var whAux = WarehouseId("WAUX");
            foreach (var (orderId, perProd) in orderActual)
            {
                var ord = Db.ProductionOrders.Include(o => o.Materials).FirstOrDefault(o => o.Id == orderId);
                if (ord == null) continue;
                foreach (var mat in ord.Materials.Where(m => m.ActualIssuedQty > 0))
                {
                    double consumed = 0;
                    foreach (var (prodId, carts) in perProd)
                    {
                        var fms = Db.ConsumptionFormulas.AsNoTracking().Where(f => f.ProductId == prodId && f.IsActive
                            && f.Mode == "PerCarton" && (f.CustomerId == null || f.CustomerId == ord.CustomerId)).ToList();
                        foreach (var f in fms)
                            if (ordSvc.ResolveAuxMaterial(f, ord.CustomerId) == mat.MaterialId)
                                consumed += f.QtyPerUnit * carts;
                    }
                    if (actualAux != null)
                        consumed += actualAux.Where(a => a.OrderId == orderId && a.MaterialId == mat.MaterialId).Sum(a => a.Qty);
                    double diff = mat.ActualIssuedQty - mat.ReturnedQty - consumed;
                    if (diff > 0.001)
                    {
                        mat.ReturnedQty += diff;
                        var bal = Db.StockBalances.FirstOrDefault(b => b.WarehouseId == whAux && b.MaterialId == mat.MaterialId);
                        if (bal == null) { bal = new StockBalance { WarehouseId = whAux, MaterialId = mat.MaterialId }; Db.StockBalances.Add(bal); }
                        bal.QtyKg += diff;
                        Db.InventoryTransactions.Add(new InventoryTransaction
                        {
                            TxnNumber = Numbering.Next("TXN"), WarehouseId = whAux, MaterialId = mat.MaterialId, OrderId = orderId,
                            MovementType = MovementType.Inbound, QtyKg = diff,
                            ReferenceDocType = ReferenceDocType.MaterialReturn, ReferenceDocNumber = closing.DocumentNumber, IsApproved = true
                        });
                    }
                    else if (diff < -0.001)
                    {
                        var bal = Db.StockBalances.FirstOrDefault(b => b.WarehouseId == whAux && b.MaterialId == mat.MaterialId);
                        if (bal == null) { bal = new StockBalance { WarehouseId = whAux, MaterialId = mat.MaterialId }; Db.StockBalances.Add(bal); }
                        bal.QtyKg += diff;
                        Db.InventoryTransactions.Add(new InventoryTransaction
                        {
                            TxnNumber = Numbering.Next("TXN"), WarehouseId = whAux, MaterialId = mat.MaterialId, OrderId = orderId,
                            MovementType = MovementType.Outbound, QtyKg = -diff,
                            ReferenceDocType = ReferenceDocType.MaterialIssue, ReferenceDocNumber = closing.DocumentNumber, IsApproved = true
                        });
                    }
                }
                // §مواد الإدخال الفعلي غير المصروفة عند الاعتماد (ديزل/وقود): تُخصم عند الإقفال
                if (actualAux != null)
                    foreach (var aa in actualAux.Where(a => a.OrderId == orderId && a.Qty > 0
                             && !ord.Materials.Any(m => m.MaterialId == a.MaterialId)))
                    {
                        var bal = Db.StockBalances.FirstOrDefault(b => b.WarehouseId == whAux && b.MaterialId == aa.MaterialId);
                        if (bal == null) { bal = new StockBalance { WarehouseId = whAux, MaterialId = aa.MaterialId }; Db.StockBalances.Add(bal); }
                        bal.QtyKg -= aa.Qty;
                        Db.InventoryTransactions.Add(new InventoryTransaction
                        {
                            TxnNumber = Numbering.Next("TXN"), WarehouseId = whAux, MaterialId = aa.MaterialId, OrderId = orderId,
                            MovementType = MovementType.Outbound, QtyKg = aa.Qty,
                            ReferenceDocType = ReferenceDocType.MaterialIssue, ReferenceDocNumber = closing.DocumentNumber, IsApproved = true
                        });
                    }
            }
            Db.SaveChanges();
            if (emptyCartonsActual != null)
            {
                // تأكيد فعلي إجمالي: يُرحَّل لنوع الوعاء الغالب
                int domKey = estByPack.OrderByDescending(kv => kv.Value).Select(kv => kv.Key).FirstOrDefault();
                int? dominant = domKey == NoPack ? null : domKey;
                cartonSvc.PostEmptyCartons(emptyCartonsActual.Value, closing.DocumentNumber, cartonWarehouseId, dominant);
            }
            else
                foreach (var kv in estByPack)
                    cartonSvc.PostEmptyCartons(Math.Round(kv.Value), closing.DocumentNumber, cartonWarehouseId,
                        kv.Key == NoPack ? null : kv.Key);

            // §B85/H1: توحيد المسارين — إقفال البنود يصرف خامه فعلياً (كان يُسجَّل الإنتاج دون صرف في هذا المسار)
            foreach (var kv in consumeByLot)
            {
                var lotC = Db.Lots.FirstOrDefault(l => l.Id == kv.Key);
                if (lotC == null || kv.Value <= 0) continue;
                ConsumeLot(lotC.Id, kv.Value, "إقفال بند الخطة");
                PostStockMovement(WarehouseId("WRM"), MovementType.Outbound, kv.Value, 0,
                    ReferenceDocType.ProductionExecution, closing.DocumentNumber,
                    productId: lotC.ProductId, lotId: lotC.Id, customerId: lotC.CustomerId,
                    notes: "صرف خام فعلي عند إقفال بند الخطة");
            }

            // §B86: تطبيق المرتجع المجمّع — حركة واحدة لكل دفعة (رصيد الدفعة + حركة موثقة)
            foreach (var kv in returnByLot)
            {
                var lotR = Db.Lots.FirstOrDefault(l => l.Id == kv.Key);
                if (lotR == null || kv.Value <= 0) continue;
                lotR.InStockQtyKg += kv.Value;
                PostStockMovement(WarehouseId("WRM"), MovementType.Inbound, kv.Value, 0,
                    ReferenceDocType.Return, closing.DocumentNumber,
                    productId: lotR.ProductId, lotId: lotR.Id, customerId: lotR.CustomerId,
                    notes: $"مرتجع متبقي الإقفال إلى مخزن الخام — نفس العميل والدفعة ({lotR.LotCode})");
            }

            // §إعادة احتساب الحجوزات: المخطط خُفض للمنتَج فتحرر المتبقي آلياً
            ApplyReservationsViaPlanning(plan);

            // §الإرسال للفحص — فحص معلّق لكل أمر متأثر (تبريد يومان) — يومية كانت الخطة أو فترية
            if (sendToQuality)
            {
                foreach (var kv in producedByOrder.Where(x => x.Value > 0))
                {
                    Db.QualityChecks.Add(new QualityCheck
                    {
                        DocumentNumber = Numbering.Next("QC"),
                        OrderId = kv.Key,
                        CheckDate = DateTime.Now,
                        CheckType = "نهائي — بعد التبريد (يومان)",
                        TotalCheckedKg = kv.Value,
                        ExpectedCheckDate = DateTime.Today.AddDays(2),
                        Status = DocStatuses.Submitted
                    });
                }
            }
            Db.SaveChanges();

            // §اكتملت كل البنود ← إقفال الخطة استعداداً لخطة/أمر الغد
            string planMsg = "";
            var auto = _planning.TryAutoCloseIfComplete(planId);
            if (auto.Ok) planMsg = "\n" + auto.Message;

            string qMsg = sendToQuality
                ? $"\n🔬 أُرسل الإنتاج للفحص — النتيجة متوقعة {DateTime.Today.AddDays(2):dd/MM/yyyy} (فترة تبريد يومان)." +
                  "\nالتسليم لمخزن التام مسموح الآن؛ تسليم العميل بانتظار اعتماد الفحص."
                : "";
            return OpResult.Success(
                $"🔒 أُقفلت {closing.Items.Count} بنداً من الخطة {plan.DocumentNumber}: المنتَج {totalProduced:N1} كجم" +
                (totalReturned > 0 ? $" | أُعيد للمخزن الخام {totalReturned:N1} كجم (بنفس العملاء والدفعات)" : "") +
                (closing.Downtimes.Count > 0 ? $" | توقفات: {closing.Downtimes.Sum(d => d.Hours):N1} س" : "") +
                qMsg + planMsg, closing.Id, closing.DocumentNumber);
        });
    }

    /// <summary>إعادة احتساب الحجوزات عبر خدمة التخطيط (تفادياً لازدواج المنطق).</summary>
    private void ApplyReservationsViaPlanning(ProductionPlan plan)
        => RefreshLotReservations(plan.Items.Where(i => i.LotId != null).Select(i => i.LotId.Value));

    /// <summary>§B85/H1: إعادة احتساب الحجز المخزن للدفعات — تُستدعى بعد كل إقفال (يوم/بنود).</summary>
    private void RefreshLotReservations(IEnumerable<int> lotIds)
    {
        // الحجز = مجموع (المخطط − المنتَج) في الخطط النشطة
        foreach (var lid in lotIds.Distinct())
        {
            var lot = Db.Lots.FirstOrDefault(l => l.Id == lid);
            if (lot == null) continue;
            double reserved = Db.ProductionPlanItems
                .Where(i => i.LotId == lid)
                .Join(Db.ProductionPlans, i => i.PlanId, p => p.Id, (i, p) => new { i, p })
                .Where(x => x.p.Status != DocStatuses.Closed && x.p.Status != DocStatuses.Cancelled && !x.p.IsClosed)
                .Where(x => !x.i.IsClosed)
                .Sum(x => x.i.PlannedQtyKg - x.i.ProducedQtyKg);
            lot.ReservedQtyKg = Math.Max(0, reserved);
        }
    }
}

/// <summary>§7 — فحص الجودة مع منع تكرار الفحص لنفس الجلسة (§8).</summary>
public class QualityService : ServiceBase, IQualityService
{
    public QualityService(DatesErpDbContext db, ICurrentSession session, INumberingService numbering)
        : base(db, session, numbering) { }

    public OpResult SaveCheck(int? orderId, int? executionId, string checkDate, string checkType, List<QualityItemDto> items,
        List<(int byProductId, double qtyKg)> byProducts = null, QualityLabDto lab = null)
    {
        Require("quality", "Create");
        if (items == null || items.Count == 0) return OpResult.Fail("أدخل بنداً واحداً على الأقل في الفحص.");
        if (executionId != null && Db.QualityChecks.Any(c => c.ExecutionId == executionId && c.IsApproved))
            return OpResult.Fail("يوجد فحص معتمد مسبقاً لجلسة التنفيذ هذه — لا يسمح بتكرار الفحص.");

        // §مسار الإقفال: إن وُجد فحص معلّق أُنشئ عند الإقفال اليومي تُستكمل نتيجته هنا (بلا تكرار)
        var check = executionId != null
            ? Db.QualityChecks.Include(c => c.Items).FirstOrDefault(c => c.ExecutionId == executionId && !c.IsApproved)
            : null;
        // §تتبع الصنف: الأمر وبنوده — الفحص لا يقبل أصنافاً خارج الأمر
        var order = Db.ProductionOrders.AsNoTracking().Include(o => o.Items).FirstOrDefault(o => o.Id == orderId);

        return RunOp(() =>
        {
            if (check == null)
            {
                check = new QualityCheck
                {
                    DocumentNumber = Numbering.Next("QC"),
                    OrderId = orderId,
                    ExecutionId = executionId,
                    Status = DocStatuses.Draft
                };
                Db.QualityChecks.Add(check);
            }
            else
            {
                // استكمال فحص الإقفال المعلَّق: استبدال بنوده المؤقتة بالنتيجة الفعلية
                if (check.Items.Count > 0) Db.QualityCheckItems.RemoveRange(check.Items);
                check.Items.Clear();
                check.OrderId = orderId;
            }
            check.CheckDate = UiFormat.TryParseDate(checkDate, out var d) ? d : DateTime.Now;
            check.CheckType = checkType ?? "نهائي";
            // §إصلاح: تاريخ الفحص المتوقع كان يُملأ من مسار الإقفال فقط، فيظهر فارغاً
            // في رسالة تسليم التام عندما يُنشأ الفحص من شاشة الجودة مباشرة.
            if (check.ExpectedCheckDate == null)
                check.ExpectedCheckDate = (UiFormat.TryParseDate(checkDate, out var cd2) ? cd2 : DateTime.Today).AddDays(2);
            foreach (var it in items)
            {
                if (it.AcceptedQtyKg < 0 || it.RejectedQtyKg < 0) throw new DomainException("الكميات لا يمكن أن تكون سالبة.");

                // §نظام الوحدات: بنود الفحص منتجات تامة فقط (المجموعة 002)
                UnitsPolicy.RequireItemType(Db, it.ProductId, "Finished", "بند فحص الجودة");

                // §تتبع الصنف: الفحص يستقبل فقط أصناف الأمر بهويتها الفعلية — لا صنف خارج الأمر
                if (order != null && order.Items.Count > 0 && !order.Items.Any(i => i.ProductId == it.ProductId))
                {
                    string name = Db.Products.AsNoTracking().Where(p => p.Id == it.ProductId).Select(p => p.ProductNameAr).FirstOrDefault() ?? $"#{it.ProductId}";
                    throw new DomainException(
                        $"⛔ الصنف «{name}» ليس من بنود أمر الإنتاج {order.DocumentNumber}.\n" +
                        "الفحص يستقبل منتجات الأمر بهويتها الفعلية فقط — لا يمكن فحص صنف لم يُنتج في هذا الأمر.",
                        "FOREIGN_PRODUCT");
                }
                // §تتبع الصنف: لا يُفحص خلاص مرتبط بدفعة سكري
                ProductIdentityGuard.EnsureConversionAllowed(Db, it.ProductId, it.LotId);

                check.Items.Add(new QualityCheckItem
                {
                    ProductId = it.ProductId,
                    LotId = it.LotId,
                    CheckedQtyKg = it.CheckedQtyKg > 0 ? it.CheckedQtyKg : it.AcceptedQtyKg + it.RejectedQtyKg,
                    AcceptedQtyKg = it.AcceptedQtyKg,
                    RejectedQtyKg = it.RejectedQtyKg,
                    Notes = it.Notes
                });
            }

            // §قرار الجودة ومعايير الفحص المخبري والحسي (المواصفة القياسية المعتمدة للتمور)
            if (lab != null)
            {
                check.Decision = lab.Decision is "Passed" or "Quarantine" or "Rejected" ? lab.Decision : "Passed";
                check.MoisturePct = lab.MoisturePct;
                check.BrixDeg = lab.BrixDeg;
                check.SkinSeparationPct = lab.SkinSeparationPct;
                check.ImpuritiesPct = lab.ImpuritiesPct;
                check.SampleCartons = lab.SampleCartons;
                check.InspectorNotes = lab.InspectorNotes;
            }
            check.TotalCheckedKg = check.Items.Sum(i => i.CheckedQtyKg);
            check.AcceptedKg = check.Items.Sum(i => i.AcceptedQtyKg);
            check.RejectedKg = check.Items.Sum(i => i.RejectedQtyKg);
            Db.SaveChanges();

            if (byProducts != null)
                foreach (var (bpId, qty) in byProducts)
                {
                    // §نظام الوحدات: المخرجات الثانوية (003) أصناف ثانوية معرفة وبالكيوجرام فقط — لا كراتين
                    if (!Db.ByProducts.Any(b => b.Id == bpId))
                        throw new DomainException("الصنف الثانوي غير موجود في بطاقة الأصناف الثانوية.");
                    if (qty < 0) throw new DomainException("كمية المخرج الثانوي لا يمكن أن تكون سالبة.");
                    Db.QualityByProductRecords.Add(new QualityByProductRecord { CheckId = check.Id, ByProductId = bpId, QtyKg = qty });
                }

            Db.SaveChanges();
            return OpResult.Success($"تم حفظ فحص الجودة {check.DocumentNumber} — مقبول {check.AcceptedKg:N1} كجم.", check.Id, check.DocumentNumber);
        });
    }

    public OpResult ApproveCheck(int checkId)
    {
        Require("quality", "Approve");
        var check = Db.QualityChecks.FirstOrDefault(c => c.Id == checkId);
        if (check == null) return OpResult.Fail("الفحص غير موجود.");
        if (check.IsApproved) return OpResult.Fail("الفحص معتمد مسبقاً.");

        return RunOp(() =>
        {
            check.IsApproved = true;
            check.Status = DocStatuses.Approved;
            check.ApprovedBy = Session?.UserId;
            check.ApprovedDate = DateTime.Now;
            Db.SaveChanges();
            // §الخطة الطويلة: مزامنة المقبول إلى بنود الخطة المرتبطة (بعد الحفظ) — الفحص اليدوي بلا أمر
            if (check.OrderId != null) PlanSync.SyncAccepted(Db, check.OrderId.Value);
            Db.SaveChanges();
            string decAr = check.Decision switch { "Quarantine" => " (قرار: حجز وتحريز مؤقت)", "Rejected" => " (قرار: مرفوض/عوادم)", _ => "" };
            return OpResult.Success($"تم اعتماد فحص الجودة{decAr}.", check.Id, check.DocumentNumber);
        });
    }
}


/// <summary>مزامنة تقدم بنود الخطة من أوامر الإنتاج والتسليمات.</summary>
public static class PlanSync
{
    /// <summary>المنتَج: يوزع إنتاج بنود الأمر على بنود الخطة المرتبطة ويحدّث حالة التنفيذ.</summary>
    public static void SyncProduced(DatesErp.Infrastructure.Persistence.DatesErpDbContext db, int orderId)
    {
        var orderItems = db.ProductionOrderItems.Where(i => i.OrderId == orderId && i.PlanItemId != null).ToList();
        foreach (var oi in orderItems)
        {
            var pi = db.ProductionPlanItems.FirstOrDefault(x => x.Id == oi.PlanItemId);
            if (pi == null) continue;
            pi.ProducedQtyKg = db.ProductionOrderItems.Where(x => x.PlanItemId == pi.Id).Sum(x => x.ProducedQtyKg);
            UpdateStatus(pi);
        }
    }

    /// <summary>المقبول: من فحوصات الجودة المعتمدة عبر بنود الأمر.</summary>
    public static void SyncAccepted(DatesErp.Infrastructure.Persistence.DatesErpDbContext db, int orderId)
    {
        var orderItems = db.ProductionOrderItems.Where(i => i.OrderId == orderId && i.PlanItemId != null).ToList();
        foreach (var oi in orderItems)
        {
            var pi = db.ProductionPlanItems.FirstOrDefault(x => x.Id == oi.PlanItemId);
            if (pi == null) continue;
            double accepted = db.QualityCheckItems
                .Where(q => q.CheckId != 0)
                .Join(db.QualityChecks, q => q.CheckId, c => c.Id, (q, c) => new { q, c })
                .Where(x => x.c.OrderId == orderId && x.c.IsApproved && x.q.ProductId == oi.ProductId)
                .Sum(x => x.q.AcceptedQtyKg);
            pi.AcceptedQtyKg = Math.Min(pi.PlannedQtyKg, accepted);
            UpdateStatus(pi);
        }
    }

    /// <summary>§B86/M5: المسلَّم يوزع على بنود (العميل + الصنف + العبوة) حسب التاريخ — كان الكيلو الأعمى يملأ أصنافاً أخرى.</summary>
    public static void SyncDeliveredForCustomer(DatesErp.Infrastructure.Persistence.DatesErpDbContext db, int customerId, int productId, int? packagingTypeId, double qtyKg)
    {
        var remaining = qtyKg;
        var items = db.ProductionPlanItems
            .Where(i => i.CustomerId == customerId && i.ProductId == productId && i.ScheduledDate != null
                && (packagingTypeId == null || i.PackagingTypeId == packagingTypeId))
            .OrderBy(i => i.ScheduledDate).ThenBy(i => i.PriorityNo)
            .ToList();
        foreach (var pi in items)
        {
            if (remaining <= 0) break;
            double slot = pi.PlannedQtyKg - pi.DeliveredQtyKg;
            if (slot <= 0) continue;
            double take = Math.Min(slot, remaining);
            pi.DeliveredQtyKg += take;
            remaining -= take;
            UpdateStatus(pi);
        }
    }

    public static void UpdateStatus(DatesErp.Core.Domain.Entities.ProductionPlanItem pi)
    {
        if (pi.ProducedQtyKg <= 0 && pi.DeliveredQtyKg <= 0) pi.ExecutionStatus = "NotStarted";
        else if (pi.ProducedQtyKg + 0.001 >= pi.PlannedQtyKg && pi.DeliveredQtyKg + 0.001 >= pi.PlannedQtyKg) pi.ExecutionStatus = "Completed";
        else if (pi.DeliveredQtyKg > 0) pi.ExecutionStatus = "Partial";
        else pi.ExecutionStatus = "InProgress";
    }
}
