using DatesErp.Core.Common;
using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Domain.Enums;
using DatesErp.Core.Exceptions;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

/// <summary>§7 — خطط الإنتاج: حجز كميات الدفعات لكل الأصناف + فحص طاقة الورديات + رفض التجاوز.</summary>
public class PlanningService : ServiceBase, IPlanningService
{
    public PlanningService(DatesErpDbContext db, ICurrentSession session, INumberingService numbering)
        : base(db, session, numbering) { }

    /// <summary>§B75: نهاية الفترة حسب النوع — يومية=البداية، أسبوعية=+6 أيام.</summary>
    public static DateTime PeriodEndDate(string planType, DateTime start)
        => planType switch
        {
            "Weekly" => start.AddDays(6),
            "Monthly" => start.AddMonths(1).AddDays(-1),   // §B77 شهرية: حتى نهاية الشهر
            _ => start
        };

    public OpResult SavePlan(string title, string planType, string startDate, string endDate, int? shiftId, int? lineId, List<PlanItemDto> items, string notes = null, string scopeMode = null, int? singleCustomerId = null)
    {
        Require("planning", "Create");
        if (items == null || items.Count == 0) return OpResult.Fail("أدخل بنداً واحداً على الأقل في الخطة.");

        return RunOp(() =>
        {
            var plan = new ProductionPlan
            {
                DocumentNumber = Numbering.Next("PLAN"),
                PlanTitle = title,
                PlanType = planType ?? "Daily",
                ScopeMode = scopeMode ?? "Multi",
                SingleCustomerId = singleCustomerId,
                StartDate = UiFormat.TryParseDate(startDate, out var sd) ? sd : null,
                EndDate = UiFormat.TryParseDate(endDate, out var ed) ? ed : null,
                ShiftId = shiftId,
                LineId = lineId,
                Status = DocStatuses.Draft,
                Notes = notes
            };
            Db.ProductionPlans.Add(plan);
            Db.SaveChanges();

            // §الخطة الطويلة: لكل بند تاريخ إنتاج إلزامي داخل فترة الخطة.
            // بدونه كان البند بلا تاريخ يتخطى فحص الطاقة كلياً (الحارس يشترط ScheduledDate != null).
            // §B80: + رفض أي تاريخ بند خارج فترة الخطة.
            ApplyDefaultScheduledDates(items, sd, ed);
            // §B76: خطة العميل الواحد لا تقبل تسريب عملاء آخرين — فرض من الخلفية لا من الواجهة فقط
            if ((scopeMode ?? "Multi") == "Single" && singleCustomerId != null)
                foreach (var dtoC in items)
                    if (dtoC.CustomerId != singleCustomerId)
                        throw new DomainException("خطة العميل الواحد لا تقبل بنوداً لعميل آخر — كل البنود يجب أن تكون للعميل المحدد في الرأس.");

            // §حرج: حارس الطاقة يشترط وردية على البند، فكان أي بند بلا SuggestedShiftId
            // يتخطى الفحص كلياً وبصمت. البند يرث وردية الخطة وخطها إن لم يُحددا له.
            foreach (var dtoInh in items)
            {
                dtoInh.SuggestedShiftId ??= shiftId;
                dtoInh.SuggestedLineId ??= lineId;
            }
            // §إصلاح حرج: تراكم استهلاك بنود «هذه الخطة نفسها» على نفس اليوم/الوردية/الخط.
            var localUsed = new Dictionary<(DateTime day, int shift, int line), double>();

            foreach (var dto in items)
            {
                // §نظام الوحدات: بنود الخطة منتجات تامة فقط (002) — واتساق الكرتون/الكيلو إلزامي
                UnitsPolicy.RequireItemType(Db, dto.ProductId, "Finished", "خطة الإنتاج");
                dto.PlannedQtyKg = UnitsPolicy.EnsureCartonKgConsistency(Db, dto.ProductId, dto.PackagingTypeId,
                    dto.PlannedQtyKg, dto.PlannedCartons, "خطة الإنتاج");

                // §الإنتاج التام unitه الكرتون: إن أُدخل الوزن بلا كراتين تُشتق الكراتين من
                // وزن كرتون الصنف/العبوة المعرَّف — فتُفحص الطاقة دائماً ولا تُتخطى.
                if (dto.PlannedCartons <= 0 && dto.PlannedQtyKg > 0)
                {
                    double w = UnitsPolicy.CartonWeight(Db, dto.ProductId, dto.PackagingTypeId);
                    if (w > 0) dto.PlannedCartons = (int)Math.Round(dto.PlannedQtyKg / w);
                }

                // §قاعدة توازن الإنتاج: المخطط كمية منتج تام مستهدفة، لا حجزاً للخام.
                // وفي تصنيع التمور يزيد وزن الخارج عن الداخل لإضافة الماء أثناء التشغيل،
                // فالتخطيط بكمية أكبر من رصيد الخام مشروع — ولا معادلة ثابتة تربطهما.
                // الحجز الفعلي للخام يتم عند اعتماد الأمر، وهناك يُمنع تجاوز الرصيد فعلاً.
                if (dto.SourceType == "FromReceiving" && dto.LotId is int lotId)
                {
                    if (!Db.Lots.AsNoTracking().Any(l => l.Id == lotId))
                        throw new DomainException("الدفعة المحددة غير موجودة.");
                }

                // §تتبع الصنف: التحويل الرسمي — لا يخطط خلاص من دفعة سكري ولا سكري من دفعة خلاص
                ProductIdentityGuard.EnsureConversionAllowed(Db, dto.ProductId, dto.LotId);

                // §3/§8 — فحص الطاقة الإنتاجية للوردية في اليوم المحدد (لكل بند)
                // مع تراكم بنود هذه الخطة نفسها — لا يكفي استثناء الخطة من خطط الآخرين.
                EnsureSlotCapacity(plan, dto, localUsed);

                // §الملكية: دفعة العميل لا تُخطط إلا باسم صاحبها — لا دمج ولا تداخل
                if (dto.LotId is int lotOwn && dto.CustomerId is int custOwn)
                {
                    var lotOwner = Db.Lots.AsNoTracking().Where(l => l.Id == lotOwn).Select(l => l.CustomerId).FirstOrDefault();
                    if (lotOwner != null && lotOwner != custOwn)
                        throw new DomainException("الدفعة المحددة مملوكة لعميل آخر — لا يمكن تخطيطها لعميل مختلف.", "OWNERSHIP");
                }

                plan.Items.Add(new ProductionPlanItem
                {
                    PlanId = plan.Id,
                    SourceType = dto.SourceType,
                    LotId = dto.LotId,
                    ShipmentId = dto.ShipmentId ?? (dto.LotId != null ? Db.Lots.Where(l => l.Id == dto.LotId).Select(l => l.ShipmentId).FirstOrDefault() : null),
                    CustomerId = dto.CustomerId,
                    ProductId = dto.ProductId,
                    PackagingTypeId = dto.PackagingTypeId,
                    PlannedQtyKg = dto.PlannedQtyKg,
                    PlannedCartons = dto.PlannedCartons,
                    ScheduledDate = UiFormat.TryParseDate(dto.ScheduledDate, out var d) ? d : null,
                    SuggestedShiftId = dto.SuggestedShiftId,
                    SuggestedLineId = dto.SuggestedLineId,
                    PriorityNo = dto.PriorityNo,
                    Status = DocStatuses.Draft
                });
            }

            // حجز كميات الدفعات (لكل الأصناف) بمجرد إنشاء الخطة
            ApplyLotReservations(plan);
            Db.SaveChanges();
            return OpResult.Success("تم حفظ خطة الإنتاج بنجاح.", plan.Id, plan.DocumentNumber);
        });
    }

    /// <summary>
    /// §تعديل خطة قائمة (مسودة غير معتمدة): يستبدل البنود ويعيد فحص الطاقة والأرصدة والحجوزات.
    /// يعالج حجز الخطة القديم صحيحاً (يُستثنى من فحص المتاح حتى لا يُحتسب مرتين).
    /// </summary>
    public OpResult UpdatePlan(int planId, string title, string planType, string startDate, string endDate, int? shiftId, int? lineId, List<PlanItemDto> items, string notes = null, string scopeMode = null, int? singleCustomerId = null)
    {
        Require("planning", "Edit");
        if (items == null || items.Count == 0) return OpResult.Fail("أضف بنداً واحداً على الأقل في الخطة.");

        return RunOp(() =>
        {
            var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId)
                       ?? throw new DomainException("الخطة غير موجودة.");
            if (plan.IsApproved) throw new DomainException("الخطة معتمدة — ألغِ الاعتماد أولاً للتعديل.");
            if (plan.IsClosed) throw new DomainException("الخطة مقفلة — لا يمكن التعديل.");

            plan.PlanTitle = title;
            plan.PlanType = planType ?? "Daily";
            plan.ScopeMode = scopeMode ?? plan.ScopeMode ?? "Multi";
            plan.SingleCustomerId = singleCustomerId;
            plan.StartDate = UiFormat.TryParseDate(startDate, out var sd) ? sd : null;
            plan.EndDate = UiFormat.TryParseDate(endDate, out var ed) ? ed : null;
            plan.ShiftId = shiftId;
            plan.LineId = lineId;
            plan.Notes = notes;

            // حذف البنود القديمة (ستُستبدل) — مع تحرير حجوزاتها ضمنياً بالاستثناء من الفحص
            Db.ProductionPlanItems.RemoveRange(plan.Items);
            plan.Items.Clear();

            // §الخطة الطويلة: لكل بند تاريخ إنتاج إلزامي داخل فترة الخطة.
            // §B80: + رفض أي تاريخ بند خارج فترة الخطة.
            ApplyDefaultScheduledDates(items, sd, ed);
            // §B76: خطة العميل الواحد لا تقبل تسريب عملاء آخرين — فرض من الخلفية لا من الواجهة فقط
            if ((scopeMode ?? "Multi") == "Single" && singleCustomerId != null)
                foreach (var dtoC in items)
                    if (dtoC.CustomerId != singleCustomerId)
                        throw new DomainException("خطة العميل الواحد لا تقبل بنوداً لعميل آخر — كل البنود يجب أن تكون للعميل المحدد في الرأس.");

            // §حرج: حارس الطاقة يشترط وردية على البند، فكان أي بند بلا SuggestedShiftId
            // يتخطى الفحص كلياً وبصمت. البند يرث وردية الخطة وخطها إن لم يُحددا له.
            foreach (var dtoInh in items)
            {
                dtoInh.SuggestedShiftId ??= shiftId;
                dtoInh.SuggestedLineId ??= lineId;
            }
            // §إصلاح حرج: تراكم استهلاك بنود «هذه الخطة نفسها» على نفس اليوم/الوردية/الخط.
            var localUsed = new Dictionary<(DateTime day, int shift, int line), double>();

            foreach (var dto in items)
            {
                // §نظام الوحدات: بنود الخطة منتجات تامة فقط (002) — واتساق الكرتون/الكيلو إلزامي
                UnitsPolicy.RequireItemType(Db, dto.ProductId, "Finished", "خطة الإنتاج");
                dto.PlannedQtyKg = UnitsPolicy.EnsureCartonKgConsistency(Db, dto.ProductId, dto.PackagingTypeId,
                    dto.PlannedQtyKg, dto.PlannedCartons, "خطة الإنتاج");

                // §الإنتاج التام unitه الكرتون: إن أُدخل الوزن بلا كراتين تُشتق الكراتين من
                // وزن كرتون الصنف/العبوة المعرَّف — فتُفحص الطاقة دائماً ولا تُتخطى.
                if (dto.PlannedCartons <= 0 && dto.PlannedQtyKg > 0)
                {
                    double w = UnitsPolicy.CartonWeight(Db, dto.ProductId, dto.PackagingTypeId);
                    if (w > 0) dto.PlannedCartons = (int)Math.Round(dto.PlannedQtyKg / w);
                }

                // §كما في SavePlan: المخطط مستهدف إنتاجي لا حجز خام — لا معادلة ثابتة
                if (dto.SourceType == "FromReceiving" && dto.LotId is int lotId)
                {
                    if (!Db.Lots.AsNoTracking().Any(l => l.Id == lotId))
                        throw new DomainException("الدفعة المحددة غير موجودة.");
                }

                // §تتبع الصنف: التحويل الرسمي — لا يخطط خلاص من دفعة سكري ولا سكري من دفعة خلاص
                ProductIdentityGuard.EnsureConversionAllowed(Db, dto.ProductId, dto.LotId);

                // §3/§8 — فحص الطاقة الإنتاجية للوردية في اليوم المحدد (باستثناء هذه الخطة)
                // مع تراكم بنود هذه الخطة نفسها — لا يكفي استثناء الخطة من خطط الآخرين.
                EnsureSlotCapacity(plan, dto, localUsed);

                // §الملكية: دفعة العميل لا تُخطط إلا باسم صاحبها
                if (dto.LotId is int lotOwn && dto.CustomerId is int custOwn)
                {
                    var lotOwner = Db.Lots.AsNoTracking().Where(l => l.Id == lotOwn).Select(l => l.CustomerId).FirstOrDefault();
                    if (lotOwner != null && lotOwner != custOwn)
                        throw new DomainException("الدفعة المحددة مملوكة لعميل آخر — لا يمكن تخطيطها لعميل مختلف.", "OWNERSHIP");
                }

                plan.Items.Add(new ProductionPlanItem
                {
                    PlanId = plan.Id,
                    SourceType = dto.SourceType,
                    LotId = dto.LotId,
                    ShipmentId = dto.ShipmentId ?? (dto.LotId != null ? Db.Lots.Where(l => l.Id == dto.LotId).Select(l => l.ShipmentId).FirstOrDefault() : null),
                    CustomerId = dto.CustomerId,
                    ProductId = dto.ProductId,
                    PackagingTypeId = dto.PackagingTypeId,
                    PlannedQtyKg = dto.PlannedQtyKg,
                    PlannedCartons = dto.PlannedCartons,
                    ScheduledDate = UiFormat.TryParseDate(dto.ScheduledDate, out var d) ? d : null,
                    SuggestedShiftId = dto.SuggestedShiftId,
                    SuggestedLineId = dto.SuggestedLineId,
                    PriorityNo = dto.PriorityNo,
                    Status = DocStatuses.Draft
                });
            }

            // إعادة احتساب الحجوزات بالبنود الجديدة
            ApplyLotReservations(plan);
            Db.SaveChanges();
            return OpResult.Success("تم تحديث خطة الإنتاج بنجاح.", plan.Id, plan.DocumentNumber);
        });
    }

    /// <summary>المتاح الفعلي من دفعة بعد خصم حجوزات الخطط النشطة والأوامر، مع استثناء خطة محددة.</summary>
    private double LotAvailableExcluding(int lotId, int? excludePlanId)
    {
        var lot = Db.Lots.AsNoTracking().FirstOrDefault(l => l.Id == lotId);
        if (lot == null) return 0;
        double planCommitted = Db.ProductionPlanItems.AsNoTracking()
            .Where(i => i.LotId == lotId && (excludePlanId == null || i.PlanId != excludePlanId))
            .Join(Db.ProductionPlans.AsNoTracking(), i => i.PlanId, p => p.Id, (i, p) => new { i, p })
            .Where(x => x.p.Status != DocStatuses.Closed && x.p.Status != DocStatuses.Cancelled && !x.p.IsClosed)
            .Where(x => !x.i.IsClosed)
            .Sum(x => x.i.PlannedQtyKg - x.i.ProducedQtyKg > 0 ? x.i.PlannedQtyKg - x.i.ProducedQtyKg : 0);
        double orderCommitted = Db.ProductionOrderItems.AsNoTracking()
            .Where(i => i.LotId == lotId)
            .Join(Db.ProductionOrders.AsNoTracking(), i => i.OrderId, o => o.Id, (i, o) => new { i, o })
            .Where(x => x.o.Status != DocStatuses.Cancelled && x.o.Status != DocStatuses.Closed)
            .Where(x => !x.i.IsClosed)
            .Sum(x => x.i.PlannedQtyKg - x.i.ProducedQtyKg > 0 ? x.i.PlannedQtyKg - x.i.ProducedQtyKg : 0);
        return Math.Max(0, Math.Round(lot.InStockQtyKg - planCommitted - orderCommitted, 3));
    }

    private void ApplyLotReservations(ProductionPlan plan)
    {
        // تصفير حجوزات هذه الخطة السابقة ثم إعادة الاحتساب — يدعم التعديل متعدد الأصناف
        var lotIds = plan.Items.Where(i => i.LotId != null).Select(i => i.LotId.Value).Distinct().ToList();
        foreach (var lid in lotIds)
        {
            var lot = Db.Lots.FirstOrDefault(l => l.Id == lid);
            if (lot == null) continue;
            // الحجز = المتبقي غير المنتَج من مخطط الخطط النشطة (المنتَج استُهلك خامه أو أُنتج)
            double reserved = Db.ProductionPlanItems
                .Where(i => i.LotId == lid && i.PlanId != plan.Id)
                .Join(Db.ProductionPlans, i => i.PlanId, p => p.Id, (i, p) => new { i, p })
                .Where(x => x.p.Status != DocStatuses.Closed && x.p.Status != DocStatuses.Cancelled && !x.p.IsClosed)
                .Where(x => !x.i.IsClosed)
                .Sum(x => x.i.PlannedQtyKg - x.i.ProducedQtyKg);
            lot.ReservedQtyKg = Math.Max(0, reserved);
        }
        // §الخطة المقفلة/الملغاة تُحرر حجوزاتها — لا تُعاد إضافتها
        bool planStillActive = plan.Status != DocStatuses.Closed && plan.Status != DocStatuses.Cancelled && !plan.IsClosed;
        if (planStillActive)
        {
            foreach (var lid in plan.Items.Where(i => i.LotId != null).Select(i => i.LotId.Value).Distinct())
            {
                var lot = Db.Lots.First(l => l.Id == lid);
                lot.ReservedQtyKg += Math.Max(0, plan.Items.Where(i => i.LotId == lid && !i.IsClosed).Sum(i => i.PlannedQtyKg - i.ProducedQtyKg));
            }
        }
    }

    /// <summary>§الطاقة اللحظية: المتاح/المستخدم/المتبقي للوردية والخط في تاريخ محدد.</summary>
    public ShiftCapacityInfo GetShiftCapacityInfo(int shiftId, int lineId, string date, int? productId = null, int? excludePlanId = null)
    {
        var (used, eff, rate) = ShiftUsageHours(shiftId, lineId, date, productId ?? 0, excludePlanId);
        var shift = Db.Shifts.FirstOrDefault(s => s.Id == shiftId);
        return new ShiftCapacityInfo
        {
            ShiftName = shift?.ShiftNameAr ?? "-",
            TotalHours = eff,
            UsedHours = used,
            RemainingHours = Math.Max(0, Math.Round(eff - used, 2)),
            HourlyRate = rate,
            MaxCartons = (int)(eff * rate),
            RemainingCartons = (int)(Math.Max(0, eff - used) * rate)
        };
    }

    /// <summary>
    /// §المتاح لصنف محدد من دفعة (مطابق لـ v1.60 product_lot_remaining): يخصم فقط حجوزات
    /// هذا الصنف من الخطط النشطة لا حجوزات الأصناف الأخرى — فلا تداخل بين أصناف الدفعة الواحدة.
    /// سكري: رصيد الدفعة − حجوز سكري فقط | برمي: رصيد الدفعة − حجوز برمي فقط.
    /// </summary>
    public double GetProductLotRemaining(int lotId, int productId, int? excludePlanId = null)
    {
        var lot = Db.Lots.AsNoTracking().FirstOrDefault(l => l.Id == lotId);
        if (lot == null) return 0;

        // حجوزات هذا الصنف فقط من بنود الخطط النشطة (غير المقفلة/الملغاة)
        var planCommitted = Db.ProductionPlanItems.AsNoTracking()
            .Where(i => i.LotId == lotId && i.ProductId == productId
                        && (excludePlanId == null || i.PlanId != excludePlanId))
            .Join(Db.ProductionPlans.AsNoTracking(), i => i.PlanId, p => p.Id, (i, p) => new { i, p })
            .Where(x => x.p.Status != DocStatuses.Closed && x.p.Status != DocStatuses.Cancelled && !x.p.IsClosed)
            .Where(x => !x.i.IsClosed)
            .Sum(x => x.i.PlannedQtyKg - x.i.ProducedQtyKg > 0 ? x.i.PlannedQtyKg - x.i.ProducedQtyKg : 0);

        // حجوزات هذا الصنف من أوامر الإنتاج النشطة (غير الملغاة/المكتملة)
        var orderCommitted = Db.ProductionOrderItems.AsNoTracking()
            .Where(i => i.LotId == lotId && i.ProductId == productId)
            .Join(Db.ProductionOrders.AsNoTracking(), i => i.OrderId, o => o.Id, (i, o) => new { i, o })
            .Where(x => x.o.Status != DocStatuses.Cancelled && x.o.Status != DocStatuses.Closed)
            .Where(x => !x.i.IsClosed)
            .Sum(x => x.i.PlannedQtyKg - x.i.ProducedQtyKg > 0 ? x.i.PlannedQtyKg - x.i.ProducedQtyKg : 0);

        return Math.Max(0, Math.Round(lot.InStockQtyKg - planCommitted - orderCommitted, 3));
    }

    /// <summary>§7 — إرسال الخطة للمدير العام للاعتماد الرسمي.</summary>
    public OpResult SubmitPlan(int planId)
    {
        Require("planning", "Edit");
        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");
        if (plan.IsApproved) return OpResult.Fail("الخطة معتمدة مسبقاً.");
        if (plan.Items.Count == 0) return OpResult.Fail("لا يمكن إرسال خطة بدون بنود.");
        return RunOp(() =>
        {
            plan.Status = "UnderApproval";
            Db.SaveChanges();
            return OpResult.Success("تم إرسال الخطة للاعتماد الرسمي.", plan.Id, plan.DocumentNumber);
        });
    }

    /// <summary>إرجاع الخطة للمخطط للتعديل مع ملاحظات.</summary>
    public OpResult ReturnPlan(int planId, string notes)
    {
        Require("planning", "Approve");
        var plan = Db.ProductionPlans.FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");
        if (plan.IsApproved) return OpResult.Fail("الخطة معتمدة — استخدم إلغاء الاعتماد.");
        return RunOp(() =>
        {
            plan.Status = DocStatuses.Draft;
            plan.Notes = string.IsNullOrWhiteSpace(notes) ? plan.Notes : ("ملاحظات الإرجاع: " + notes);
            Db.SaveChanges();
            return OpResult.Success("تم إرجاع الخطة للتعديل.", plan.Id, plan.DocumentNumber);
        });
    }

    public OpResult UnapprovePlan(int planId)
    {
        Require("planning", "Cancel");
        var plan = Db.ProductionPlans.FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");
        if (!plan.IsApproved) return OpResult.Fail("الخطة غير معتمدة.");
        if (Db.ProductionOrders.Any(o => o.SourcePlanId == planId))
            return OpResult.Fail("لا يمكن إلغاء الاعتماد: صدرت أوامر إنتاج من هذه الخطة.");
        return RunOp(() =>
        {
            plan.IsApproved = false;
            plan.Status = DocStatuses.Draft;
            ApplyLotReservations(plan); // إعادة احتساب الحجوزات بدون هذه الخطة
            Db.SaveChanges();
            return OpResult.Success("تم إلغاء اعتماد الخطة وإعادة فتحها للتعديل.", plan.Id, plan.DocumentNumber);
        });
    }

    public OpResult DeletePlan(int planId)
    {
        Require("planning", "Delete");
        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");
        if (plan.IsApproved) return OpResult.Fail("لا يمكن حذف خطة معتمدة — ألغِ الاعتماد أولاً.");
        if (Db.ProductionOrders.Any(o => o.SourcePlanId == planId))
            return OpResult.Fail("لا يمكن حذف خطة صدرت منها أوامر إنتاج.");
        return RunOp(() =>
        {
            Db.ProductionPlans.Remove(plan);
            Db.SaveChanges();
            return OpResult.Success("تم حذف الخطة (المسودة).");
        });
    }

    /// <summary>§7 — اعتماد الخطة تصبح معه جاهزة لأوامر الإنتاج.</summary>
    public OpResult ApprovePlan(int planId)
    {
        Require("planning", "Approve");
        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");
        if (plan.IsApproved) return OpResult.Fail("الخطة معتمدة مسبقاً.");
        if (plan.Items.Count == 0) return OpResult.Fail("لا يمكن اعتماد خطة بدون بنود.");

        // §لا خطة فوق خطة (فحص طاقة لا منع أعمى): يُسمح بخطة ثانية في نفس اليوم والوردية
        // ما دامت الطاقة الفعلية المتبقية تكفي، ويُرفض فقط التجاوز الذي يتعدى الطاقة.
        // §إصلاح حرج: تراكم بنود الخطة نفسها على نفس اليوم/الوردية/الخط عند الاعتماد أيضاً.
        var localUsed = new Dictionary<(DateTime day, int shift, int line), double>();
        foreach (var item in plan.Items)
        {
            if (item.PlannedCartons > 0 && item.ScheduledDate != null && item.SuggestedShiftId is int shId)
            {
                int lineId = item.SuggestedLineId ?? 1;
                var (usedOther, cap, rate) = ShiftUsageHours(shId, lineId,
                    item.ScheduledDate.Value.ToString("dd/MM/yyyy"), item.ProductId,
                    excludePlanId: plan.Id, item.PackagingTypeId);
                var key = (item.ScheduledDate.Value.Date, shId, lineId);
                double usedHere = localUsed.TryGetValue(key, out var lu) ? lu : 0;
                double requiredHours = rate > 0 ? item.PlannedCartons / rate : 0;
                double used = usedOther + usedHere;
                if (used + requiredHours > cap + 0.0001)
                {
                    double remainingHours = Math.Max(0, cap - used);
                    int availableCartons = (int)Math.Floor(remainingHours * rate);
                    return OpResult.Fail(
                        $"⛔ لا يمكن اعتماد الخطة: الطاقة الإنتاجية للوردية يوم {item.ScheduledDate:dd/MM/yyyy} لا تكفي.\n" +
                        $"الطاقة المتاحة: {availableCartons:N0} كرتون | المطلوب لهذا البند: {item.PlannedCartons:N0} كرتون\n" +
                        $"(مستهلكة في خطط أخرى {usedOther:N1} س + في بنود هذه الخطة {usedHere:N1} س من أصل {cap:N1} س)\n" +
                        $"قلّل الكمية أو انقل البند ليوم/وردية أخرى بها طاقة متبقية.");
                }
                localUsed[key] = usedHere + requiredHours;
            }
        }

        return RunOp(() =>
        {
            plan.IsApproved = true;
            plan.Status = DocStatuses.Approved;
            plan.ApprovedBy = Session?.UserId;
            plan.ApprovedDate = DateTime.Now;
            foreach (var it in plan.Items) it.Status = DocStatuses.Approved;
            Db.SaveChanges();
            return OpResult.Success("تم اعتماد الخطة — أصبحت جاهزة لإنشاء أوامر الإنتاج.", plan.Id, plan.DocumentNumber);
        });
    }

    public OpResult ClosePlan(int planId, string notes)
    {
        Require("planning", "Cancel");
        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId);
        if (plan == null) return OpResult.Fail("الخطة غير موجودة.");

        return RunOp(() =>
        {
            plan.IsClosed = true;
            plan.ClosedDate = DateTime.Now;
            plan.Status = DocStatuses.Closed;
            plan.Notes = string.IsNullOrWhiteSpace(notes) ? plan.Notes : notes;
            ApplyLotReservations(plan); // تحرير الحجوزات غير المستهلكة
            Db.SaveChanges();
            return OpResult.Success("تم إقفال الخطة نهائياً.");
        });
    }

    /// <summary>§12/§13 — الدفعات المتاحة مع خصم كل الخطط النشطة لكل الأصناف.</summary>
    public List<AvailableLotDto> GetAvailableLots(int? customerId = null)
    {
        var q = Db.Lots.AsQueryable();
        // §B67: فلترة العميل تشمل الدفعات التي ورثت عميلها من سند الاستلام (بيانات قديمة
        // بلا CustomerId على الدفعة) — فلا «تختفي أصناف العميل» أبداً.
        if (customerId != null)
            q = q.Where(l => l.CustomerId == customerId
                || (l.CustomerId == null && Db.Shipments.Any(x => x.Id == l.ShipmentId && x.CustomerId == customerId)));
        return q.Where(l => l.Status == DocStatuses.Approved && l.InStockQtyKg > 0)
            .Select(l => new AvailableLotDto
            {
                LotId = l.Id,
                LotCode = l.LotCode,
                ProductId = l.ProductId,
                ProductName = Db.Products.Where(p => p.Id == l.ProductId).Select(p => p.ProductNameAr).FirstOrDefault(),
                CustomerId = l.CustomerId,
                CustomerName = Db.Customers.Where(c => c.Id == l.CustomerId).Select(c => c.CustomerName).FirstOrDefault(),
                ShipmentId = l.ShipmentId,
                ShipmentNo = Db.Shipments.Where(x => x.Id == l.ShipmentId).Select(x => x.DocumentNumber).FirstOrDefault(),
                ArrivalDate = Db.Shipments.Where(x => x.Id == l.ShipmentId).Select(x => x.ArrivalDate).FirstOrDefault(),
                InitialQtyKg = l.InitialQtyKg,
                ReservedQtyKg = l.ReservedQtyKg,
                // §B64: AvailableQtyKg خاصية محسوبة غير مخزّنة — لا تُترجم في استعلام خادمي؛
                // يُستبدل بالتعبير القابل للترجمة (يطرح العمودين المخزّنين).
                RemainingKg = l.InStockQtyKg - l.ReservedQtyKg
            })
            .Where(l => l.RemainingKg > 0)
            .ToList();
    }

    /// <summary>§B68: الأصناف القابلة للتخطيط من دفعة محددة — يُستبعد كل صنف نفذ رصيده منها.
    /// بلا دفعة (إضافة يدوي/إدارة) تُرجع كل الأصناف التامة.</summary>
    public List<Product> GetPlannableProducts(int? lotId = null)
    {
        var fins = GetFinishedProducts();
        if (lotId == null) return fins;
        return fins.Where(p => GetProductLotRemaining(lotId.Value, p.Id) > 0).ToList();
    }

    /// <summary>
    /// §نافذة الاختيار: الأصناف التامة التي تظهر في قائمة الصنف التام — مطابقة لفلتر v1.59:
    /// (المجموعة 002 أو صنف بلا مجموعة) ونشط. هذا يضمن ظهور أصناف المصنع حتى لو لم تُملأ المجموعة.
    /// </summary>
    /// <summary>§B56: الأصناف التامة فقط — النوع «Finished» هو انتماء مجموعة التام،
    /// فلا تظهر أصناف الخام/الثانوي في قوائم اختيار الصنف التام، وتظهر التامة بمجموعات مخصصة.</summary>
    public List<Product> GetFinishedProducts()
        => Db.Products.AsNoTracking()
            .Where(p => p.IsActive && p.ItemType == "Finished")
            .OrderBy(p => p.ProductNameAr)
            .ToList();

    /// <summary>
    /// ⚖ محرك التوزيع العادل الآلي (نقل خوارزمية v1.59 مع تحسين استغلال اليوم):
    /// • يقرأ كل الأرصدة المتاحة (الرصيد − المحجوز) مرتبة بأقدمية وصول الحاويات (FIFO).
    /// • الحصة اليومية = طاقة الوردية (معدل الصنف × الساعات الفعلية) محولة للكيلو، أو إدخال يدوي.
    /// • لكل يوم: دوّار على العملاء بترتيب (الأقل نسبة إنجاز أولاً ← ثم الأقدم وصولاً) —
    ///   مع تحسين: إن بقي من حصة اليوم شيء بعد عميل رصيده صغير يكمل اليوم بعميل آخر بدل إهدار الطاقة.
    /// • كل بند يحمل مرجعه الكامل + عدد أيام شحنته في المخزن.
    /// النتيجة: لا يُغرق السوق بصنف عميل واحد، ولا ينتظر صاحب الحاوية الواحدة خلف أصحاب الحاويات.
    /// </summary>
    public FairDistributionProposal SuggestFairDistribution(string startDate, string endDate, int shiftId, int lineId,
        int? targetProductId = null, double? dailyKgOverride = null)
    {
        Require("planning", "View");
        var result = new FairDistributionProposal();

        if (!UiFormat.TryParseDate(startDate, out var d0) || !UiFormat.TryParseDate(endDate, out var d1) || d1 < d0)
        { result.Message = "تواريخ الخطة غير صحيحة — حدد فترة سليمة (من ≤ إلى)."; return result; }
        var days = new List<DateTime>();
        for (var d = d0.Date; d <= d1.Date; d = d.AddDays(1)) days.Add(d);

        // §الوردية اختيار إلزامي
        var shift = Db.Shifts.AsNoTracking().FirstOrDefault(s => s.Id == shiftId);
        if (shift == null) { result.Message = "اختر الوردية أولاً — اختيار إلزامي لمعدل الخطة."; return result; }
        double eff = shift.EffectiveProductiveHours > 0 ? shift.EffectiveProductiveHours : (shift.TotalHours > 0 ? shift.TotalHours : 8);

        // الأصناف التامة: صنف مستهدف واحد أو دوّار أصناف تلقائي
        var fins = targetProductId != null
            ? Db.Products.AsNoTracking().Where(p => p.Id == targetProductId.Value && p.IsActive).ToList()
            : GetFinishedProducts();
        if (fins.Count == 0) { result.Message = "لا توجد أصناف تامة معرفّة — أضفها من شاشة الأصناف أولاً."; return result; }

        var packs = Db.PackagingTypes.AsNoTracking().Where(p => p.IsActive).OrderBy(p => p.Id).ToList();
        if (packs.Count == 0) { result.Message = "لا توجد عبوات معرفّة — أضف العبوات أولاً."; return result; }

        int DefaultPackId(Product p) => packs.OrderBy(x => Math.Abs(x.UnitWeightKg - p.CartonWeightKg)).First().Id;
        double PackWeight(int packId) => packs.First(p => p.Id == packId).UnitWeightKg;

        // الحصة اليومية (كجم): تلقائية من طاقة الوردية للصنف المرجعي أو إدخال يدوي
        if (dailyKgOverride > 0)
        {
            result.DailyQuotaKg = dailyKgOverride.Value;
        }
        else
        {
            var refProd = fins[0];
            // §لا معدل افتراضي في الكود: كان يُعوَّض 500 كرتون/ساعة بصمت فتظهر أرقام بلا أساس.
            // الآن يُقرأ بالترتيب المعتمد، والغياب = صفر ولا يُقترح شيء.
            var (rate, _, rateSrc) = CapacityPolicy.Resolve(Db, refProd.Id, shiftId, DefaultPackId(refProd));
            result.DailyQuotaKg = rate > 0
                ? Math.Round(eff * rate * PackWeight(DefaultPackId(refProd)), 0)
                : 0;
            result.CapacityNote = rate > 0
                ? $"المعدل {rate:0.#} كرتون/ساعة ← {rateSrc}"
                : "لا طاقة معرَّفة لهذا الصنف في هذه الوردية — عرّفها من شاشة الأصناف";
        }

        // الأرصدة المتاحة لكل عميل مع أقدمية الحاويات (FIFO حسب تاريخ الوصول)
        var lotsQ = from l in Db.Lots.AsNoTracking()
                    where l.InStockQtyKg - l.ReservedQtyKg > 0.01
                    join s in Db.Shipments.AsNoTracking() on l.ShipmentId equals s.Id into sj
                    from s in sj.DefaultIfEmpty()
                    orderby s.ArrivalDate ascending, l.Id ascending
                    select new LotSeed
                    {
                        Id = l.Id, LotCode = l.LotCode, CustomerId = l.CustomerId ?? 0,
                        ShipmentId = l.ShipmentId, RawProductId = l.ProductId,
                        Remaining = l.InStockQtyKg - l.ReservedQtyKg,
                        ArrivalDate = s.ArrivalDate, ContainerNumber = s.ContainerNumber, ShipmentNo = s.DocumentNumber
                    };
        // §إصلاح: ToDictionary عملية ذاكرية — AsEnumerable قبلها
        var rawNames = Db.Products.AsNoTracking().AsEnumerable().ToDictionary(p => p.Id, p => p.ProductNameAr);
        var custNames = Db.Customers.AsNoTracking().AsEnumerable().ToDictionary(c => c.Id, c => c.CustomerName);
        // §B77: أولوية العميل تُقدَّم على قاعدة الأقل إنجازاً عند التناوب
        var custPrio = Db.Customers.AsNoTracking().AsEnumerable().ToDictionary(c => c.Id, c => c.PriorityNo);
        var today = DateTime.Today;

        var buckets = new Dictionary<int, CustBucket>();
        foreach (var lot in lotsQ.ToList())
        {
            if (!buckets.TryGetValue(lot.CustomerId, out var b))
            {
                b = new CustBucket
                {
                    CustomerId = lot.CustomerId,
                    Name = lot.CustomerId > 0 && custNames.TryGetValue(lot.CustomerId, out var nm) ? nm : "بدون عميل",
                    OldestArrival = lot.ArrivalDate ?? DateTime.MaxValue
                };
                b.PriorityNo = custPrio.TryGetValue(lot.CustomerId, out var pr) ? pr : 0;
                buckets[lot.CustomerId] = b;
            }
            lot.DaysInStock = lot.ArrivalDate != null ? Math.Max(0, (today - lot.ArrivalDate.Value.Date).Days) : 0;
            b.Lots.Add(lot);
            b.TotalAvailable += lot.Remaining;
            b.ShipmentIds.Add(lot.ShipmentId ?? 0);
            if (lot.ArrivalDate != null && lot.ArrivalDate < b.OldestArrival) b.OldestArrival = lot.ArrivalDate.Value;
        }
        if (buckets.Count == 0)
        { result.Message = "لا توجد أرصدة خام متاحة للتوزيع — استلم شحنات واعتمدها أولاً."; return result; }

        foreach (var b in buckets.Values) b.Remaining = b.TotalAvailable;
        double totalRemaining = buckets.Values.Sum(b => b.TotalAvailable);
        var rows = new List<FairPlanRowDto>();
        int prio = 1;

        // §الدوّار العادل: يوم ← عملاء بترتيب نسبة الإنجاز ← أقدم الحاويات أولاً
        foreach (var day in days)
        {
            if (totalRemaining <= 0.01) break;
            result.DaysUsed++;
            double dayKg = result.DailyQuotaKg;
            while (dayKg > 0.01 && totalRemaining > 0.01)
            {
                var next = buckets.Values.Where(c => c.Remaining > 0.01)
                    .OrderBy(c => c.PriorityNo == 0 ? int.MaxValue : c.PriorityNo).ThenBy(c => c.Ratio).ThenBy(c => c.OldestArrival).FirstOrDefault();
                if (next == null) break;

                double need = Math.Min(dayKg, next.Remaining);
                double got = 0;
                while (need > 0.01 && next.Lots.Count > 0)
                {
                    var lot = next.Lots[0];
                    var fin = targetProductId != null ? fins[0] : fins[(next.CustomerId + rows.Count) % fins.Count];
                    int packId = DefaultPackId(fin);
                    double uw = PackWeight(packId);
                    double take = Math.Min(need, lot.Remaining);
                    int cartons = Math.Max(1, (int)Math.Floor(take / uw));
                    double kg = Math.Round(cartons * uw, 1); // الكمية = الكراتين × وزن العبوة (بلا تجاوز للرصيد)

                    rows.Add(new FairPlanRowDto
                    {
                        PriorityNo = prio++,
                        Date = day.ToString("dd/MM/yyyy"),
                        CustomerId = next.CustomerId,
                        CustomerName = next.Name,
                        ShipmentId = lot.ShipmentId,
                        ShipmentNo = lot.ShipmentNo ?? "—",
                        ContainerNumber = lot.ContainerNumber ?? "—",
                        ArrivalDate = lot.ArrivalDate?.ToString("dd/MM/yyyy") ?? "—",
                        DaysInStock = lot.DaysInStock,
                        LotId = lot.Id,
                        LotCode = lot.LotCode,
                        RawName = rawNames.TryGetValue(lot.RawProductId, out var rn) ? rn : "—",
                        AvailableKg = Math.Round(lot.Remaining, 1),
                        ProductId = fin.Id,
                        ProductName = fin.ProductNameAr,
                        PackagingTypeId = packId,
                        PackName = packs.First(p => p.Id == packId).PackageNameAr,
                        PlannedCartons = cartons,
                        PlannedQtyKg = kg
                    });
                    if (!next.Days.Contains(day)) next.Days.Add(day);

                    next.AllocatedCartons += cartons;
                    lot.Remaining -= kg; next.Remaining -= kg; totalRemaining -= kg; need -= kg; dayKg -= kg; got += kg;
                    if (lot.Remaining <= 0.01) next.Lots.RemoveAt(0);
                }
                next.Allocated += got;
                double denom = next.Allocated + next.Remaining;
                next.Ratio = denom > 0 ? next.Allocated / denom : 1.0;
                if (got <= 0.01) break; // حماية من الدوران اللانهائي
            }
        }

        result.Rows = rows;
        result.Customers = buckets.Values.Select(b => new FairCustomerSummaryDto
        {
            CustomerId = b.CustomerId,
            CustomerName = b.Name,
            ContainersCount = b.ShipmentIds.Where(x => x > 0).Distinct().Count(),
            TotalAvailableKg = Math.Round(b.TotalAvailable, 1),
            AllocatedKg = Math.Round(b.Allocated, 1),
            AllocatedCartons = b.AllocatedCartons,
            ProgressRatio = Math.Round(b.Ratio * 100, 1),
            ProductionDays = b.Days.OrderBy(x => x).Select(x => x.ToString("MM-dd")).ToList()
        }).OrderByDescending(c => c.TotalAvailableKg).ToList();
        result.TotalRemainingKg = Math.Round(totalRemaining, 1);

        result.Ok = rows.Count > 0;
        result.Message = $"⚖ اقتراح توزيع عادل: {rows.Count} بنداً على {result.DaysUsed} يوماً لـ{buckets.Count} عملاء — حصة يومية ≈ {result.DailyQuotaKg:N0} كجم.";
        if (totalRemaining > 0.01)
            result.Message += $"\n⚠ متبقٍ {totalRemaining:N0} كجم لا تسعها مدة الخطة — وسّع الفترة أو زد الحصة اليومية.";
        return result;
    }

    private class LotSeed
    {
        public int Id; public string LotCode; public int CustomerId; public int? ShipmentId;
        public int RawProductId; public double Remaining; public DateTime? ArrivalDate;
        public string ContainerNumber; public string ShipmentNo; public int DaysInStock;
    }

    private class CustBucket
    {
        public int CustomerId; public string Name; public List<LotSeed> Lots = new();
        public double TotalAvailable; public double Remaining;
        public double Allocated; public int AllocatedCartons;
        public double Ratio; public DateTime OldestArrival = DateTime.MaxValue;
        public int PriorityNo;
        public HashSet<int> ShipmentIds = new(); public List<DateTime> Days = new();
    }

    /// <summary>
    /// §الإقفال اليومي: إن اكتمل إنتاج كل بنود الخطة تُقفل تلقائياً — يحرر الحجوزات
    /// غير المستهلكة ويعيد الأرصدة متاحة، استعداداً لإصدار خطة اليوم التالي.
    /// </summary>
    public OpResult TryAutoCloseIfComplete(int planId)
    {
        var plan = Db.ProductionPlans.Include(p => p.Items).FirstOrDefault(p => p.Id == planId);
        if (plan == null || plan.IsClosed) return OpResult.Fail("");
        if (plan.Items.Count == 0 || !plan.Items.All(i => i.IsClosed || i.ProducedQtyKg + 0.001 >= i.PlannedQtyKg))
            return OpResult.Fail(""); // لم تكتمل بعد — تبقى مفتوحة (إجراء صامت)

        // §B79: مكتملة ≠ مقفلة — لا إقفال تلقائي؛ الإقفال قرار صريح من شاشة «إقفال خطة الإنتاج».
        return OpResult.Success($"✅ الخطة {plan.DocumentNumber} مكتملة — جاهزة للإقفال الرسمي من شاشة «إقفال خطة الإنتاج».");
    }

    /// <summary>
    /// §إصلاح حرج: كل بند يجب أن يحمل تاريخ إنتاج — وإلا تخطّى فحص الطاقة كلياً
    /// لأن الحارس يشترط ScheduledDate != null. البند بلا تاريخ يُجدول على بداية الخطة
    /// (لا يُرفض — جدولة رحومة تُخضعه للفحص بدل أن تُعطّل العمل).
    /// </summary>
    private static void ApplyDefaultScheduledDates(List<PlanItemDto> items, DateTime? planStart, DateTime? planEnd = null)
    {
        string fallback = (planStart ?? DateTime.Today).Date.ToString(UiFormat.DatePattern);
        foreach (var i in items)
            if (!UiFormat.TryParseDate(i.ScheduledDate, out _))
                i.ScheduledDate = fallback;

        // §B80: فرض تاريخ كل إنتاج — تاريخ أي بند خارج فترة الخطة مرفوض صراحةً.
        // (الواجهة تعرض تاريخاً لكل بند في نافذة الاختيار وجدول البنود وتتحقق قبل الحفظ،
        // وهذا الحارس يسدّ أي مسار آخر — الخطة الطويلة لا تقبل بنداً في يوم خارج فترتها.)
        if (planStart != null && planEnd != null && planEnd.Value.Date >= planStart.Value.Date)
        {
            var outside = items
                .Where(i => UiFormat.TryParseDate(i.ScheduledDate, out var d)
                            && (d.Date < planStart.Value.Date || d.Date > planEnd.Value.Date))
                .ToList();
            if (outside.Count > 0)
            {
                string first = outside[0].ScheduledDate;
                throw new DomainException(
                    $"تاريخ الإنتاج ({first}) خارج فترة الخطة " +
                    $"({planStart.Value.Date.ToString(UiFormat.DatePattern)} ← {planEnd.Value.Date.ToString(UiFormat.DatePattern)}) — " +
                    $"{outside.Count} بند بتواريخ خارج الفترة.\nحدّد لكل بند تاريخ إنتاج داخل فترة الخطة.",
                    "DATE_OUT_OF_RANGE");
            }
        }
    }

    /// <summary>
    /// §إصلاح حرج — فحص الطاقة لبند مع تراكم بنود «الخطة نفسها».
    /// الخلل السابق: كان يُمرَّر excludePlanId وحده، فتُستثنى الخطة كلها من الحساب
    /// ولا تُحتسب بنودها على بعضها ← أمكن تحميل 16 ساعة في وردية 8 ساعات بوضع البنود في خطة واحدة.
    /// </summary>
    private void EnsureSlotCapacity(ProductionPlan plan, PlanItemDto dto,
        Dictionary<(DateTime day, int shift, int line), double> localUsed)
    {
        if (dto.PlannedCartons <= 0 || dto.SuggestedShiftId is not int shId) return;
        if (!UiFormat.TryParseDate(dto.ScheduledDate, out var day)) return;
        int lineId = dto.SuggestedLineId ?? 1;

        var (usedOther, cap, rate) = ShiftUsageHours(shId, lineId, dto.ScheduledDate, dto.ProductId,
            excludePlanId: plan.Id, dto.PackagingTypeId);
        var key = (day.Date, shId, lineId);
        double usedHere = localUsed.TryGetValue(key, out var lu) ? lu : 0;
        double requiredHours = rate > 0 ? dto.PlannedCartons / rate : 0;
        double used = usedOther + usedHere;

        if (used + requiredHours > cap + 0.0001)
        {
            double remainingHours = Math.Max(0, cap - used);
            int availableCartons = (int)Math.Floor(remainingHours * rate);
            int over = Math.Max(0, dto.PlannedCartons - availableCartons);
            // §B77: اقتراح أقرب يوم بديل تتسع طاقته للكمية — بدل الرفض الأعمى
            string suggestion = "";
            if (plan.StartDate != null && plan.EndDate != null && rate > 0)
            {
                // §B77: ابحث داخل فترة الخطة أولاً ثم حتى 7 أيام بعدها (مع تنبيه تمديد الفترة)
                var last = plan.EndDate.Value.Date.AddDays(7);
                for (var d = plan.StartDate.Value.Date; d <= last; d = d.AddDays(1))
                {
                    if (d == day.Date) continue;
                    var (uOther, _, _) = ShiftUsageHours(shId, lineId, d.ToString("dd/MM/yyyy"), dto.ProductId, plan.Id, dto.PackagingTypeId);
                    double freeHere = localUsed.TryGetValue((d, shId, lineId), out var lh) ? lh : 0;
                    if (uOther + freeHere + requiredHours <= cap + 0.0001)
                    {
                        int altAvail = (int)Math.Floor(Math.Max(0, cap - uOther - freeHere) * rate);
                        string beyond = d > plan.EndDate.Value.Date ? " (خارج فترة الخطة الحالية — مدّد الخطة إليه)" : "";
                        suggestion = $"\n💡 أقرب يوم بديل تتسع طاقته: {d:dd/MM/yyyy}{beyond} (متاح فيه ≈ {altAvail:N0} كرتون) — انقل البند إليه أو وزّع عبر «اقتراح توزيع عادل».";
                        break;
                    }
                }
            }
            throw new DomainException(
                $"الكمية المطلوبة أكبر من الطاقة الإنتاجية المتاحة للصنف في هذه الوردية يوم {day:dd/MM/yyyy}.\n" +
                $"الطاقة المتاحة: {availableCartons:N0} كرتون | المطلوب: {dto.PlannedCartons:N0} كرتون | الزيادة: {over:N0} كرتون\n" +
                $"(الساعات: الإنتاجية {cap:N1} | في خطط أخرى {usedOther:N1} | في بنود هذه الخطة {usedHere:N1} | المطلوبة {requiredHours:N1})" + suggestion,
                "CAPACITY_EXCEEDED");
        }
        localUsed[key] = usedHere + requiredHours;
    }

    /// <summary>(الوردية، الخط، اليوم) ← ساعات مستخدمة/طاقة كلية/معدل الصنف — يراعي العبوة/المواصفة.</summary>
    internal (double usedHours, double effHours, double rate) ShiftUsageHours(int shiftId, int lineId, string schedDate, int productId, int? excludePlanId, int? packagingTypeId = null)
    {
        var shift = Db.Shifts.FirstOrDefault(s => s.Id == shiftId);
        double effHours = CapacityPolicy.EffectiveHours(shift?.EffectiveProductiveHours ?? 0, shift?.TotalHours ?? 0);
        double rate = RateFor(productId, shiftId, packagingTypeId);

        DateTime? day = UiFormat.TryParseDate(schedDate, out var dv) ? dv.Date : (DateTime?)null;
        DateTime? dayEnd = day?.AddDays(1);
        var items = Db.ProductionPlanItems
            .Where(i => i.SuggestedLineId == lineId && (i.SuggestedShiftId ?? 1) == shiftId
                        && i.ScheduledDate != null && i.ScheduledDate >= day && i.ScheduledDate < dayEnd)
            .Select(i => new { i.PlanId, i.ProductId, i.PackagingTypeId, i.PlannedCartons }).ToList()
            .Where(x => excludePlanId == null || x.PlanId != excludePlanId);

        double used = 0;
        foreach (var it in items)
        {
            // §كل بند يُحسب بمعدل صنفه وعبوته وورديته (سكري 7.5 ≠ سكري 4)
            var r = RateFor(it.ProductId, shiftId, it.PackagingTypeId);
            if (r > 0) used += it.PlannedCartons / r;   // §بلا معدل معرَّف لا تُحتسب ساعات
        }
        return (Math.Round(used, 2), effHours, rate);
    }

    /// <summary>معدل صنف + عبوة + وردية: خاصة بالعبوة أولاً، ثم العامة، ثم معدل الصنف العام.</summary>
    private double RateFor(int productId, int shiftId, int? packagingTypeId)
    {
        var (r, _, _) = CapacityPolicy.Resolve(Db, productId, shiftId, packagingTypeId);
        return r;
    }
}
