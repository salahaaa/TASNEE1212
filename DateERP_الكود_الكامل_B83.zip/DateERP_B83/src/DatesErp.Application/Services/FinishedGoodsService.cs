using DatesErp.Core.Common;
using DatesErp.Core.Domain.Entities;
using DatesErp.Core.Domain.Enums;
using DatesErp.Core.Exceptions;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Application.Services;

/// <summary>
/// §7 — الدورة القانونية لاستلام الإنتاج التام:
/// أمر التسليم (متعدد الأصناف) ← الإصدار للمخزن (بلا أثر على الأرصدة)
/// ← سند الاستلام المخزني هو وحده ما يحرّك أرصدة مخزن التام (كلي/جزئي لكل صنف).
/// </summary>
public class FinishedGoodsService : ServiceBase, IFinishedGoodsService
{
    public FinishedGoodsService(DatesErpDbContext db, ICurrentSession session, INumberingService numbering)
        : base(db, session, numbering) { }

    public OpResult SaveReceipt(int orderId, int? qualityCheckId, string deliveryDate, List<FinishedGoodsItemDto> items)
    {
        Require("finishedgoods", "Create");
        if (items == null || items.Count == 0) return OpResult.Fail("أدخل بنداً واحداً على الأقل.");
        var order = Db.ProductionOrders.Include(o => o.Items).FirstOrDefault(o => o.Id == orderId);
        if (order == null) return OpResult.Fail("أمر الإنتاج غير موجود.");
        // §جودة التمور (فترة تبريد يومان): يُسمح بالتسليم لمخزن التام بمجرد الإقفال اليومي
        // وإرسال الإنتاج للجودة — النتيجة النهائية تُستكمل خلال يومين قبل تسليم العميل.
        var qualityCheck = Db.QualityChecks.AsNoTracking()
            .Where(c => c.OrderId == orderId).OrderByDescending(c => c.Id).FirstOrDefault();
        if (qualityCheck == null)
            return OpResult.Fail("لا يمكن تسليم الإنتاج قبل إقفال يوم الإنتاج وإرساله إلى الجودة — نفّذ الإقفال اليومي أولاً.");
        bool coolingPending = !qualityCheck.IsApproved;

        return RunOp(() =>
        {
            var rcpt = new FinishedGoodsReceipt
            {
                DocumentNumber = Numbering.Next("FGR"),
                OrderId = orderId,
                QualityCheckId = qualityCheckId,
                DeliveryDate = UiFormat.TryParseDate(deliveryDate, out var d) ? d : DateTime.Now,
                WarehouseId = WarehouseId("WFG"),
                Status = DocStatuses.Draft,
                ReceiptStatus = "None"
            };
            foreach (var it in items)
            {
                // §نظام الوحدات: استلام التام للمنتجات التامة فقط (002) واتساق الكرتون/الكيلو إلزامي
                UnitsPolicy.RequireItemType(Db, it.ProductId, "Finished", "استلام الإنتاج التام");
                it.NetWeightKg = UnitsPolicy.EnsureCartonKgConsistency(Db, it.ProductId, it.PackagingTypeId,
                    it.NetWeightKg, it.PackageCount, "استلام الإنتاج التام");

                // §8 — لا يتجاوز بند التسليم كمية الأمر
                var orderItem = order.Items.FirstOrDefault(i => i.ProductId == it.ProductId);
                if (orderItem == null) throw new DomainException("الصنف غير موجود في أمر الإنتاج.");

                // §تتبع الصنف: الدفعة المرتبطة بالتسليم يجب أن تتطابق مع دفعة بند الأمر (لا استبدال هوية)
                if (it.LotId is int fgLotId)
                {
                    ProductIdentityGuard.EnsureConversionAllowed(Db, it.ProductId, fgLotId);
                    if (orderItem.LotId != null && orderItem.LotId != fgLotId)
                    {
                        string wantLot = Db.Lots.AsNoTracking().Where(l => l.Id == fgLotId).Select(l => l.LotCode).FirstOrDefault() ?? $"#{fgLotId}";
                        string realLot = Db.Lots.AsNoTracking().Where(l => l.Id == orderItem.LotId).Select(l => l.LotCode).FirstOrDefault() ?? $"#{orderItem.LotId}";
                        throw new DomainException(
                            $"⛔ الدفعة {wantLot} ليست دفعة هذا البند — بند الأمر مرتبط بالدفعة {realLot}.\n" +
                            "هوية الصنف والدفعة تنتقلان من أمر الإنتاج كما هما.",
                            "LOT_MISMATCH");
                    }
                }
                double alreadyDelivering = Db.FinishedGoodsReceiptItems
                    .Join(Db.FinishedGoodsReceipts, i => i.ReceiptId, r => r.Id, (i, r) => new { i, r })
                    .Where(x => x.r.OrderId == orderId && x.i.ProductId == it.ProductId)
                    .Sum(x => x.i.NetWeightKg);
                if (alreadyDelivering + it.NetWeightKg > orderItem.ProducedQtyKg + 0.001)
                    throw new DomainException(
                        $"تسليم يتجاوز كمية أمر الإنتاج للصنف.\nالمنتَج: {orderItem.ProducedQtyKg:N1} كجم | المطلوب تسليمه تراكمياً: {alreadyDelivering + it.NetWeightKg:N1}",
                        "EXCEED_ORDER_QTY");

                rcpt.Items.Add(new FinishedGoodsReceiptItem
                {
                    ProductId = it.ProductId,
                    LotId = it.LotId,
                    PackagingTypeId = it.PackagingTypeId,
                    PackageCount = it.PackageCount,
                    NetWeightKg = it.NetWeightKg,
                    ReceivedQtyKg = 0,
                    // §القاعدة 7: وزن الكرتون وقت الاستلام — لا يتغير بتعريف العبوة لاحقاً
                    CartonWeightKg = UnitsPolicy.CartonWeight(Db, it.ProductId, it.PackagingTypeId)
                });
            }
            Db.FinishedGoodsReceipts.Add(rcpt);
            Db.SaveChanges();
            string coolingNote = coolingPending
                ? $"\n🔬 الفحص النهائي متوقع {qualityCheck.ExpectedCheckDate:dd/MM/yyyy} (فترة تبريد) — تسليم العميل متوقف على اعتماد الفحص."
                : "";
            return OpResult.Success($"تم إنشاء أمر تسليم الإنتاج {rcpt.DocumentNumber} — الجودة سمحت بالتسليم للتام." + coolingNote, rcpt.Id, rcpt.DocumentNumber);
        });
    }

    /// <summary>الإصدار إلى المخزن — لا يمس أي رصيد (§7).</summary>
    public OpResult Issue(int receiptId)
    {
        var rcpt = Db.FinishedGoodsReceipts.FirstOrDefault(r => r.Id == receiptId);
        if (rcpt == null) return OpResult.Fail("أمر التسليم غير موجود.");
        if (rcpt.Status == DocStatuses.Issued) return OpResult.Fail("أمر التسليم مُصدر مسبقاً.");
        // بوابة الصلاحيات: الإصدار للإنتاج/الإدارة — الجودة والمخازن لا يُصدران
        if (Session != null && !Session.Can("finishedgoods", "Create") && !Session.Can("production", "Edit"))
            return OpResult.Fail("لا تملك صلاحية إصدار أمر التسليم.");

        return RunOp(() =>
        {
            rcpt.Status = DocStatuses.Issued;
            Db.SaveChanges();
            return OpResult.Success("تم إصدار أمر التسليم إلى المخزن — بانتظار سند الاستلام.");
        });
    }

    /// <summary>§7/§8 — سند الاستلام المخزني: وحده يؤثر على الأرصدة، كلياً أو جزئياً لكل صنف.</summary>
    public OpResult Receive(int receiptId, Dictionary<int, double> receivedByItemId)
    {
        Require("finishedgoods", "Approve");
        var rcpt = Db.FinishedGoodsReceipts.Include(r => r.Items).FirstOrDefault(r => r.Id == receiptId);
        if (rcpt == null) return OpResult.Fail("أمر التسليم غير موجود.");
        if (rcpt.ReceiptStatus == "Full") return OpResult.Fail("السند منفذ بالكامل مسبقاً.");
        if (rcpt.Status != DocStatuses.Issued && rcpt.Status != DocStatuses.Completed)
            return OpResult.Fail("لا يمكن الاستلام قبل إصدار أمر التسليم.");

        return RunOp(() =>
        {
            var whFg = rcpt.WarehouseId;
            var orderCust = Db.ProductionOrders.Where(o => o.Id == rcpt.OrderId).Select(o => o.CustomerId).FirstOrDefault();
            double totalReceived = 0;
            rcpt.ReceiveCount++;
            rcpt.ReceiptNumber ??= Numbering.Next("RCV");
            var voucher = $"{rcpt.ReceiptNumber}#{rcpt.ReceiveCount}"; // لكل سند استلام (متابعة) ترقيم متسلسل
            foreach (var item in rcpt.Items)
            {
                double remaining = item.NetWeightKg - item.ReceivedQtyKg;
                if (remaining <= 0.001) continue;
                double recv = receivedByItemId != null && receivedByItemId.TryGetValue(item.Id, out var v) ? v : remaining;
                if (recv <= 0) continue;
                if (recv > remaining + 0.001)
                    throw new DomainException($"الكمية المستلمة أكبر من المتبقي للبند ({remaining:N1} كجم).", "OVER_RECEIPT");

                item.ReceivedQtyKg += recv;
                totalReceived += recv;
                // التام يُورد بالكرتون: قيد العبوات المستلمة تناسبياً مع الوزن
                int pkgRecv = item.PackageCount > 0 && item.NetWeightKg > 0
                    ? (int)Math.Round(recv / item.NetWeightKg * item.PackageCount) : 0;
                PostStockMovement(whFg, MovementType.Inbound, recv, pkgRecv,
                    ReferenceDocType.FinishedGoodsReceipt, voucher,
                    productId: item.ProductId, lotId: item.LotId, orderId: rcpt.OrderId,
                    customerId: orderCust, packagingTypeId: item.PackagingTypeId,
                    notes: $"استلام إنتاج تام — سند {rcpt.ReceiptNumber}");
            }

            if (totalReceived <= 0.001) return OpResult.Fail("لم تُدخل أي كمية مستلمة.");

            bool full = rcpt.Items.All(i => i.ReceivedQtyKg + 0.001 >= i.NetWeightKg);
            rcpt.ReceiptStatus = full ? "Full" : "Partial";
            rcpt.IsApproved = true;
            rcpt.Status = DocStatuses.Completed;
            rcpt.ApprovedBy = Session?.UserId;
            rcpt.ApprovedDate = DateTime.Now;

            // إغلاق أمر الإنتاج تلقائياً عند الاكتمال الكامل
            if (full)
            {
                var order = Db.ProductionOrders.Include(o => o.Items).FirstOrDefault(o => o.Id == rcpt.OrderId);
                if (order != null && order.Items.All(i => i.IsClosed || i.ProducedQtyKg + 0.001 >= i.PlannedQtyKg))
                {
                    order.Status = DocStatuses.Completed;
                    order.IsClosed = true;
                    order.ClosedDate = DateTime.Now;
                }
                else if (order != null) order.Status = "PendingDelivery";
            }

            Db.SaveChanges();
            return OpResult.Success(full
                ? "تم الاستلام الكامل وتقييد كامل الكمية في مخزن الإنتاج التام."
                : $"تم الاستلام الجزئي ({totalReceived:N1} كجم) وتقييدها في مخزن التام.", rcpt.Id, rcpt.ReceiptNumber);
        });
    }

    /// <summary>إلغاء السند يعكس الأرصدة بدقة ويحذف حركاته (§6).</summary>
    public OpResult Unapprove(int receiptId)
    {
        Require("finishedgoods", "Cancel");
        var rcpt = Db.FinishedGoodsReceipts.Include(r => r.Items).FirstOrDefault(r => r.Id == receiptId);
        if (rcpt == null) return OpResult.Fail("السند غير موجود.");
        if (!rcpt.IsApproved) return OpResult.Fail("السند غير معتمد.");

        return RunOp(() =>
        {
            var whFg = rcpt.WarehouseId;
            var orderCust = Db.ProductionOrders.Where(o => o.Id == rcpt.OrderId).Select(o => o.CustomerId).FirstOrDefault();
            var prefix = rcpt.ReceiptNumber ?? rcpt.DocumentNumber;
            // §إصلاح حرج — الإلغاء بقيد عكسي لا بحذف دفتر الأستاذ.
            // كان يحذف الحركات بـ StartsWith(prefix):
            //  • يدمّر سجلّاً إلحاقياً (قرارهم #48: «إلحاقي غير قابل للتعديل»)
            //  • وتصادم بادئات: عند السند رقم 10000 يصبح RCV-...-1000 بادئة له فيحذف حركاته
            //  • وكان يبحث الرصيد بلا CustomerId بينما Receive يكتب به ← قد يطرح من صف آخر
            int seq = 0;
            foreach (var item in rcpt.Items.Where(i => i.ReceivedQtyKg > 0))
            {
                int pkgBack = item.PackageCount > 0 && item.NetWeightKg > 0
                    ? (int)Math.Round(item.ReceivedQtyKg / item.NetWeightKg * item.PackageCount) : 0;
                seq++;
                PostStockMovement(whFg, MovementType.Outbound, item.ReceivedQtyKg, pkgBack,
                    ReferenceDocType.FinishedGoodsReceipt, $"{prefix}#REV{seq}",
                    productId: item.ProductId, lotId: item.LotId, orderId: rcpt.OrderId,
                    customerId: orderCust, packagingTypeId: item.PackagingTypeId,
                    notes: $"إلغاء سند الاستلام {rcpt.ReceiptNumber} — قيد عكسي");
                item.ReceivedQtyKg = 0;
            }
            rcpt.IsApproved = false;
            rcpt.ReceiptStatus = "None";
            rcpt.Status = DocStatuses.Issued;
            Db.SaveChanges();
            return OpResult.Success("تم إلغاء السند وعكس أرصدة مخزن التام بالكامل.");
        });
    }
}
