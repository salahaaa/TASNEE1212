using System.Data;
using System.Windows;
using System.Windows.Controls;
using DatesErp.Core.Interfaces.Services;
using DatesErp.Desktop.Services;
using DatesErp.Desktop.Views;
using DatesErp.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace DatesErp.Desktop.Views.Screens;

/// <summary>
/// §24 — شاشة قائمة عامة: شبكة بيانات + بحث + طباعة/تصدير.
/// §23 — تدعم أزرار جديد/تعديل/حذف للشاشات القابلة للتعديل (تراجع لا يحذف محفوظاً).
/// </summary>
public partial class GenericListView : UserControl
{
    public class CrudConfig
    {
        public string EntityTitle { get; set; }
        public List<FieldDef> Fields { get; set; }
        /// <summary>الحفظ — القيم تشمل "__id" عند التعديل.</summary>
        public Func<Dictionary<string, object>, (bool ok, string msg)> Save { get; set; }
        /// <summary>تحميل قيم السجل للتعديل.</summary>
        public Func<int, Dictionary<string, object>> LoadForEdit { get; set; }
        public Func<int, (bool ok, string msg)> Delete { get; set; }
    }

    private string _title;
    private Func<DatesErpDbContext, (List<string> columns, List<object[]> rows)> _loader;
    private CrudConfig _crud;
    private bool _idFirstColumn;
    private List<string> _columns = new();
    private List<object[]> _rows = new();
    private Views.ErpChrome _chrome;
    public string Module { get; private set; } = "البيانات الأساسية";
    public string ScreenCode { get; private set; } = "MRPMAS1099";

    /// <summary>ربط الإطار الكلاسيكي الموحّد بالشاشة.</summary>
    public void AttachChrome(Views.ErpChrome chrome, string module, string screenCode)
    {
        _chrome = chrome;
        Module = module; ScreenCode = screenCode;
        chrome.SetModule(module);
        chrome.SetScreenCode(screenCode);
        chrome.SetToolbar(BuildToolbar());
        chrome.SetBody(this);
    }

    /// <summary>§1 — شريط الأدوات القياسي الموحد: جديد/بحث/تعديل/تراجع/طباعة ثم الإضافات حسب طبيعة الشاشة.</summary>
    public Views.ErpToolbar BuildToolbar()
    {
        var tb = new Views.ErpToolbar();
        if (_crud != null) tb.WithNew(New_Click);
        tb.WithSearch(SearchBtn_Click);
        if (_crud != null)
        {
            tb.WithEdit(Edit_Click);
            tb.WithUndo(Undo_Click);
        }
        tb.WithPrint((_, _) => AppContainer.Get<ExportPrintService>().Print(AsReport()));
        if (_crud != null) tb.WithDelete(Delete_Click);
        tb.WithExcel((_, _) => AppContainer.Get<ExportPrintService>().ExportExcel(AsReport()))
          .WithRefresh((_, _) => Refresh());
        tb.WithExit((_, _) => (Window.GetWindow(this) as MainWindow)?.OpenScreen("dashboard"));
        return tb;
    }

    private GenericListView(string title, Func<DatesErpDbContext, (List<string>, List<object[]>)> loader)
    {
        InitializeComponent();
        _title = title;
        _loader = loader;
        // §2/§27 — الشاشة تفتح فارغة نظيفة: لا عرض تلقائي للبيانات — جديد للإنشاء وبحث للاستعراض
        Loaded += (_, _) => SetEmptyState();
    }

    private void SetEmptyState()
    {
        Grid.ItemsSource = null;
        StateText.Text = _crud != null
            ? "الشاشة جاهزة — اضغط «جديد» لإنشاء سجل جديد، أو «بحث / عرض الكل» لاستعراض السجلات المحفوظة."
            : "الشاشة جاهزة — اضغط «بحث» أو «عرض الكل» لاستعراض البيانات حسب صلاحيتك.";
        _chrome?.SetCount(0);
    }

    public GenericListView WithCrud(CrudConfig crud)
    {
        _crud = crud;
        _idFirstColumn = true;
        return this;
    }

    private void Refresh()
    {
        try
        {
            using var scope = AppContainer.NewScope();
            var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
            (_columns, _rows) = _loader(db);
            ApplyFilter();
            string action = _crud != null ? "تفتحانه للتعديل" : "لعرض تفاصيله";
            StateText.Text = $"نتائج البحث: {_rows.Count} سجلاً — نقرتان متتاليتان على أي سجل {action}.";
        }
        catch (Exception ex)
        {
            AppContainer.Get<DialogService>().HandleException(ex, "List:" + _title);
        }
    }

    private void ApplyFilter()
    {
        string term = SearchBox.Text?.Trim().ToLower() ?? "";
        var filtered = string.IsNullOrEmpty(term) ? _rows
            : _rows.Where(r => r.Any(c => c?.ToString().ToLower().Contains(term) == true)).ToList();

        var dt = new DataTable();
        var displayCols = _idFirstColumn ? _columns.Skip(1).ToList() : _columns;
        foreach (var c in displayCols) dt.Columns.Add(c);
        foreach (var r in filtered)
        {
            var src = _idFirstColumn ? r.Skip(1).ToArray() : r;
            var arr = new object[displayCols.Count];
            for (int i = 0; i < displayCols.Count; i++) arr[i] = i < src.Length ? src[i] : null;
            dt.Rows.Add(arr);
        }
        Grid.Tag = filtered; // الاحتفاظ بالصفوف الأصلية (مع المعرف) للتعديل/الحذف
        Grid.AutoGenerateColumns = true;
        Grid.ItemsSource = dt.DefaultView;
        _chrome?.SetCount(filtered.Count);
    }

    private int? SelectedRowId()
    {
        if (!_idFirstColumn || Grid.SelectedIndex < 0) return null;
        if (Grid.Tag is List<object[]> filtered && Grid.SelectedIndex < filtered.Count)
            return filtered[Grid.SelectedIndex][0] as int? ?? Convert.ToInt32(filtered[Grid.SelectedIndex][0]);
        return null;
    }

    // ═══════════════════════ أزرار جديد/تعديل/حذف (§23) ═══════════════════════

    private void New_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dlg = new EntityFormDialog($"{_crud.EntityTitle} — جديد", _crud.Fields);
            if (dlg.ShowDialog() != true) return;
            var (ok, msg) = _crud.Save(dlg.Values);
            if (!ok) AppContainer.Get<DialogService>().Error(msg);
            else { AppContainer.Get<DialogService>().Info(msg); Refresh(); }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "New:" + _title); }
    }

    private void Edit_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var id = SelectedRowId();
            if (id == null) { AppContainer.Get<DialogService>().Error("اختر سجلاً من الجدول لتعديله."); return; }
            var values = _crud.LoadForEdit(id.Value);
            values["__id"] = id.Value;
            var dlg = new EntityFormDialog($"{_crud.EntityTitle} — تعديل", _crud.Fields, values);
            if (dlg.ShowDialog() != true) return;
            var (ok, msg) = _crud.Save(dlg.Values);
            if (!ok) AppContainer.Get<DialogService>().Error(msg);
            else { AppContainer.Get<DialogService>().Info(msg); Refresh(); }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Edit:" + _title); }
    }

    /// <summary>§النقر المزدوج على أي سجل يفتح نافذة التعديل مباشرة — حركة أسرع كالأنظمة الكبيرة.</summary>
    private void Grid_DoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
    {
        if (_crud == null) return;
        Edit_Click(sender, e);
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var id = SelectedRowId();
            if (id == null) { AppContainer.Get<DialogService>().Error("اختر سجلاً من الجدول لحذفه."); return; }
            if (!AppContainer.Get<DialogService>().Confirm($"هل تريد حذف هذا السجل من {_crud.EntityTitle}؟")) return;
            var (ok, msg) = _crud.Delete(id.Value);
            if (!ok) AppContainer.Get<DialogService>().Error(msg);
            else { AppContainer.Get<DialogService>().Info(msg); Refresh(); }
        }
        catch (Exception ex) { AppContainer.Get<DialogService>().HandleException(ex, "Delete:" + _title); }
    }

    // ═══════════════════════ الطباعة والتصدير ═══════════════════════

    private ReportResult AsReport()
    {
        var displayCols = _idFirstColumn ? _columns.Skip(1).ToList() : _columns;
        var displayRows = _rows.Select(r => _idFirstColumn ? r.Skip(1).ToArray() : r).ToList();
        return new ReportResult { TitleAr = _title, Columns = displayCols, Rows = displayRows };
    }

    private void Search_Changed(object sender, TextChangedEventArgs e) { if (ClearBtn != null) ClearBtn.Visibility = string.IsNullOrEmpty(SearchBox.Text) ? Visibility.Collapsed : Visibility.Visible; if (_columns.Count > 0) ApplyFilter(); }
    private void SearchBtn_Click(object sender, RoutedEventArgs e) => Refresh();
    private void ShowAll_Click(object sender, RoutedEventArgs e) { SearchBox.Text = ""; Refresh(); }
    /// <summary>§13 — التراجع: يمسح البحث والتح دون حذف أي بيانات محفوظة.</summary>
    private void Undo_Click(object sender, RoutedEventArgs e) { SearchBox.Text = ""; SetEmptyState(); }
    private void Clear_Click(object sender, RoutedEventArgs e) { SearchBox.Text = ""; if (_columns.Count > 0) ApplyFilter(); ClearBtn.Visibility = Visibility.Collapsed; }

    private void Grid_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        switch (e.Key)
        {
            case System.Windows.Input.Key.F2: if (_crud != null) New_Click(sender, e); break;
            case System.Windows.Input.Key.F3: if (_crud != null) Edit_Click(sender, e); break;
            case System.Windows.Input.Key.F8: if (_crud != null) Delete_Click(sender, e); break;
            case System.Windows.Input.Key.F5: Refresh(); break;
            case System.Windows.Input.Key.F9: SearchBox.Focus(); break;
        }
    }
    private void Refresh_Click(object sender, RoutedEventArgs e) => Refresh();
    private void Print_Click(object sender, RoutedEventArgs e) => AppContainer.Get<ExportPrintService>().Print(AsReport());
    private void Pdf_Click(object sender, RoutedEventArgs e) => AppContainer.Get<ExportPrintService>().ExportPdf(AsReport());
    private void Excel_Click(object sender, RoutedEventArgs e) => AppContainer.Get<ExportPrintService>().ExportExcel(AsReport());

    // ═══════════════════════ شاشات القوائم ═══════════════════════

    private static (bool, string) Wrap(Func<OpResult> f)
    {
        var r = f();
        return (r.Ok, r.Message);
    }

    public static GenericListView ForCustomers()
    {
        var view = new GenericListView("العملاء", db => (
        new() { "#", "الكود", "الاسم", "النوع", "الهاتف", "الشخص المسؤول", "الأولوية", "الحالة" },
        db.Customers.ToList().Select(c => new object[] { c.Id, c.CustomerCode, c.CustomerName, c.CustomerType, c.Phone, c.ContactPerson, c.PriorityNo, c.IsActive ? "نشط" : "موقوف" }).ToList()));
        return view.WithCrud(new CrudConfig
        {
            EntityTitle = "العميل",
            Fields = new()
            {
                new FieldDef { Key = "code", LabelAr = "الكود", Default = "C0" },
                new FieldDef { Key = "name", LabelAr = "اسم العميل" },
                new FieldDef { Key = "type", LabelAr = "النوع", Kind = "combo", Options = new[] { "تجار جملة", "تجزئة", "تصدير", "أخرى" } },
                new FieldDef { Key = "phone", LabelAr = "الهاتف" },
                new FieldDef { Key = "contact", LabelAr = "الشخص المسؤول" },
                new FieldDef { Key = "prio", LabelAr = "الأولوية (1 أولاً، 0 بلا)", Default = "0" },
                new FieldDef { Key = "active", LabelAr = "نشط", Kind = "check", Default = "true" }
            },
            Save = v =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                int? id = v.TryGetValue("__id", out var x) && x != null ? Convert.ToInt32(x) : null;
                int.TryParse(v.TryGetValue("prio", out var pr) ? pr?.ToString() : "0", out var prio);
                return Wrap(() => svc.SaveCustomer(id, v["code"]?.ToString(), v["name"]?.ToString(),
                    v["type"]?.ToString(), v["phone"]?.ToString(), v["contact"]?.ToString(), v["active"] is bool b && b, prio));
            },
            LoadForEdit = id =>
            {
                using var scope = AppContainer.NewScope();
                var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
                var c = db.Customers.First(x => x.Id == id);
                return new Dictionary<string, object>
                {
                    ["code"] = c.CustomerCode, ["name"] = c.CustomerName, ["type"] = c.CustomerType,
                    ["phone"] = c.Phone, ["contact"] = c.ContactPerson, ["prio"] = c.PriorityNo, ["active"] = c.IsActive
                };
            },
            Delete = id =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                return Wrap(() => svc.DeleteCustomer(id));
            }
        });
    }

    public static GenericListView ForSuppliers()
    {
        var view = new GenericListView("الموردون", db => (
        new() { "#", "الكود", "الاسم", "الهاتف", "الحالة" },
        db.Suppliers.ToList().Select(s => new object[] { s.Id, s.SupplierCode, s.SupplierName, s.Phone, s.IsActive ? "نشط" : "موقوف" }).ToList()));
        return view.WithCrud(new CrudConfig
        {
            EntityTitle = "المورد",
            Fields = new()
            {
                new FieldDef { Key = "code", LabelAr = "الكود", Default = "S0" },
                new FieldDef { Key = "name", LabelAr = "اسم المورد" },
                new FieldDef { Key = "phone", LabelAr = "الهاتف" },
                new FieldDef { Key = "active", LabelAr = "نشط", Kind = "check", Default = "true" }
            },
            Save = v =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                int? id = v.TryGetValue("__id", out var x) && x != null ? Convert.ToInt32(x) : null;
                return Wrap(() => svc.SaveSupplier(id, v["code"]?.ToString(), v["name"]?.ToString(), v["phone"]?.ToString(), v["active"] is bool b && b));
            },
            LoadForEdit = id =>
            {
                using var scope = AppContainer.NewScope();
                var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
                var s = db.Suppliers.First(x => x.Id == id);
                return new Dictionary<string, object> { ["code"] = s.SupplierCode, ["name"] = s.SupplierName, ["phone"] = s.Phone, ["active"] = s.IsActive };
            },
            Delete = id =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                return Wrap(() => svc.DeleteSupplier(id));
            }
        });
    }

    /// <summary>§شاشة الموظفين: كل موظف يأخذ رقماً للدخول — الرقم فريد (هذا الرقم محجوز).</summary>
    public static GenericListView ForEmployees()
    {
        var view = new GenericListView("الموظفون", db => (
        new() { "#", "رقم الموظف", "الاسم", "الوظيفة", "الإدارة", "الهاتف", "الحالة" },
        db.Employees.ToList().Select(e => new object[] { e.Id, e.EmployeeCode, e.FullName, e.JobTitle, e.Department, e.Phone, e.IsActive ? "نشط" : "موقوف" }).ToList()));
        return view.WithCrud(new CrudConfig
        {
            EntityTitle = "الموظف",
            Fields = new()
            {
                new FieldDef { Key = "code", LabelAr = "رقم الموظف (رقم الدخول)", Default = "EMP" },
                new FieldDef { Key = "name", LabelAr = "الاسم الكامل" },
                new FieldDef { Key = "job", LabelAr = "الوظيفة" },
                new FieldDef { Key = "dept", LabelAr = "الإدارة", Kind = "combo", Options = new[] { "الإدارة العامة", "الإنتاج", "المخازن", "الجودة", "المبيعات", "المالية" } },
                new FieldDef { Key = "phone", LabelAr = "الهاتف" },
                new FieldDef { Key = "active", LabelAr = "نشط", Kind = "check", Default = "true" }
            },
            Save = v =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                int? id = v.TryGetValue("__id", out var x) && x != null ? Convert.ToInt32(x) : null;
                return Wrap(() => svc.SaveEmployee(id, v["code"]?.ToString(), v["name"]?.ToString(), v["job"]?.ToString(),
                    v["dept"]?.ToString(), v["phone"]?.ToString(), v["active"] is bool b && b));
            },
            LoadForEdit = id =>
            {
                using var scope = AppContainer.NewScope();
                var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
                var e = db.Employees.First(x => x.Id == id);
                return new Dictionary<string, object> { ["code"] = e.EmployeeCode, ["name"] = e.FullName, ["job"] = e.JobTitle, ["dept"] = e.Department, ["phone"] = e.Phone, ["active"] = e.IsActive };
            },
            Delete = id =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                return Wrap(() => svc.DeleteEmployee(id));
            }
        });
    }

    public static GenericListView ForWarehouses()
    {
        var view = new GenericListView("المخازن", db => (
        new() { "#", "الكود", "الاسم", "النوع", "الحالة" },
        db.Warehouses.ToList().Select(w => new object[] { w.Id, w.WarehouseCode, w.WarehouseNameAr, w.WarehouseType, w.IsActive ? "نشط" : "موقوف" }).ToList()));
        return view.WithCrud(new CrudConfig
        {
            EntityTitle = "المخزن",
            Fields = new()
            {
                new FieldDef { Key = "code", LabelAr = "الكود", Default = "W" },
                new FieldDef { Key = "name", LabelAr = "اسم المخزن" },
                new FieldDef { Key = "type", LabelAr = "النوع", Kind = "combo", Options = new[] { "Raw", "Finished", "Auxiliary" } },
                new FieldDef { Key = "active", LabelAr = "نشط", Kind = "check", Default = "true" }
            },
            Save = v =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                int? id = v.TryGetValue("__id", out var x) && x != null ? Convert.ToInt32(x) : null;
                return Wrap(() => svc.SaveWarehouse(id, v["code"]?.ToString(), v["name"]?.ToString(), v["type"]?.ToString(), v["active"] is bool b && b));
            },
            LoadForEdit = id =>
            {
                using var scope = AppContainer.NewScope();
                var db = scope.ServiceProvider.GetRequiredService<DatesErpDbContext>();
                var w = db.Warehouses.First(x => x.Id == id);
                return new Dictionary<string, object> { ["code"] = w.WarehouseCode, ["name"] = w.WarehouseNameAr, ["type"] = w.WarehouseType, ["active"] = w.IsActive };
            },
            Delete = id =>
            {
                using var scope = AppContainer.NewScope();
                var svc = scope.ServiceProvider.GetRequiredService<Application.Services.MasterDataService>();
                return Wrap(() => svc.DeleteWarehouse(id));
            }
        });
    }

    public static GenericListView ForLots() => new("الدفعات Lots — (المستلم / المصروف للإنتاج / المتبقي / المسلَّم)", db => (
        new() { "الدفعة", "الصنف", "العميل", "المستلم (كجم)", "المصروف للإنتاج (كجم)", "المتبقي (كجم)", "المحجوز للخطط (كجم)", "المتاح (كجم)", "المسلَّم (كجم)" },
        db.Lots.ToList().Select(l => new object[]
        {
            l.LotCode,
            db.Products.Where(p => p.Id == l.ProductId).Select(p => p.ProductNameAr).FirstOrDefault(),
            db.Customers.Where(c => c.Id == l.CustomerId).Select(c => c.CustomerName).FirstOrDefault(),
            l.InitialQtyKg, l.ProducedQtyKg, l.InStockQtyKg, l.ReservedQtyKg, l.AvailableQtyKg, l.DeliveredQtyKg
        }).ToList()));

    public static GenericListView ForExecutions() => new("متابعة التنفيذ", db => (
        new() { "الجلسة", "الأمر", "البداية", "النهاية", "الكمية (كجم)", "الكراتين", "الحالة" },
        db.ProductionExecutions.ToList().Select(e => new object[]
        {
            e.DocumentNumber,
            db.ProductionOrders.Where(o => o.Id == e.OrderId).Select(o => o.DocumentNumber).FirstOrDefault(),
            e.StartDateTime?.ToString("dd/MM/yyyy HH:mm"), e.EndDateTime?.ToString("dd/MM/yyyy HH:mm"),
            e.ActualQtyKg, e.ActualCartons, e.Status
        }).ToList()));

    public static GenericListView ForWastage() => new("الهالك والأصناف الثانوية (بالكيلو)", db => (
        new() { "الفحص", "الصنف الثانوي", "الوحدة", "الكمية (كجم)" },
        db.QualityByProductRecords.ToList().Select(b => new object[]
        {
            db.QualityChecks.Where(c => c.Id == b.CheckId).Select(c => c.DocumentNumber).FirstOrDefault(),
            db.ByProducts.Where(x => x.Id == b.ByProductId).Select(x => x.ByProductNameAr).FirstOrDefault(),
            db.ByProducts.Where(x => x.Id == b.ByProductId).Select(x => x.UnitOfMeasure).FirstOrDefault(),
            b.QtyKg
        }).ToList()));

    public static GenericListView ForBalances() => new("أرصدة المخزون", db => (
        new() { "المخزن", "الصنف/المادة", "الدفعة", "العميل", "الرصيد (كجم)", "العبوات" },
        db.StockBalances.Where(b => b.QtyKg != 0 || b.PackageCount != 0).ToList().Select(b => new object[]
        {
            db.Warehouses.Where(w => w.Id == b.WarehouseId).Select(w => w.WarehouseNameAr).FirstOrDefault(),
            b.ProductId != null ? db.Products.Where(p => p.Id == b.ProductId).Select(p => p.ProductNameAr).FirstOrDefault()
                                : db.AuxiliaryMaterials.Where(m => m.Id == b.MaterialId).Select(m => m.MaterialNameAr).FirstOrDefault(),
            db.Lots.Where(l => l.Id == b.LotId).Select(l => l.LotCode).FirstOrDefault(),
            db.Customers.Where(c => c.Id == b.CustomerId).Select(c => c.CustomerName).FirstOrDefault(),
            b.QtyKg, b.PackageCount
        }).ToList()));

    public static GenericListView ForMovements() => new("حركات المخزون (تتبع كامل)", db => (
        new() { "الحركة", "التاريخ", "المخزن", "الصنف", "الدفعة", "النوع", "الكمية (كجم)", "المستند المرجعي", "المستخدم", "الجهاز" },
        db.InventoryTransactions.OrderByDescending(t => t.TxnDate).Take(1000).ToList().Select(t => new object[]
        {
            t.TxnNumber, t.TxnDate.ToString("dd/MM/yyyy HH:mm"),
            db.Warehouses.Where(w => w.Id == t.WarehouseId).Select(w => w.WarehouseNameAr).FirstOrDefault(),
            t.ProductId != null ? db.Products.Where(p => p.Id == t.ProductId).Select(p => p.ProductNameAr).FirstOrDefault()
                                : db.AuxiliaryMaterials.Where(m => m.Id == t.MaterialId).Select(m => m.MaterialNameAr).FirstOrDefault(),
            db.Lots.Where(l => l.Id == t.LotId).Select(l => l.LotCode).FirstOrDefault(),
            t.MovementType == Core.Domain.Enums.MovementType.Inbound ? "وارد" : "صادر",
            t.QtyKg, $"{t.ReferenceDocType}: {t.ReferenceDocNumber}",
            db.Users.Where(u => u.Id == t.CreatedBy).Select(u => u.FullName).FirstOrDefault(),
            t.MachineName
        }).ToList()));

    public static GenericListView ForMachines() => new("الأجهزة المتصلة بالنظام", db => (
        new() { "معرف الجهاز", "اسم الجهاز", "مستخدم ويندوز", "إصدار التطبيق", "آخر دخول", "آخر ظهور", "الحالة" },
        db.ClientMachines.OrderByDescending(m => m.LastSeen).ToList().Select(m => new object[]
        {
            m.MachineId, m.MachineName, m.WindowsUser, m.ApplicationVersion,
            m.LastLogin?.ToString("dd/MM/yyyy HH:mm"), m.LastSeen?.ToString("dd/MM/yyyy HH:mm"),
            m.IsActive ? "نشط" : "غير نشط"
        }).ToList()));

    public static GenericListView ForAudit() => new("سجل التدقيق", db => (
        new() { "التاريخ", "المستخدم", "الجهاز", "الإجراء", "الشاشة", "المستند", "رقم السجل" },
        db.AuditLogs.OrderByDescending(a => a.ActionDate).Take(1000).ToList().Select(a => new object[]
        {
            a.ActionDate.ToString("dd/MM/yyyy HH:mm:ss"), a.UserName, a.MachineName, a.ActionType, a.ScreenName, a.DocumentNumber, a.RecordId
        }).ToList()));
}
