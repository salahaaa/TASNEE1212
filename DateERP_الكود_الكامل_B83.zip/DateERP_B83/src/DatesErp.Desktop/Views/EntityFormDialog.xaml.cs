using System.Windows;
using System.Windows.Controls;

namespace DatesErp.Desktop.Views;

/// <summary>§23 — نافذة نموذج عامة (جديد/تعديل) تُبنى ديناميكياً من تعريف الحقول.</summary>
public class FieldDef
{
    public string Key { get; set; }
    public string LabelAr { get; set; }
    public string Kind { get; set; } = "text"; // text | number | combo | check
    public string[] Options { get; set; }
    public string Default { get; set; }
}

public partial class EntityFormDialog : Window
{
    private readonly List<(FieldDef def, FrameworkElement control)> _controls = new();
    public Dictionary<string, object> Values { get; } = new();

    public EntityFormDialog(string title, IEnumerable<FieldDef> fields, Dictionary<string, object> initialValues = null)
    {
        Title = title;
        FlowDirection = FlowDirection.RightToLeft;
        WindowStartupLocation = WindowStartupLocation.CenterOwner;
        Width = 480;
        ResizeMode = ResizeMode.NoResize;
        Background = (System.Windows.Media.Brush)new System.Windows.Media.BrushConverter().ConvertFromString("#F4F6F4");

        var panel = new StackPanel { Margin = new Thickness(20) };
        initialValues ??= new Dictionary<string, object>();

        // §الاحتفاظ بالقيم الإضافية الممررة من الشاشة (مثل __id رقم السجل للتعديل)
        // حتى لا يتحول التعديل إلى إضافة جديدة ويعطي «هذا الرقم محجوز»
        foreach (var kv in initialValues) Values[kv.Key] = kv.Value;

        foreach (var f in fields)
        {
            panel.Children.Add(new TextBlock
            {
                Text = f.LabelAr,
                Style = (Style)System.Windows.Application.Current.FindResource("FieldLabel")
            });

            FrameworkElement ctl;
            object initial = initialValues.TryGetValue(f.Key, out var v) ? v : (object)f.Default;

            switch (f.Kind)
            {
                case "combo":
                    var cb = new ComboBox { ItemsSource = f.Options };
                    if (initial != null) cb.SelectedItem = initial.ToString();
                    else if (f.Options?.Length > 0) cb.SelectedIndex = 0;
                    ctl = cb;
                    break;
                case "check":
                    // §إصلاح: القيمة الافتراضية قد تكون نص "true" — نحوله لمنطقي حتى لا تُنشأ
                    // السجلات الجديدة «موقوفة» فتختفي من القوائم المنسدلة
                    bool initialCheck = initial is bool bb
                        ? bb
                        : bool.TryParse(initial?.ToString(), out var parsed) && parsed;
                    var ck = new CheckBox { Content = f.LabelAr, IsChecked = initialCheck };
                    ctl = ck;
                    break;
                default:
                    var tb = new TextBox { Text = initial?.ToString() ?? "" };
                    ctl = tb;
                    break;
            }
            _controls.Add((f, ctl));
            panel.Children.Add(ctl);
        }

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 16, 0, 0) };
        var ok = new Button { Content = "💾 حفظ", Style = (Style)System.Windows.Application.Current.FindResource("PrimaryButton") };
        ok.Click += (_, _) =>
        {
            // تُحدَّث حقول النموذج فقط — القيم الإضافية (__id وغيره) تبقى محفوظة
            foreach (var (def, ctl) in _controls)
            {
                Values[def.Key] = ctl switch
                {
                    TextBox t => t.Text,
                    ComboBox c => c.SelectedItem?.ToString(),
                    CheckBox c => c.IsChecked == true,
                    _ => null
                };
            }
            DialogResult = true;
            Close();
        };
        var cancel = new Button { Content = "إلغاء", Style = (Style)System.Windows.Application.Current.FindResource("SecondaryButton") };
        cancel.Click += (_, _) => { DialogResult = false; Close(); };
        buttons.Children.Add(ok);
        buttons.Children.Add(cancel);
        panel.Children.Add(buttons);

        Content = new System.Windows.Controls.ScrollViewer { Content = panel, VerticalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Auto, MaxHeight = 560 };
        SizeToContent = SizeToContent.Height;
    }
}
